# Changelog v0.3

- Импортировано 8 уникальных Faction Packs v1.0.
- Подтверждён и удалён повторный Custodes PDF.
- Добавлено 41 detachments.
- Проиндексировано 169 stratagems.
- Проиндексировано 93 matched-play/Imperial Armour datasheets.
- Создан поиск по 276 PDF-страницам.
- Добавлены 80 faction regression tests.
- Зарегистрированы live MFM 4.3 и Balance Dataslate 3.3 как обязательные внешние слои.
