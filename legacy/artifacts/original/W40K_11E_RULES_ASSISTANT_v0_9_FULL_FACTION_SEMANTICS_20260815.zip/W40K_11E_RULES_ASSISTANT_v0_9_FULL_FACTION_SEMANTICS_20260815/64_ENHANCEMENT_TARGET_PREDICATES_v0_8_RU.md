# v0.8 — Enhancement Target Predicates

Файл `data/enhancement_target_predicates_v0_8_20260815.json` переводит точные target clauses из удерживаемых Faction Pack источников в машинные predicates.

## Покрытие checkpoint

- MFM current Enhancement cost entries: **267**;
- exact target clauses, доступные в локальном retained source corpus: **115**;
- executable normalized predicates: **115/115**;
- доля всего MFM enhancement-cost каталога с exact локальным target predicate: **43.1%**.

Это различие принципиально: наличие цены Enhancement в MFM не доказывает его target wording. Остальные entries не реконструируются по памяти и не угадываются.

Predicates поддерживают:

- required keyword/tag;
- несколько обязательных tags;
- альтернативные группы `A or B`;
- exclusions;
- required ability;
- standard Enhancement vs Upgrade semantics;
- exact detachment membership;
- EPIC HERO prohibition;
- one-enhancement-per-unit;
- current MFM price.

Имена сверяются Unicode/case-normalization. Отдельный alias registry хранит реальные extraction/OCR расхождения, например `Praes.idius` → current MFM `Praesidius`.

QA:

```bash
python tools/validate_enhancement_targets_v0_8.py
```

Expected: `115/115 executable`.
