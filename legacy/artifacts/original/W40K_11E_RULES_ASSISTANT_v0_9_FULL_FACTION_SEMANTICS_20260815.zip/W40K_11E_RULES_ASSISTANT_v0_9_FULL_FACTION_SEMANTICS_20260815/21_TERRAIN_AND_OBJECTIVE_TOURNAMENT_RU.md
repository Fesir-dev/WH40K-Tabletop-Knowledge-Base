# Турнирный terrain и objective markers

## Поле

Официальный Companion v1.5 ориентирован на Strike Force и поле примерно **44×60 дюймов**.

## Набор area-terrain outlines

Каждый из восьми layouts строится из:
- 4 секций 6×4 дюйма;
- 2 секций 10×5 дюймов;
- 6 секций 12×6 дюймов.

В документах показаны рекомендуемые высоты участков: более 4 дюймов и 2 дюйма или ниже. Основой layouts служат Ruins, но Woods, Barricades и Hills допустимы при сохранении функций поля.

## Objective markers

В Tournament Companion маркеры — плоские круги 40 мм; на них можно завершать движение. Это форматная поправка и она отличается от общего Core Rules подхода к физическим objective artefacts/terrain objectives.

При setup-измерениях по Mission FAQ мерить от центра маркера. Для контроля во время игры применять точное правило objective из Core Rules/terrain area или миссионную поправку, не смешивая setup distance и control range.

## Использование layout ID

`data/tournament_mission_pool.json` показывает, какие layouts допустимы для каждой комбинации A–T. Точные координаты и ориентация берутся с диаграммы официального Companion; проект намеренно не воспроизводит их по памяти.

## Геометрический анализ позиции

Для запроса приложить:
- mission code и layout;
- ориентацию Attacker/Defender;
- фото сверху или схему с размерами;
- какие стены выше 4 дюймов, какие низкие;
- фактические opening/gaps;
- размеры баз спорных моделей.

После этого проверять true visibility, Hidden/Obscuring/Solid, route distance, charge end position, pile-in и consolidation.
