# Current query + regression layer — v0.6

## Быстрый current-only поиск

```bash
python tools/query_current.py "Venatari"
python tools/query_current.py "Take and Hold" --faction adeptus_custodes
python tools/query_current.py "Unbridled Bloodlust" --faction world_eaters
```

Инструмент ищет только в MFM 1.2 current runtime, Leader/Support graph и semantic Faction Pack v1.1 update index. Если совпадения нет, он не падает молча в historical snapshot.

## Исполняемые регрессии

```bash
python tools/run_current_regressions.py
```

Набор фиксирует sentinel cases для points/copy bands, DP/Force Dispositions и faction rules-update markers. Это не заменяет полный rules engine, но переводит ключевые July-2026 изменения из «документации» в автоматически проверяемые invariants.
