# Chapter Approved Tournament Mission Pool v1.5

| Код | Primary | Deployment | Допустимые layouts |
|---|---|---|---|
| A | Take and Hold | Tipping Point | 1, 2, 4, 6, 7, 8 |
| B | Supply Drop | Tipping Point | 1, 2, 4, 6, 7, 8 |
| C | Linchpin | Tipping Point | 1, 2, 4, 6, 7, 8 |
| D | Scorched Earth | Tipping Point | 1, 2, 4, 6, 7, 8 |
| E | Take and Hold | Hammer and Anvil | 1, 7, 8 |
| F | Hidden Supplies | Hammer and Anvil | 1, 7, 8 |
| G | Purge the Foe | Hammer and Anvil | 1, 7, 8 |
| H | Supply Drop | Hammer and Anvil | 1, 7, 8 |
| I | Hidden Supplies | Search and Destroy | 1, 2, 3, 4, 6 |
| J | Linchpin | Search and Destroy | 1, 2, 3, 4, 6 |
| K | Scorched Earth | Search and Destroy | 1, 2, 3, 4, 6 |
| L | Take and Hold | Search and Destroy | 1, 2, 3, 4, 6 |
| M | Purge the Foe | Crucible of Battle | 1, 2, 4, 6, 8 |
| N | Hidden Supplies | Crucible of Battle | 1, 2, 4, 6, 8 |
| O | Terraform | Crucible of Battle | 1, 2, 4, 6, 8 |
| P | Scorched Earth | Crucible of Battle | 1, 2, 4, 6, 8 |
| Q | Supply Drop | Sweeping Engagement | 3, 5 |
| R | Terraform | Sweeping Engagement | 3, 5 |
| S | Linchpin | Dawn of War | 5 |
| T | Purge the Foe | Dawn of War | 5 |

Точный способ начисления VP определяется карточкой Primary. Таблица хранит только официальную комбинацию Primary, deployment и рекомендованных terrain layouts.
