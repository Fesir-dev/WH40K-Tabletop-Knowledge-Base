# Regression tests

Тесты нужны, чтобы обновление одного слоя не вернуло старые или 10th-edition ответы.

Ключевые сценарии:

1. Unit без ranged weapons остаётся eligible to shoot.
2. Blast не стреляет в engaged target через Monster/Vehicle exceptions.
3. Scout move не позволяет последующий embark.
4. Overrun fight невозможен без текущей eligibility to fight.
5. Tactical во второй Command phase с одной активной картой берёт только одну.
6. Добровольный сброс двух Tactical в свой ход даёт 1CP, не 2CP.
7. В Reserves одновременно 6 из 10 units, даже при 40% points — незаконно.
8. Attached Unit продолжает Action после гибели одного component unit.
9. Marked for Death требует Bodyguard плюс минимум одного Leader.
10. Objective setup distance измеряется от центра.
11. Тabled player продолжает ходы до конца пятого round.
12. Tournament objective допускает end move on top; casual Core scenario требует проверки mission context.
13. Preview statement не переопределяет Companion v1.5.
14. Старый 10e dataslate не применяется автоматически.
15. Points без MFM version не принимаются как финальные.

Machine cases: `data/rules_tests.json`.
