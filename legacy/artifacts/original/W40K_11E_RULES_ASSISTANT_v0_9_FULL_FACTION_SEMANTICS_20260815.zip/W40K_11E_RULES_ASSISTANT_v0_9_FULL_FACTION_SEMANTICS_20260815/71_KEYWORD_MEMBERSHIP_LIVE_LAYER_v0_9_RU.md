# v0.9 — Current Keyword Membership Live Layer

## Цель

`data/keyword_membership_current_v0_9_20260815.json` хранит доказуемую принадлежность текущих datasheet к важным keywords. Это не полный зеркальный Codex/App export: слой предназначен для machine-readable legality evidence.

## Семантика evidence

- `member in list` → keyword доказан.
- `complete_for_local_mfm: true` и unit отсутствует в списке → keyword доказанно отсутствует в текущем локальном MFM corpus.
- `complete_for_local_mfm: false` и unit отсутствует → **UNKNOWN**, а не `false`.
- Официальные GW документы остаются authoritative; Wahapedia 11e используется как structured secondary cross-check.

## Текущий объём

- 8 пользовательских фракций.
- 62 keyword records.
- 435 positive unit→keyword assertions.
- 52 keyword sets complete для локального current-MFM corpus.

Новые высокоценные complete sets включают Custodes `VEHICLE/TERMINATOR`, AdMech `INFANTRY/JUMP PACK/LEGIO CYBERNETICA`, Imperial Knights `DOMINUS`, World Eaters `VEHICLE`, а также CSM transport-sensitive `JUMP PACK/OBLITERATORS/MUTILATORS/POSSESSED`.
