# v0.8 — Faction Legality Engine

Checkpoint: **2026-08-15**.

`tools/validate_roster_v0_8.py` расширяет v0.7 от core-legality к исполняемым faction-specific ограничениям. Источник приоритета остаётся: **официальный GW current text → официальный update/app → Wahapedia как structured cross-check → локальный historical snapshot**.

## Что исполняется

- всё покрытие v0.7: points, DP, Unit Limits, Epic Hero, Warlord, Leader/Support, базовая Enhancement legality, start-loaded Dedicated Transports;
- Enhancement обязан происходить из реально выбранного detachment;
- 115 exact Enhancement/Upgrade target predicates из удерживаемых Faction Pack источников;
- 6/6 Dedicated Transport profiles текущего role-dataset: capacity + passenger keyword/exclusion checks;
- 7 Supreme Commander / must-be-Warlord rules, включая специальный max-one для Patriarch;
- 7 нормализованных faction-composition rules, включая Scintillating Legions, Blood Legions, Final Day, Questor Forgepact, Solar Spearhead Moritoi, Pactbound Marks и Renegade Warband restriction;
- отдельная модель `army availability != native faction keyword`, чтобы союзный unit не становился Warlord только потому, что он находится в текущем MFM bucket армии;
- адресуемые unit IDs: unit row с `quantity > 1` нельзя использовать как один конкретный Warlord/Enhancement target/attachment/transport target.

## Результаты

- `FAIL` — обнаружено исполняемое нарушение;
- `PASS_WITH_UNVERIFIED_DETAILS` — известных нарушений нет, но одному или нескольким current rules не хватает точного локально-нормализованного evidence;
- `CURRENT_CERTIFIED` — все правила, необходимые для переданного roster input в текущем нормализованном scope, доказаны и пройдены.

`CURRENT_CERTIFIED` не означает, что проект уже локально зеркалирует весь Codex/App corpus; это сертификат только для конкретного ростера и только при отсутствии unresolved gates.

Запуск:

```bash
python tools/validate_roster_v0_8.py examples/roster_v0_8_current_certified_custodes.json
```
