# v0.8 — Regression Certification

Главный runner:

```bash
python tools/run_roster_regressions_v0_8.py
```

Checkpoint: **25/25 PASS**.

Покрыты, среди прочего:

- Supreme Commander must-be-Warlord;
- Solar Spearhead Moritoi Character grant и отрицательный case;
- exact Enhancement target predicate valid/invalid;
- Enhancement только из выбранного detachment;
- Patriarch max-one;
- Final Day permitted/excluded Tyranid allies;
- Pactbound Khorne Psyker prohibition;
- Pactbound attachment mark match;
- Pactbound transport/passenger mark match;
- Renegade Warband incompatible option;
- CSM Rhino capacity/exclusions;
- Questor Forgepact exact AdMech ally allowlist;
- Thousand Sons Scintillating Legions availability + point cap;
- World Eaters Blood Legions availability + point cap;
- ambiguity guard: targeted `unit_id` cannot represent `quantity > 1`.

Inherited suites remain mandatory:

- v0.6 current runtime: **18/18 PASS**;
- v0.7 rules engine: **19/19 PASS**.

Итого на checkpoint: **62/62 executable regression cases PASS**.
