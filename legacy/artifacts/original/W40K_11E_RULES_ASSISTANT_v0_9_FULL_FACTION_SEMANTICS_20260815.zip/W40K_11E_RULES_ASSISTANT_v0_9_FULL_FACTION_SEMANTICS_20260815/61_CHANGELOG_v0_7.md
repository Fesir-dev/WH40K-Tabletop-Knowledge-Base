# Changelog v0.7 — 2026-08-15

## Added

- executable Core Roster Legality Engine;
- current battle-size constraints and Incursion 3DP exception;
- current unit-role dataset for all 8 user factions;
- Warlord native-faction eligibility layer;
- Leader/Support attachment legality;
- Dedicated Transport start-loaded legality;
- Enhancement execution layer with Upgrade semantics where source-confirmed;
- current universal interaction engine;
- source-conflict gate and explicit UNKNOWN state;
- unit-role lookup/validator;
- 19-case v0.7 executable regression suite;
- 169-entry current-aware Stratagem semantic index and query tool.

## Safety/authority changes

- Official GW remains authoritative over Wahapedia.
- Secondary/current and historical sources can no longer silently resolve a source conflict.
- A core PASS does not claim full faction legality while detachment-specific composition/target restrictions remain unnormalized.
