# Проверка ростера

## Формат входного JSON

```json
{
  "faction": "adeptus_custodes",
  "dp_limit": 5,
  "detachments": ["Shield Host", "Might of the Moritoi"],
  "enhancements": [
    {"detachment": "Shield Host", "name": "Auric Mantle"}
  ],
  "units": [
    {"name": "Custodian Guard", "models": 5, "quantity": 2},
    {"name": "Caladius Grav-tank", "models": 1, "quantity": 1,
     "wargear": [{"name": "Twin arachnus heavy blaze cannon", "count": 1}]}
  ]
}
```

## Команды

```bash
python tools/cost_roster.py roster.json
python tools/check_detachments.py adeptus_custodes "Might of the Moritoi" "Solar Spearhead"
python tools/leader_lookup.py chaos_space_marines "Huron Blackheart"
python tools/validate_live_layers.py
```

## Что проверяется

- цена нужной по порядку копии datasheet;
- допустимый размер unit;
- платное wargear;
- enhancement cost и принадлежность detachment;
- сумма Detachment Points;
- конфликты unique-tags;
- Leader/Support links.

## Что не считается автоматически

- полная legality по всем Codex/app ограничениям;
- Warlord requirements;
- союзники и специальные mustering exceptions;
- base sizes;
- будущие hotfixes после даты snapshot.


## Current runtime v0.6

`cost_roster.py`, `check_detachments.py` и `leader_lookup.py` читают `data/mfm_v1_2_user_factions_20260815.json`. Проверить миграцию:

```bash
python tools/validate_current_mfm.py
python tools/validate_rules_updates_v1_1.py
python tools/run_current_regressions.py
```

Historical MFM 20260710 не используется current costing engine.

## v0.7 superseding execution layer

For current 11e legality use `tools/validate_roster_v0_7.py`. It supersedes the earlier points/DP-only structural check for new work. The old `cost_roster.py` is retained for compatibility and simple costing.
