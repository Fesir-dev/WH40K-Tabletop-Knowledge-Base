# v0.9 — Regression Certification

Новый набор `data/roster_regression_v0_9.json` содержит 18 executable cases.

Проверяются:

- automatic positive/negative keyword evidence;
- exact Enhancement target predicates;
- specific Enhancement target precedence;
- non-Dedicated Transport loading;
- passenger eligibility;
- space multipliers;
- Orion special slot/capacity override;
- право обычного Transport начинать пустым.

Результат: **18/18 PASS**.

Наследуемые наборы также обязательны:

- v0.6: 18/18;
- v0.7: 19/19;
- v0.8: 25/25;
- v0.9: 18/18.

Cumulative: **80/80 executable regressions PASS**.
