# v0.7 — Core Roster Legality Engine

Checkpoint: 2026-08-15.

`tools/validate_roster_v0_7.py` переводит базовые правила построения армии 11-й редакции из справочного текста в исполняемые проверки.

## Уже исполняется

- лимит очков по battle size;
- Detachment Points и специальное исключение Incursion для единственного 3-DP detachment;
- запрет повторного выбора одного detachment;
- UNIQUE-tag conflicts из MFM;
- Unit Limit;
- удвоенный Unit Limit для BATTLELINE и DEDICATED TRANSPORT;
- максимум одна копия EPIC HERO;
- обязательный Warlord и проверка CHARACTER/native faction eligibility;
- Leader/Support graph: допустимый bodyguard, максимум один Leader + один Support, Support обязан быть прикреплён;
- Enhancement Limit;
- EPIC HERO не может получить enhancement;
- standard enhancement требует CHARACTER;
- Upgrade copies считаются по отдельной логике, если тип Enhancement подтверждён локальным faction-pack source;
- один enhancement на один unit;
- текущая стоимость units/wargear/enhancements из MFM v1.2;
- обязательный embarked friendly unit для каждого DEDICATED TRANSPORT перед началом боя.

## Принцип неполной сертификации

Движок не объявляет ростер полностью tournament-legal, если не нормализованы faction-specific restrictions, transport capacity/passenger keywords или точный тип/target restriction конкретного Enhancement. В таких случаях результат — `PASS_WITH_UNVERIFIED_FACTION_RULES`, а не ложный `CURRENT_CERTIFIED`.

## Формат минимального roster JSON

```json
{
  "faction": "adeptus_custodes",
  "battle_size": "incursion",
  "units": [
    {"id":"cap","name":"Shield-Captain","models":1},
    {"id":"guard","name":"Custodian Guard","models":4}
  ],
  "detachments": ["Might of the Moritoi"],
  "warlord_unit_id": "cap",
  "attachments": [
    {"character_unit_id":"cap","bodyguard_unit_id":"guard"}
  ],
  "enhancements": [],
  "dedicated_transport_loads": []
}
```

Запуск:

```bash
python tools/validate_roster_v0_7.py roster.json
```
