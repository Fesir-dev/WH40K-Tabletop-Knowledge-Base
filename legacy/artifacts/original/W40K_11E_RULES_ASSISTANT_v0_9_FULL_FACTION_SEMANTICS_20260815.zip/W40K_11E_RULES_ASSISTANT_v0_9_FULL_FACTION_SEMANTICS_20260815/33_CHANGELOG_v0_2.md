# Changelog v0.2 — 2026-07-10

- Добавлен русскоязычный master prompt.
- Внедрён Chapter Approved Tournament Companion v1.5.
- Добавлена последовательность из 15 pre-game/game steps.
- Добавлены Fixed/Tactical, New Orders, Actions, Reserves, deployment/redeploy и scoring caps.
- Добавлен официальный пул A–T и layout compatibility.
- Добавлены mission FAQ rulings.
- Добавлены Force Dispositions и MFM live policy.
- Разделены printed Rules Appendix и app-only gaps.
- Добавлены source/version conflict traps.
- Добавлена схема faction layer и шаблоны.
- Добавлены SQLite, JSON, CSV, query/validation utilities и regression tests.
- Зафиксирован незакрытый блок: конкретная фракция и полный app-only appendix.
