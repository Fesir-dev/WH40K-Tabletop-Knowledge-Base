# Core Abilities Glossary (`24`)

## General duplication rule

Multiple instances of the same Core or weapon ability do not stack. Choose one applicable instance. This includes different numbers and different keyword variants. Scouts has a special mixed-unit rule: use the lowest value not shared by every model.

## Weapon abilities

### `[ANTI-X Y+]`
Against a target unit with keyword X, an unmodified wound roll of Y+ is a Critical Wound.

### `[ASSAULT]`
Allows a unit containing the weapon to use Assault Shooting after Advancing; only Assault weapons can be selected.

### `[BLAST]` / `[BLAST X]`
Add 1, or X, attack dice per full five models in the target unit at target selection.

### `[CLEAVE X]`
Melee analogue of Blast, but only when all attacks from the weapon are assigned to one target. Add X dice per full five target models.

### `[CLOSE-QUARTERS]`
Enables Close-quarters Shooting. Non-MONSTER/VEHICLE models using another shooting type choose either close-quarters weapons or other ranged weapons.

### `[DEVASTATING WOUNDS]`
Critical Wound becomes mortal wounds equal to D; each critical attack can damage at most one model.

### `[EXTRA ATTACKS]`
Must be selected in addition to one other melee weapon when the model fights.

### `[HAZARDOUS]`
After the unit resolves all attacks, make one hazard roll per hazardous weapon selected.

### `[HEAVY]`
In own Shooting phase, +1 hit roll if unengaged, not set up this turn, and no model moved more than 3".

### `[IGNORES COVER]`
Target cannot receive Benefit of Cover from any source.

### `[INDIRECT FIRE]`
Enables Indirect Shooting. The shooting type supplies the visibility, cover, reroll and hit-floor restrictions.

### `[LANCE]`
+1 to wound if attacking model's unit charged this turn.

### `[LETHAL HITS]`
Critical Hit may automatically wound. Optional; declining can preserve Critical Wound opportunities.

### `[MELTA X]`
If target was within half range at target selection, add X to D until the unit's attacks finish.

### `[ONE SHOT]`
Weapon can be selected once per battle. Revival does not refresh it; a newly added unit receives its own use.

### `[PISTOL]`
Functionally identical to `[CLOSE-QUARTERS]`; legacy term being superseded.

### `[PRECISION]`
At allocation order, attacker may make a visible CHARACTER group the current group until those attacks finish or the group dies.

### `[PSYCHIC]`
Attacker may ignore any/all BS/WS and hit-roll modifiers. Attacks count as psychic attacks.

### `[RAPID FIRE X]`
Add X attack dice if target was within half range at target selection.

### `[SUSTAINED HITS X]`
Each Critical Hit generates X additional hits.

### `[TORRENT]`
Automatically hits.

### `[TWIN-LINKED]`
May reroll wound roll.

## Unit abilities

### Deadly Demise X
When the model is destroyed, after emergency disembarkations, roll a D6. On 6, each unit within 6" suffers X mortal wounds; roll random X separately per affected unit.

### Deep Strike
All models must have it. During Ingress, set up anywhere more than 8" from enemies, including opponent deployment zone.

### Feel No Pain X+
Each time the model would lose a wound, roll; on X+ the wound is not lost.

### Fights First
A unit is Fights First only while every model in it has the ability.

### Firing Deck X
When the transport shoots, select up to X embarked models and one non-One-Shot ranged weapon each; transport temporarily gains them. Embarked units cannot shoot later that turn.

### Hover
Taking to the skies does not reduce movement by 2".

### Infiltrators
If every model has it, deploy more than 8" from opponent deployment zone and all enemies.

### Leader
Forms an Attached Unit with a listed Bodyguard.

### Lone Operative / Lone Operative X"
Unless attached, not visible beyond the listed distance and cannot be targeted by Indirect Fire beyond it.

### Scouts X"
In pre-battle abilities, redeploy from reserves into own deployment zone or make a Scout Move; can transfer to a Dedicated Transport if every passenger qualifies.

### Scout Move
Move up to X" and end more than 8" from all enemies. Cannot embark afterward according to the Core FAQ.

### Stealth
If every model has it, target unit gains Benefit of Cover against ranged attacks.

### Support
Forms an Attached Unit with a listed Bodyguard.

### Super-heavy Walker
Normal/Advance/Fall-back through non-TITANIC models and terrain sections up to 4". May gain MOBILE for the move, risking Battle-shock on a roll of 1 afterward.
