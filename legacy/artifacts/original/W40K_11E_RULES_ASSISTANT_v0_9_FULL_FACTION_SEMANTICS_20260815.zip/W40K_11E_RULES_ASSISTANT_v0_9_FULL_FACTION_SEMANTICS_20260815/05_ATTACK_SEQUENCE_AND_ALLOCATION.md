# Attack Sequence and Allocation

## A. Making attacks (`04`)

### 1. Select weapons

- Shooting: each model can select one or more ranged weapons, subject to weapon restrictions.
- Fighting: each model selects one melee weapon, plus all applicable `[EXTRA ATTACKS]` weapons.
- Non-MONSTER/VEHICLE models with `[CLOSE-QUARTERS]` weapons must often choose between their close-quarters set and their other ranged weapons.

### 2. Select targets

Shooting target normally must be:

- visible to the attacking model;
- within weapon range;
- unengaged.

Fighting target must be engaged with the attacking model. A melee weapon can split attacks between multiple engaged units, but the split must be declared before rolling.

### 3. Resolve attacks

- Select one enemy target unit.
- Select one weapon profile attacking it.
- Pool identical attacks only if BS/WS, S, AP, D and all applicable rules are identical.
- Resolve the full attack sequence.
- Repeat for other weapons and targets.

## B. Hit roll (`05.01`)

Order of checks:

1. Unmodified 1 fails.
2. Unmodified 6 is a Critical Hit.
3. Modified result meeting BS/WS hits.
4. Otherwise fails.

Core reminder: automatic hits do not make a hit roll, so they do not naturally produce a rolled Critical Hit unless another rule explicitly says so.

## C. Wound roll (`05.02`)

| Strength vs Toughness | Required |
|---|---:|
| S is at least double T | 2+ |
| S greater than T | 3+ |
| S equal to T | 4+ |
| S less than T | 5+ |
| S at most half T | 6+ |

Order of checks:

1. Unmodified 1 fails.
2. Unmodified 6 is a Critical Wound.
3. Result meeting the required value wounds.
4. Otherwise fails.

`[ANTI-X Y+]` changes which unmodified wound results count as critical wounds against the listed keyword.

## D. Save groups and allocation (`05.03`)

The defender creates allocation groups:

- one separate group for each CHARACTER model;
- one group for all non-CHARACTER models sharing W, Sv and InSv.

Then declare group order with these constraints:

1. A wounded non-CHARACTER group must be first.
2. No CHARACTER group can precede a non-CHARACTER group.
3. Wounded CHARACTER groups precede unwounded CHARACTER groups.

Important consequences:

- A defender can often choose which equivalent bodyguard profile is exposed first.
- Each CHARACTER is its own allocation group.
- `[PRECISION]` can override normal order for a visible CHARACTER group.
- Attacks still target the unit, not individual models.

## E. Save rolls and damage (`05.04`)

1. Roll one save die for every wound.
2. Resolve results from **lowest to highest**.
3. Allocate to a model in the current group; a wounded model in that group must be selected if possible.
4. An unmodified save roll of 1 inflicts damage.
5. Otherwise an eligible invulnerable save succeeds if the result meets InSv.
6. Otherwise modify the die by AP and compare with Sv.
7. Failed save: lose wounds equal to D; destroy at 0 or fewer.

Excess normal damage from a single attack does not spill to another model unless a rule explicitly says so.

## F. Mortal wounds (`06.02`)

Mortal wounds are allocated one at a time with this priority:

1. wounded non-CHARACTER;
2. other non-CHARACTER;
3. wounded CHARACTER;
4. other CHARACTER.

Resolve normal damage first, then mortal wounds, when an attack pool produces both.

## G. Devastating Wounds (`24.10`)

On a Critical Wound:

- the attack sequence ends for that attack;
- the target suffers mortal wounds equal to D;
- those mortal wounds are applied after normal damage from the attack pool;
- mortal wounds from each individual Critical Wound can damage at most one model;
- excess from that single critical attack is lost.

Example: D3 Devastating Wounds into 2-Wound infantry can kill at most one model per critical wound, even if 1 mortal wound remains.

## H. Lethal Hits decision (`24.23`)

A Critical Hit can be chosen to automatically wound. This is optional.

Choose automatic wound when:

- the normal wound chance is poor;
- no valuable Critical Wound effect is being sacrificed.

Decline automatic wound when:

- rolling a wound can trigger `[DEVASTATING WOUNDS]`, `[ANTI]` or another Critical Wound effect;
- the expected value of the critical-wound payoff exceeds the risk of failing the wound.

## I. Hazard rolls (`06.03`, `24.15`)

- Roll a D6; 1-2 fails.
- Failed roll: unit suffers 1 mortal wound, or 3 if every model in the unit is MONSTER/VEHICLE.
- `[HAZARDOUS]`: after all attacks, make one hazard roll per selected hazardous weapon, not per attack generated.

## J. Attached-unit attack notes

- Use the highest Toughness among bodyguard models while bodyguards remain.
- If only leader/support models remain, use the highest Toughness among them.
- The attached unit has all component keywords; this can make every attack against the unit eligible for `[ANTI]` effects based on a leader's keyword.
- Source abilities persist through the end of the attacking unit's attacks when the source is destroyed by those attacks.
