# v0.7 — Enhancement Execution Layer

`data/enhancement_metadata_v0_7_20260815.json` вводит машинную классификацию Enhancement type там, где исходный faction-pack text сохранён локально.

Для подтверждённого `UPGRADE` движок знает, что:

- до трёх copies одного Upgrade допускаются общей механикой;
- первая copy занимает Enhancement choice;
- вторая и третья не увеличивают Enhancement Limit;
- points каждой copy всё равно оплачиваются.

Для standard Enhancement движок проверяет CHARACTER target, EPIC HERO prohibition, duplication и лимит одного Enhancement на unit.

Важно: конкретные target clauses вида `... unit only` пока не нормализованы глобально. Поэтому Upgrade может пройти общую core-проверку, но получить предупреждение о faction-specific target restriction. Это сознательная защита от ложной полной сертификации.
