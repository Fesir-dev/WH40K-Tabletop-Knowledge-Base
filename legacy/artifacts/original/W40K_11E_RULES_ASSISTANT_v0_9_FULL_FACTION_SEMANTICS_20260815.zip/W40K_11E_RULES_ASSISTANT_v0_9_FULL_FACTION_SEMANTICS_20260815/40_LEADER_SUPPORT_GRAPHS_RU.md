# Leader / Support graphs

Связи импортированы из interactive MFM. `SUPPORT` сохранён отдельно от `LEADER`: это важно для ограничений состава Attached Unit.

## Адептус Кустодес

- **Aleya** (LEADER) → Prosecutors, Vigilators, Witchseekers
- **Blade Champion** (LEADER) → Custodian Guard, Custodian Guard with Adrasite and Pyrithite Spears, Custodian Wardens, Sagittarum Custodians
- **Knight-Centura** (LEADER) → Prosecutors, Vigilators, Witchseekers
- **Shield-Captain** (LEADER) → Custodian Guard, Custodian Guard with Adrasite and Pyrithite Spears, Custodian Wardens, Sagittarum Custodians
- **Shield-Captain in Allarus Terminator Armour** (LEADER) → Allarus Custodians, Aquilon Custodians
- **Shield-Captain on Dawneagle Jetbike** (LEADER) → Agamatus Custodians, Vertus Praetors
- **Trajann Valoris** (LEADER) → Custodian Guard, Custodian Guard with Adrasite and Pyrithite Spears, Custodian Wardens, Sagittarum Custodians
- **Valerian** (LEADER) → Custodian Guard, Custodian Guard with Adrasite and Pyrithite Spears, Custodian Wardens, Sagittarum Custodians

## Адептус Механикус

- **Cybernetica Datasmith** (SUPPORT) → Kastelan Robots
- **Skitarii Marshal** (SUPPORT) → Hastarii Exterminators, Hastarii Fusiliers, Skitarii Rangers, Skitarii Vanguard
- **Technoarcheologist** (SUPPORT) → Corpuscarii Electro-Priests, Fulgurite Electro-Priests, Hastarii Exterminators, Hastarii Fusiliers, Kataphron Breachers, Kataphron Destroyers, Servitor Battleclade, Skitarii Rangers, Skitarii Vanguard
- **Tech-Priest Dominus** (LEADER) → Corpuscarii Electro-Priests, Fulgurite Electro-Priests, Hastarii Exterminators, Hastarii Fusiliers, Kataphron Breachers, Kataphron Destroyers, Servitor Battleclade, Skitarii Rangers, Skitarii Vanguard
- **Tech-Priest Enginseer** (LEADER) → Corpuscarii Electro-Priests, Fulgurite Electro-Priests, Kataphron Breachers, Kataphron Destroyers, Skitarii Rangers, Skitarii Vanguard
- **Tech-Priest Manipulus** (LEADER) → Corpuscarii Electro-Priests, Fulgurite Electro-Priests, Hastarii Exterminators, Hastarii Fusiliers, Kataphron Breachers, Kataphron Destroyers, Servitor Battleclade, Skitarii Rangers, Skitarii Vanguard

## Демоны Хаоса

- **Bloodmaster** (LEADER) → Bloodletters
- **Changecaster** (LEADER) → Blue Horrors, Pink Horrors
- **Contorted Epitome** (LEADER) → Daemonettes
- **Epidemius** (LEADER) → Plaguebearers
- **Exalted Flamer** (LEADER) → Flamers
- **Fateskimmer** (LEADER) → Screamers
- **Fluxmaster** (LEADER) → Blue Horrors, Pink Horrors
- **Horticulous Slimux** (LEADER) → Beasts of Nurgle
- **Infernal Enrapturess** (LEADER) → Daemonettes
- **Karanak** (LEADER) → Flesh Hounds
- **Poxbringer** (LEADER) → Plaguebearers
- **Skullmaster** (LEADER) → Bloodcrushers
- **Skulltaker** (LEADER) → Bloodletters
- **Sloppity Bilepiper** (LEADER) → Plaguebearers
- **Spoilpox Scrivener** (LEADER) → Plaguebearers
- **Syll’Esske** (LEADER) → Daemonettes
- **Tormentbringer on Exalted Seeker Chariot** (LEADER) → Hellflayer
- **Tranceweaver** (LEADER) → Daemonettes

## Космодесант Хаоса

- **Abaddon the Despoiler** (LEADER) → Chaos Terminator Squad, Chosen
- **Chaos Lord** (LEADER) → Chosen, Legionaries, Nemesis Claw, Red Corsairs Raiders
- **Chaos Lord in Terminator Armour** (LEADER) → Chaos Terminator Squad
- **Chaos Lord with Jump Pack** (LEADER) → Raptors
- **Cultist Firebrand** (LEADER) → Accursed Cultists, Cultist Mob
- **Dark Apostle** (LEADER) → Accursed Cultists, Chosen, Cultist Mob, Legionaries, Nemesis Claw, Red Corsairs Raiders
- **Dark Commune** (LEADER) → Accursed Cultists, Cultist Mob
- **Fabius Bile** (LEADER) → Accursed Cultists, Chosen, Cultist Mob, Legionaries, Red Corsairs Raiders
- **Haarken Worldclaimer** (LEADER) → Raptors
- **Huron Blackheart** (LEADER) → Chaos Terminator Squad, Chosen, Legionaries, Masters of the Maelstrom, Red Corsairs Raiders
- **Kravek Morne** (LEADER) → Chaos Terminator Squad, Mutilators, Obliterators
- **Master of Executions** (SUPPORT) → Chosen, Legionaries, Nemesis Claw, Red Corsairs Raiders
- **Master of Possession** (LEADER) → Chosen, Legionaries, Nemesis Claw, Possessed, Red Corsairs Raiders
- **Masters of the Maelstrom** (SUPPORT) → Chosen, Legionaries, Red Corsairs Raiders
- **Red Corsairs Reave-Captain** (LEADER) → Chosen, Legionaries, Nemesis Claw, Red Corsairs Raiders
- **Sorcerer** (LEADER) → Chosen, Legionaries, Nemesis Claw, Red Corsairs Raiders
- **Sorcerer in Terminator Armour** (LEADER) → Chaos Terminator Squad
- **Traitor Enforcer** (LEADER) → Traitor Guardsmen Squad
- **Warpsmith** (LEADER) → Chosen, Havocs, Legionaries, Nemesis Claw, Red Corsairs Raiders

## Культы генокрадов

- **Abominant** (LEADER) → Aberrants
- **Acolyte Iconward** (LEADER) → Acolyte Hybrids with Autopistols, Acolyte Hybrids with Hand Flamers, Hybrid Metamorphs, Neophyte Hybrids
- **Benefictus** (LEADER) → Acolyte Hybrids with Autopistols, Acolyte Hybrids with Hand Flamers, Hybrid Metamorphs, Neophyte Hybrids
- **Biophagus** (SUPPORT) → Aberrants, Acolyte Hybrids with Autopistols, Acolyte Hybrids with Hand Flamers, Hybrid Metamorphs, Neophyte Hybrids
- **Clamavus** (SUPPORT) → Acolyte Hybrids with Autopistols, Acolyte Hybrids with Hand Flamers, Hybrid Metamorphs, Neophyte Hybrids
- **Jackal Alphus** (LEADER) → Atalan Jackals
- **Locus** (SUPPORT) → Acolyte Hybrids with Autopistols, Acolyte Hybrids with Hand Flamers, Hybrid Metamorphs, Neophyte Hybrids
- **Magus** (LEADER) → Acolyte Hybrids with Autopistols, Acolyte Hybrids with Hand Flamers, Hybrid Metamorphs, Neophyte Hybrids
- **Nexos** (SUPPORT) → Acolyte Hybrids with Autopistols, Acolyte Hybrids with Hand Flamers, Hybrid Metamorphs, Neophyte Hybrids
- **Patriarch** (LEADER) → Purestrain Genestealers
- **Primus** (LEADER) → Acolyte Hybrids with Autopistols, Acolyte Hybrids with Hand Flamers, Hybrid Metamorphs, Neophyte Hybrids

## Имперские Рыцари

- У фракции нет стандартного Leader graph в MFM.

## Тысяча Сынов

- **Ahriman** (LEADER) → Rubric Marines, Tzaangor Enlightened, Tzaangor Enlightened with Greatbows
- **Exalted Sorcerer** (LEADER) → Rubric Marines
- **Exalted Sorcerer on Disc of Tzeentch** (LEADER) → Rubric Marines, Tzaangor Enlightened, Tzaangor Enlightened with Greatbows
- **Infernal Master** (LEADER) → Rubric Marines
- **Thousand Sons Sorcerer** (LEADER) → Rubric Marines
- **Thousand Sons Sorcerer in Terminator Armour** (LEADER) → Scarab Occult Terminators
- **Tzaangor Shaman** (LEADER) → Tzaangor Enlightened, Tzaangor Enlightened with Greatbows, Tzaangors

## Пожиратели Миров

- **Khârn the Betrayer** (LEADER) → Khorne Berzerkers
- **Lord Invocatus** (LEADER) → Eightbound, Exalted Eightbound, Khorne Berzerkers
- **World Eaters Lord on Juggernaut** (LEADER) → Eightbound, Exalted Eightbound, Khorne Berzerkers
- **World Eaters Master of Executions** (LEADER) → Khorne Berzerkers
- **Slaughterbound** (LEADER) → Eightbound, Exalted Eightbound
