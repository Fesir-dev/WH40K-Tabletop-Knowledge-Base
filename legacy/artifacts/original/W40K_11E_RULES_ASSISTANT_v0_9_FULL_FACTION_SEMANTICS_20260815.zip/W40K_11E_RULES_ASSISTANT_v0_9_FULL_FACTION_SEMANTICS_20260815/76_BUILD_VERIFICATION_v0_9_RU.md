# v0.9 — Build Verification

Финальный checkpoint должен проходить:

- project/faction/live/source-freshness validators;
- current MFM and Faction Pack update validators;
- unit-role and Stratagem index validators;
- v0.8 Enhancement/faction-legality validators;
- v0.9 keyword + transport semantic validator;
- executable regressions v0.6/v0.7/v0.8/v0.9;
- Python bytecode compilation;
- project manifest verification;
- SHA256SUMS verification;
- ZIP integrity and unsafe-path check.

Current live source date lock: latest official MFM observed at build time = **22.07.2026**, checked again **15.08.2026**.
