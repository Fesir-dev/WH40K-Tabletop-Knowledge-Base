# Короткие команды помощнику

## `/ruling`
Быстрое решение спорного взаимодействия.

Пример: `/ruling раунд 2, мой Fight phase, Boyz+Warboss, Bodyguard уничтожен до активации; может ли Warboss fight?`

## `/sequence`
Пошагово разложить timing window и порядок simultaneous rules.

## `/turn`
Построить оптимальный план текущего хода с Primary/Secondary, CP и контригрой.

## `/mission`
Показать подготовку, допустимые layouts, scoring checks и риски по коду A–T.

## `/action`
Проверить законность старта/завершения конкретного Action.

## `/damage`
Рассчитать distribution урона, а не только среднее.

## `/list`
Проверить legality, MFM version, DP, Force Disposition, Leaders и battlefield roles.

## `/threat`
Рассчитать normal/advance/charge/threat range с terrain и reserve constraints.

## `/terrain`
Проверить visibility, cover, Hidden/Obscuring/Solid, route и charge geometry по фото/схеме.

## `/source`
Показать применённые источники, версии и что осталось непроверенным.

## Минимальный state block

```yaml
format: Tournament Companion 1.5
mission_code: A
layout: 1
round: 2
active_player: me
phase: Shooting
score: {me: 25, opponent: 20}
cp: {me: 2, opponent: 1}
my_secondaries: []
opponent_secondaries: []
question: "..."
```

## v0.7 executable commands

```bash
python tools/validate_roster_v0_7.py roster.json
python tools/rules_engine_v0_7.py query.json
python tools/query_unit_role_v0_7.py "Custodian Guard" adeptus_custodes
python tools/query_stratagem_v0_7.py "Flawless Construction" adeptus_custodes
python tools/run_rules_engine_regressions_v0_7.py
```
