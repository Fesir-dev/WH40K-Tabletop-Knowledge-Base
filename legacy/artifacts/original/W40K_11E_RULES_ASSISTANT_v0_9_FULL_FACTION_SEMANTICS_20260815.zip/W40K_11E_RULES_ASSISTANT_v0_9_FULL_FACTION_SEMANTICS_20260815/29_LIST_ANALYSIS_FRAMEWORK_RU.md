# Анализ армейского списка

## 1. Legal audit

- faction keywords и army rule;
- detachments и Detachment Points;
- Force Disposition;
- datasheet repetition limits;
- unit sizes и current points;
- enhancements и носители;
- Leader/Bodyguard/Support legality;
- Transports и capacity;
- Reserves план.

## 2. Battlefield roles

Каждому unit присвоить основную и вторичную роли: home objective, midfield holder, action unit, screen, trade piece, anti-infantry, anti-elite, anti-tank, indirect, transport, counter-charge, deep-strike pressure, denial.

## 3. Mission economy

- сколько units могут независимо выполнять Actions;
- сколько OC и durable wounds доступны на центр;
- хватает ли мобильности для Tactical;
- какие units нельзя расходовать из-за Primary;
- насколько detachment/disposition соответствует реальному составу.

## 4. Damage profiles

Проверить не только средний damage, но вероятность:
- снять стандартный транспорт;
- добить wounded target;
- убить 5/10 infantry;
- пережить ответную активацию;
- провалить ключевой charge.

## 5. Matchup plan

Выдать deployment priorities, reserve plan, first-turn/second-turn ветви, CP budget, target priority и три главных ошибки, которых избегать.
