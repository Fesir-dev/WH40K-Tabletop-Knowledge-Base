# Changelog

## v0.1 - 2026-07-10

Initial Core Rules foundation.

Added:

- source hierarchy and update policy;
- full Core Rules section map;
- turn and phase checklist;
- attack/allocation reference;
- movement/charge/fight reference;
- terrain/objective/action reference;
- advanced unit and reserve reference;
- Core Abilities glossary;
- Core Stratagem reference;
- rules and tactical input templates;
- decision tree and tactical framework;
- QA report and known source gaps;
- machine-readable JSON and CSV indexes.

Source:

- Warhammer 40,000 Core Rules, updated 2026-06-01.

## v0.2 — 2026-07-10

See `33_CHANGELOG_v0_2.md`.

## v0.3 — 2026-07-10

See `37_CHANGELOG_v0_3.md`.

## v0.4 — 2026-07-10

See `44_CHANGELOG_v0_4.md`.

## v0.5 LIVE — 2026-08-15

See `48_CHANGELOG_v0_5.md`.

## v0.6 CURRENT — 2026-08-15

See `52_CHANGELOG_v0_6.md` and `53_CURRENT_QUERY_AND_REGRESSION_RU.md`.

Current runtime: MFM 1.2 / Faction Pack 1.1 / Universal Rules Updates v1.0 for the eight user factions, reconciled on 2026-08-15 against current external sources. Historical 2026-07-10 layers are retained only for audit/diff.


## v0.7 RULES ENGINE — 2026-08-15

See `61_CHANGELOG_v0_7.md`. Adds executable core roster legality, current unit-role classification, Leader/Support and Dedicated Transport validation, Enhancement Upgrade semantics, universal interaction caps, source-conflict UNKNOWN gate, and 19-case regression certification.


## v0.8 FACTION LEGALITY — 2026-08-15

See `69_CHANGELOG_v0_8.md`. Adds executable Enhancement target predicates, exact current Dedicated Transport profiles, Supreme Commander/Warlord rules, selected faction-composition rules, army-availability/native-keyword separation, alias-safe name reconciliation and 25-case v0.8 regression certification.

- v0.9 (2026-08-15): current keyword membership evidence, generic/non-Dedicated transport engine, specific Enhancement target precedence, 18 executable semantic regressions.
