> **CURRENT v0.6 NOTE:** основной текст ниже — структурная памятка исходного Faction Pack v1.0. Для текущей игры поверх неё обязательно применяются `rules_updates_v1_1_20260722.json`, MFM v1.2 и Universal Rules Updates v1.0. Exact wording — из официального v1.1 PDF/App.

# Космодесант Хаоса — быстрая памятка по Faction Pack v1.0

**Matched play:** с 20 июня 2026 года.  
**Статус покрытия:** Пакет дополняет Codex и не заменяет базовые datasheets, army rule и старые detachments.

## Detachments

| Detachment | Ключевое правило | Практический архетип | Enhancements | Stratagems |
|---|---|---|---:|---:|
| **Cabal of Chaos** / Кабала Хаоса | Empyric Wellspring | псайкеры и демонические принцы | 2 | 3 |
| **Devotees of Destruction** / Служители разрушения | Rain of Ruin | Havocs и Obliterators, тяжёлая стрельба | 2 | 3 |
| **Murdertalon Raiders** / Налётчики Когтя Убийства | Prey on the Weak | прыжковая пехота и давление через Battle-shock | 2 | 3 |
| **Warpstrike Champions** / Чемпионы варп-удара | Warp Portals | Deep Strike, телепортация и элитный штурм | 4 | 6 |
| **Cult of the Arkifane** / Культ Аркифейна | Soul Forge Boons | демонические машины и техника | 4 | 6 |
| **Creations of Bile** / Творения Байла | Experimental Augmentations | усиленная пехота и мутационные бафы | 4 | 6 |
| **Nightmare Hunt** / Кошмарная охота | Terror Made Manifest | террор, ослабление и охота на надломленные цели | 4 | 6 |
| **Huron’s Marauders** / Мародёры Гурона | Tyrannical Motivation | Красные Корсары, мобильный рейд и захват добычи | 4 | 6 |
| **Renegade Warband** / Ренегатский отряд | Slaves to None, Vendetta, Twisted Doctrine | гибкая ветеранская общевойсковая игра | 4 | 6 |

## Как пользоваться во время партии

1. Сначала определить detachment и точный keyword целевого отряда.
2. Проверить **Rules Updates** этого pack.
3. Проверить актуальный **Balance Dataslate**.
4. Стоимость, размеры отрядов, Leader links, Detachment Points и Force Disposition брать только из актуального **Munitorum Field Manual/app**.
5. При споре открыть страницу, указанную в `detachments.json` или `datasheets.json`.

## Импортированные материалы

- Detachments: 9
- Stratagem cards: 45
- Datasheets/Imperial Armour entries: 10
- Legends entries проиндексировано: 0
- Rules Updates: PDF pages 37–39

## Известные ограничения

- Очки не зашиты в этот слой: это преднамеренно, чтобы устаревшие значения не выдавались как актуальные.
- Для supplement-паков нужен Codex или актуальный app export.
- Извлечение текста из двухколоночных страниц может менять порядок абзацев; визуальный PDF остаётся окончательным источником.
