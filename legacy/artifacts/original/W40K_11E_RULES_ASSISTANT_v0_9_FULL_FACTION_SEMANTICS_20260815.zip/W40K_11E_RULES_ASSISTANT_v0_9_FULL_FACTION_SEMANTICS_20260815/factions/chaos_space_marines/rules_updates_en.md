# Chaos Space Marines - current rules update pointer

Current Faction Pack: **v1.1**, legal from **22 July 2026**.

Local normalized delta: `rules_updates_v1_1_20260722.json`.

Current MFM runtime: `mfm_v1_2_points.json` + `mfm_v1_2_detachments.json`.

Historical June text is preserved in `rules_updates_v1_0_202606.md`.

Authority: current official Games Workshop Faction Pack/app/MFM. Wahapedia and 40k.app are secondary cross-checks only.
