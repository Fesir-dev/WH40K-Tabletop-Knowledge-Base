# Chaos Space Marines — Rules Updates

Источник: Faction Pack v1.0, PDF pages 37–39.

Ниже сохранён извлечённый текст. При сомнении сверять визуально с PDF.

```text
[PDF PAGE 37]
CHAOS SPACE MARINES
RULES UPDATES
This section presents updates and clarifications to your faction’s rules, designed to improve the gaming experience for all players.
Changes applied after the first iteration of this Faction Pack will be highlighted in red.
UPDATES
CHAOS CULT DETACHMENT
Chaos Cult Detachment, Keywords Section
Change to:
‘TRAITOR GUARDSMEN SQUAD units from your army gain the
BATTLELINE keyword.’
Warped Foresight Enhancement
Change to:
‘DARK APOSTLE or DAMNED model only. While the bearer is leading a
unit with the Scouts 6” ability, every model in the bearer’s unit has the
Scouts 6” ability.
DECEPTORS DETACHMENT
Relentless Pursuit Stratagem, Target Section
Change 9" to 8".
Falsehood Enhancement, third sentence
Change to:
‘If you do, in one of your Movement phases, you can select one model
in a friendly LEGIONARIES or CHOSEN unit that has two or more models
remaining and is on the battlefield (excluding Attached units).’
DREAD TALONS DETACHMENT
Screaming Descent Stratagem, Effect section
Change to:
'Set your unit up anywhere on the battlefield that is more than 6"
horizontally away from all enemy units, but until the end of the turn,
it is not eligible to declare a charge. Then select one enemy INFANTRY
or MOUNTED unit within 9" of and visible to your unit: that unit makes a
battle‑shock roll.’
PACTBOUND ZEALOTS DETACHMENT
Marks of Chaos Detachment Rule, Restrictions Section
Add an additional bullet point:
‘• A unit can only embark within (or start the battle embarked within)
aTRANSPORT if both of those units share the same keyword from the
list above.’
Restrictions Section
Change to:
‘A CHARACTER/EPIC HERO unit can only be attached to a unit if both units
share the same keyword from the list above.'
RENEGADE RAIDERS DETACHMENT
Unfailingly Obdurate Stratagem, Effect Section
Change to:
‘Until the attacking unit has finished making its attacks, each time an
attack targets your unit, worsen the Armour Penetration characteristic
of that attack by 1.’
SOULFORGED WARPACK DETACHMENT
Feeding Frenzy Stratagem, Target Section
Change to: ‘One HERETIC ASTARTES DAEMON VEHICLE or VASHTORR THE
ARKIFANE unit from your army that is within Engagement Range of that
enemy unit.’
Unstoppable Rampage Stratagem, Target Section
Change to: ‘One HERETIC ASTARTES DAEMON VEHICLE or VASHTORR THE
ARKIFANE unit from your army that has not been selected to move or
charge this phase.’
Predatory Pursuit Stratagem, Target Section
Change to: ‘One HERETIC ASTARTES DAEMON VEHICLE or VASHTORR THE
ARKIFANE unit from your army that is within 8” of that enemy unit and
not within Engagement Range of one or more enemy units.’
VETERANS OF THE LONG WAR DETACHMENT
Eager For Vengeance Enhancement
Change to:
‘HERETIC ASTARTES model only (excluding DAMNED models). The bearer’s
unit is eligible to shoot and declare a charge in a turn in which it Fell
Back. Each time a model in the bearer’s unit makes an attack that
targets your focus of hatred, if the bearer’s unit Fell Back this turn, add 1
to the Hit roll, and each time you select your focus of hatred as a target
of that unit’s charge, add 1 to the Charge roll.’
Bringers of Despair Stratagem

▪CP Cost: change to '1CP'.

▪When section: change to 'Fight phase.'
Millennia of Experience Stratagem, Target Section
Change 9" to 8".
Contemptuous Disregard Stratagem, Effect Section
Change to:
‘Until the attacking unit has finished making its attacks, each time an
attack targets your unit, worsen the Armour Penetration characteristic
of that attack by 1.’
DATASHEETS
Master of Executions, Core Abilities Section
Remove 'Leader', add 'Support'.
Chaos Land Raider, Chaos Predator Annihilator, Chaos Predator
Destructor, Chaos Rhino, Chaos Vindicator, Khorne Lord of Skulls,
Noctilith Crown – Keywords Section
Add 'FRAME'.
Heldrake

▪Profile: Change M to 12" and OC to '-'.

▪Keywords: Remove 'AIRCRAFT'.

[PDF PAGE 38]
Abaddon the Despoiler, Dark DestinyAbility
Change to:
‘Each time this model’s unit makes a Dark Pact and does not fail the
resulting leadership roll, if the result of that roll was 7+, you gain 1CP.’
Accursed Cultists, Howling Horde Ability
Change to:
'In your opponent's Shooting phase, when an enemy unit has shot, if
a model from this unit was destroyed as a result of those attacks, this
unit can make a surge move of up to D6".'
Cypher, Agent of Discord Ability
Change to:
'Agent of Discord: Once per turn, when your opponent targets a unit
from their army within 12” of this model with a stratagem, you can use
this ability. If you do increase the CP cost of tht use of that stratagem
by 1CP.'
Fabius Bile, Chirurgeon Ability
Change to:
‘The first time this unit’s FABIUS BILE model is destroyed, at the end
of the phase, roll one D6: on a 2+, set it back up on the battlefield, as
close as possible to where it was destroyed and not within Engagement
Range of any enemy models, with its full wounds remaining.'
Chaos Lord in Terminator Armour, Keywords Section
Add ‘CHAOS LORD’.
Chaos Rhino, Wargear Options
Change the second bullet point to:
‘• This model can be equipped with 1 havoc launcher or can replace 1
combi-bolter with 1 havoc launcher.’
Chaos Predator Annihilator, Annihilator Ability
Change to:
‘Each time a ranged attack made by this model is allocated to a MONSTER
or VEHICLE model, you can re‑roll the Damage roll.’
Chaos Predator Destructor, Melee Weapons, Armoured Tracks
Change WS to ‘4+’.
Heretic Astartes Daemon Prince, Abilities Section
Add the following:
‘Lord of Chaos: While this model is within 3" of a friendly HERETIC
ASTARTES INFANTRY unit, this model has Lone Operative.’
Lord Discordant on Helstalker• Move characteristic: Change to 14".

▪Invulnerable save: Change to 4+.

▪Corrupt Machine Spirits ability: Change to ‘At the start of your
Shooting phase, select one visible enemy VEHICLE unit within 12"
of this model and roll one D6: on a 2-3, that enemy unit suffers D3
mortal wounds; on a 4-5, that enemy unit suffers 3 mortal wounds;
on a 6, that enemy unit suffers D3+3 mortal wounds.’

▪Spirit Thief ability: Change to ‘At the start of your Shooting phase,
select one visible enemy VEHICLE unit. Until the end of the phase,
each time a friendly HERETIC ASTARTESmodel makes an attack that
targets that unit, re‑roll a Wound roll of 1.’

▪Impaler chainglaive weapon profile: change to:
Impaler Chainglaive [LANCE]
RANGE
A
WS
S
AP
D
Melee
5
2+
8
-3
3
Obliterators, Warp Rift Firepower Ability
Change to:
‘Warp Rift Firepower (Once per battle, per unit): In your Shooting
phase, when this unit is selected to shoot, you can use this ability. If you
do, this unit's ranged attacks have [INDIRECT FIRE].'
Vashtorr the Arkifane

▪Abilities section: add ‘Indentured Daemon Engines: While this
model is within 3" of one or more friendly DAEMON VEHICLE units, this
model has the Lone Operative ability.’

▪Reorder Reality ability: change to 'Each time an enemy unit within
18" of this model targets this model, subtract 1 from the Hit roll and,
until the end of the phase, that enemy unit’s ranged weapons have
the [HAZARDOUS] ability.’

▪Unholy Mechanisms ability: change to 'While a friendly DAEMON
VEHICLE unit is within 6" of this model, add 2 to the Strength
characteristic of weapons equipped by models in that unit.’

▪Vashtorr’s hammer weapon profile: change to:
Vashtorr's Hammer - Strike
[ANTI-VEHICLE 4+, DEVASTATING WOUNDS]
RANGE
A
WS
S
AP
D
Melee
6
2+
14
-3
3
Vashtorr's Hammer - Sweep
[ANTI-VEHICLE 4+, DEVASTATING WOUNDS]
RANGE
A
WS
S
AP
D
Melee
12
2+
8
-1
2
Warp Talons, Warp Strike Ability
Change to:
‘At the end of the Fight phase, if this unit destroyed one or more enemy
units this phase and is not within Engagement Range of one or more
enemy units, you can remove this unit from the battlefield and place it
into Strategic Reserves.’
Chaos Rhino, Transport Section
Change to:
‘This model has a transport capacity of 12 HERETIC ASTARTES INFANTRY
models. It cannot transport TERMINATOR, JUMP PACK, MUTILATORS,
OBLITERATORS or POSSESSED models.’
Chaos Land Raider, Transport Section
Change to:
‘This model has a transport capacity of 12 HERETIC ASTARTES INFANTRY
models (excluding OBLITERATOR and JUMP PACK models). Each
POSSESSED, MUTILATORS and TERMINATOR model takes up the space of
2 models.’
Traitor Guardsmen Squad,Twisted Defence Force Ability
Change to:
'While this unit is within range of an objective, this unit has +1 Sv
against ranged attacks.'

[PDF PAGE 39]
FAQS
Q: If I use the Cults of the Dark Gods rule to add Plague Marines to my
Chaos Space Marines army, does the Plague Marines’ Infused with the
Blessings of Nurgle ability have any effect?
A: No
Q: When using the Soul Link Enhancement, can the bearer use a
datasheet ability it gains as a result even if that ability has already been
used by another CHARACTER model as many times as its restrictions
allow (e.g. ‘once per battle’, ‘once per phase’)?
A: Yes.
Q: When using the Soul Link Enhancement, can I select a CHARACTER
model from my army that is not on the battlefield?
A: Yes.
Q: Can my CHARACTER with the Soul Link Enhancement use that
Enhancement while it is in Strategic Reserves?
A: Yes.
Q: When replacing the datasheet abilities of the bearer of the Soul Link
Enhancement with those of the selected CHARACTER model, does this
include Core and Faction abilities?
A: Yes.
Q: When replacing the datasheet abilities of the bearer of the Soul Link
Enhancement with those of the selected CHARACTER model, does this
include which units the bearer can be attached to?
A: No.
Q: If I am using the Veterans of the Long War Detachment, can I select a
unit embarked within a TRANSPORT to be my focus of hatred?
A: Yes.
Q: For the Opportunistic Raiders Stratagem, is a unit that did not fight
this phase an eligible target for that Stratagem, provided it was eligible
to fight at one point during the phase?
A: Yes.
Q: Can I use the Opportunistic Raiders Stratagem to Fall Back with a unit
of Warp Talons, then use that unit’s Warp Strike ability to place it into
Strategic Reserves?
A: If that Warp Talons unit destroyed one or more units this phase, yes;
otherwise, no.
Q:For the Warp Talons’ Warp Strike ability, is a unit that did not fight this
phase eligible to use that ability, provided it was eligible to fight at one
point during the phase?
A: No.
Q: When is the model destroyed by the Traitor Enforcer’s Brutal Example
ability removed?
A: Before resolving the Fire Overwatch Stratagem with that unit.
Q: When I target a unit with the Fire Overwatch Stratagem, can that unit
make a Dark Pact?
A: Yes, as the unit is selected to shoot.
Q: Can I select a unit to shoot when there are no eligible targets so that
unit can make a Dark Pact?
A: No.
Q: Does Fabius Bile’s Enhanced Warriors ability apply if Fabius starts the
battle as part of an Attached unit inside a transport?
A: Yes.
Q: When I replace the datasheet abilities of the bearer of the Soul Link
Enhancement, do persisting effects that were gained from the replaced
abilities continue to apply to the bearer of the Soul Link Enhancement?
A: No.
```
