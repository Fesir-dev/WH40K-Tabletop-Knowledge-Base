# Культы генокрадов — быстрая проверка ростера и партии

**Snapshot:** MFM v1.2 / Faction Pack v1.1 / Universal Rules Updates v1.0  
**Проверено:** 2026-08-15

## Перед построением списка

1. Выбрать detachment или сочетание detachments.
2. Сложить Detachment Points.
3. Проверить повторяющиеся `unique_tags`.
4. Сверить Force Disposition каждого detachment.
5. Посчитать units с учётом цены соответствующей копии.
6. Добавить платные weapon options.
7. Добавить enhancements из правильного detachment.
8. Проверить Leader/Support links.
9. Наложить Universal Rules Updates v1.0 и faction-specific v1.1 updates; historical Balance Dataslate v3.3 не применять как самостоятельный 11e current override.
10. Перед турниром повторно открыть официальный MFM/App и current Faction Pack.

## Игровой профиль

Армия пространства и повторного ввода: Resurgence points, Cult Ambush markers и дешёвые mission pieces.

### Приоритеты
- Считать RP как ограниченный ресурс ещё при построении списка.
- Marker ставить с учётом следующей Movement phase противника.
- Заранее решить, какие отряды выгодно возвращать.

### Типичные ловушки
- Cult Ambush нельзя Rapid Ingress.
- PURESTRAIN и HOSTS unique-tags ограничивают сочетания detachment.

## Статистика импортированного live-слоя

- Units with points: 24
- Detachments: 9
- Enhancements: 30
- Leader/Support links: 11
- Dataslate checklist entries: 8
