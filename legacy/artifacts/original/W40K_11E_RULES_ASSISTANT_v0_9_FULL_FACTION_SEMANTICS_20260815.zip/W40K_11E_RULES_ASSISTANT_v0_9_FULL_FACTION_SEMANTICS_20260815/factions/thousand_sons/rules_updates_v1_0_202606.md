# Thousand Sons — Rules Updates

Источник: Faction Pack v1.0, PDF pages 9–11.

Ниже сохранён извлечённый текст. При сомнении сверять визуально с PDF.

```text
[PDF PAGE 9]
THOUSAND SONS
RULES UPDATES
This section presents updates and clarifications to your faction’s rules, designed to improve the gaming experience for all players.
Changes applied after the first iteration of this Faction Pack will be highlighted in red.
UPDATES
ARMY RULES
Cabal of Sorcerers
Change first paragraph to:
‘If your Army Faction is THOUSAND SONS, at the start of your Shooting
phase, one or more models from your army with this ability can
attempt Rituals from those listed on the right. To do so, select one
model from your army with this ability that has not yet attempted a
Ritual this turn and select one Ritual no model from your army has
attempted to manifest this turn, then take a Psychic test for that model
by following the sequence below.’
Destiny’s Ruin (Psychic)
Change to:
‘Select one enemy unit within 24" of and visible to the manifesting
model. Until the end of the phase, each time a THOUSAND SONS or
SCINTILLATING LEGIONS model from your army makes an attack that
targets that unit, re-roll a Hit roll of 1. If the Psychic test result for this
Ritual was 10+, you can re-roll the Hit roll instead.’
Temporal Surge (Psychic)
Change to:
‘Select one friendly THOUSAND SONS or SCINTILLATING LEGIONS unit that
is not within Engagement Range of one or more enemy units and is
within 24" of and visible to the manifesting model. That unit can make
a Normal move of up to D6". If the Psychic test result for this Ritual
was 10+, that unit can make a Normal move of up to 6" instead. In
either case, until the end of the turn, that unit is not eligible to declare
a charge.’
Twist of Fate (Psychic)
Change to:
‘Select one enemy unit within 24" of and visible to the manifesting
model. Until the end of the phase, each time a THOUSAND SONS or
SCINTILLATING LEGIONS model from your army makes an attack that
targets that unit, improve the Armour Penetration characteristic of that
attack by 1. If the Psychic test result for this Ritual was 12+, improve the
Armour Penetration characteristic of that attack by 2 instead.’
CHANGEHOST OF DECEIT DETACHMENT
Ethereal Phantasm Stratagem, Target Section
Change 9" to 8".
Chronosorcerous Bleed Stratagem
Change to:
WHEN: Start of your opponent's Charge phase.
TARGET: One friendly unengaged THOUSAND SONS PSYKER/
SCINTILLATING LEGIONS unit.
EFFECT: Select one visible enemy unit within 12" of your unit.
When that enemy unit declares a charge, that enemy unit has -1 to
charge rolls.
GRAND COVEN DETACHMENT
Incandaeum Enhancement
Change to:
‘EXALTED SORCERER model only. Once per battle, when selecting a
Ritual for the bearer to attempt, you can select Doombolt, even if a
model from your army have already attempted to manifest that Ritual
this phase.
WARPFORGED CABAL DETACHMENT
Hex-marked Armour Stratagem, Effect Section
Change to:
‘Until the attacking unit has finished making its attacks, each time an
attack targets your unit, worsen the Armour Penetration characteristic
of that attack by 1.’
Ensorcelled Infusion Stratagem, Target Section
Change to:
‘One THOUSAND SONS VEHICLE unit from your army that has not been
selected to shoot this phase, that is within 6" of one or more friendly
THOUSAND SONS PSYKER units.’
Ensorcelled Infusion Stratagem, CP Cost
Change to '2CP'.

[PDF PAGE 10]
WARPMELD PACT DETACHMENT
Twisted Mirage Stratagem, Effect Section
Change 3" to 6".
Warpmeld Sacrifice Detachment Rule
Change to:
‘Each time an enemy unit is selected to shoot or fight and one or more
TZEENTCH MUTANT INFANTRY or TZEENTCH MUTANT MOUNTED units from
your army are selected as a target of one or more of those attacks, each
of those TZEENTCH MUTANT units can make a Warpmeld Sacrifice. If it
does, until the end of the phase, each time an attack targets that unit,
subtract 1 from the Wound roll. At the end of the phase, that TZEENTCH
MUTANT unit suffers D3 mortal wounds.
Each time a TZEENTCH MUTANT INFANTRY or TZEENTCH MUTANT MOUNTED
unit from your army is selected to shoot or fight, before selecting its
targets, that unit can make a Warpmeld Sacrifice. If it does, until the
end of the phase, each time a model in that unit makes an attack, add 1
to the Wound roll. At the end of the phase, that TZEENTCH MUTANT unit
suffers D3 mortal wounds.’
DATASHEETS
Heldrake

▪Profile: Change M to 12" and OC to '-'.

▪Keywords: Remove 'AIRCRAFT'.
Daemon Prince of Tzeentch with Wings, Aetherstride Ability
Change to:
‘In your Movement phase, when this model is set up on the battlefield
using the Deep Strike ability, it can perform an aetherstride. If it does:

▪It can be set up anywhere on the battlefield that is more than 6"
horizontally away from all enemy units.

▪Until the end of the turn, its Dark Blessing has the
[SUSTAINED HITS D3] ability.

▪Until the end of the turn, it is not eligible to declare a charge.’
Chaos Rhino, Core Abilities
Add ‘Firing Deck 2’.
Chaos Vindicator, Profile
Change M to 9".
Flamers, Profile
Change Ld to 7+.
Infernal Master, Ranged Weapons, inferno bolt pistol
Add ‘[PISTOL]’.
Kairos Fateweaver, Ranged Weapons, Infernal Gateway
Change profiles to:
Infernal Gateway - Witchfire
[BLAST, INDIRECT FIRE, PSYCHIC]
RANGE
A
BS
S
AP
D
24"
D6+3
2+
9
-2
D3
Infernal Gateway - Focused Witchfire
[BLAST, INDIRECT FIRE, HAZARDOUS, PSYCHIC]
RANGE
A
BS
S
AP
D
24"
D6+6
2+
9
-2
3
Mutalith Vortex Beast, Immaterial Flare Ability
Change to:
‘While a friendly THOUSAND SONS PSYKER model is within 6" of this
model, each time that model Channels the Warp (pg 67), add 1 to the
Psychic test result. This is not cumulative with any other modifiers to
the Psychic test result.
Lord of Change, Ranged Weapons

▪Change the Bolt of Change profiles to:
Bolt of Change - Witchfire [PSYCHIC]
RANGE
A
BS
S
AP
D
18"
9
2+
9
-1
1
Bolt of Change - Focused Witchfire [HAZARDOUS, PSYCHIC]
RANGE
A
BS
S
AP
D
18"
9
2+
9
-2
3

▪Change the rod of sorcery profile to:
Rod of Sorcery [PSYCHIC]
RANGE
A
BS
S
AP
D
18"
6
2+
8
-1
2
Maulerfiend, Snarling Protector Ability
Change to:

▪'You can target this unit with the Heroic Intervention stratagem,
regardless of any other uses of that stratagem this phase. If you do:

▫That use is -1 CP.

▫That use does not prevent any uses of that stratagem on other
units this phase.

▫When this unit declares a charge, If a friendly engaged PSYKER
unit is within 12" of this unit, you can use this part of this ability.
If you do:
•	 This unit can re-roll that charge roll.
•	 This unit must end that charge move engaged with an enemy
unit engaged with that friendly PSYKER unit.
Screamers, Profile
Change Ld to 7+.
Sekhetar Robots, Prophetic Sentinels Ability
Change to:
'Once per turn, when you target this unit with the Fire Overwatch/
Heroic Intervention stratagem, that use is -1 CP.'
Sorcerer in Terminator Armour, Marked by Fate Ability
Change to:
‘At the start of your Shooting phase, select one enemy unit that is visible
to this PSYKER model. Until the end of the phase, each time a model
in this unit makes an attack that targets that enemy unit, add 1 to the
Hit roll.’
Tzaangor Enlightened with Fatecaster Greatbows,
Malign Trickery Ability
Change to:
'In your opponent's Movement phase, if an enemy unit ends a move
within 8" of this unit, if this unit is not within Engagement Range of one
or more enemy units, this unit can make a Normal move of up to D6".'
Chaos Land Raider, Chaos Predator Annihilator, Chaos Predator
Destructor, Chaos Rhino and Chaos Vindicator – Keywords Section
Add 'FRAME'.

[PDF PAGE 11]
FAQS
Q: When using the Touched by Tzeentch Stratagem in the Warpmeld
Pact Detachment, do I have to declare if my unit will shoot or charge
after Advancing as soon as I use the Stratagem?
A: No, you may decide later in the turn.
Q: When going second, can a Tzaangor unit that started the game
on the battlefield and was placed into Strategic Reserves by its
Ambushing Hunters ability then arrive during my first turn using the
Twisted Mirage Stratagem?
A: No.
Q: Can the Exalted Sorcerer on Disk of Tzeentch and the Tzaangor
Shaman lead Tzaangor Enlightened with fatecaster greatbows?
A: Yes.
Q: While using the Rubricae Phalanx Detachment, if I attach a
CHARACTER to a unit selected using the Risen Rubricae Enhancement,
does that CHARACTER also gain the Infiltrators ability?
A: Yes.
Q: When using the Cabal of Sorcerers army rule, do I have to choose
whether to Channel the Warp before rolling any dice?
A: No.
Q: When using the Cabal of Sorcerers army rule, if I roll one or more
doubles or triples, does my model only suffer D3 mortal wounds if I
chose to Channel the Warp?
A: Yes.
Q: Do I need to sequence all of my Cabal of Sorcerers Rituals at the start
of my Shooting phase?
A: No, you just pick a model with the Cabal of Sorcerers rule, pick a
Ritual to manifest, and attempt it, then repeat the process until you
have run out of models or Rituals or both.
```
