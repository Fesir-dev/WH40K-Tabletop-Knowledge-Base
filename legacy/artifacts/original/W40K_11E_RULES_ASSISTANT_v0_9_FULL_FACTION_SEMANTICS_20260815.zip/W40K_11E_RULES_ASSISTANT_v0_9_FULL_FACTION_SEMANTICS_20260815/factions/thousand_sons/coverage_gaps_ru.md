# Пробелы покрытия — v0.6 CURRENT

- Фракция: **Тысяча Сынов** (`thousand_sons`).
- Coverage type: `supplement`.
- MFM **v1.2 / official update 22.07.2026**: reconciled локально; points, unit-size bands, duplicate-copy taxes, enhancements, DP и Force Dispositions доступны current runtime.
- Faction Pack **v1.1 / legal 22.07.2026**: официальный PDF проверен; semantic delta хранится в `rules_updates_v1_1_20260722.json`.
- Leader/Support local graph переведён в current namespace; exact live wording официального MFM/App имеет приоритет.
- Universal Rules Updates **v1.0** применяются как глобальный override.
- App-only wording и будущие hotfixes остаются live-source-first.
- Если Faction Pack является supplement, локальный пакет не заменяет полный Codex/App corpus.

Historical `*_20260710` / `*_v1_0_*` файлы сохранены для diff и не должны использоваться как текущие.
