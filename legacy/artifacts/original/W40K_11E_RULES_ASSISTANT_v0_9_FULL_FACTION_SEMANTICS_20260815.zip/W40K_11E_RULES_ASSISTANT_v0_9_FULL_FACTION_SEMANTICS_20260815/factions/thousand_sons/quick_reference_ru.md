> **CURRENT v0.6 NOTE:** основной текст ниже — структурная памятка исходного Faction Pack v1.0. Для текущей игры поверх неё обязательно применяются `rules_updates_v1_1_20260722.json`, MFM v1.2 и Universal Rules Updates v1.0. Exact wording — из официального v1.1 PDF/App.

# Тысяча Сынов — быстрая памятка по Faction Pack v1.0

**Matched play:** с 20 июня 2026 года.  
**Статус покрытия:** Пакет дополняет Codex и не заменяет базовые datasheets, army rule и старые detachments.

## Detachments

| Detachment | Ключевое правило | Практический архетип | Enhancements | Stratagems |
|---|---|---|---:|---:|
| **Ritual of Regeneration** / Ритуал регенерации | Sorcerous Invigoration | исцеление псайкеров через ритуалы | 2 | 3 |
| **Sekhetar Cohort** / Когорта Секхетар | Ensorcelled Animus | роботы Секхетар и поддержка псайкеров | 2 | 3 |
| **Servants of Change** / Слуги Перемен | All-seeing Mutant Hordes | Тзаангоры и мутанты | 2 | 3 |
| **Hexwarp Thrallband** / Гексварп-траллбанда | Flow of Magic | контроль Flow of Magic и телепортационная магия | 4 | 6 |

## Как пользоваться во время партии

1. Сначала определить detachment и точный keyword целевого отряда.
2. Проверить **Rules Updates** этого pack.
3. Проверить актуальный **Balance Dataslate**.
4. Стоимость, размеры отрядов, Leader links, Detachment Points и Force Disposition брать только из актуального **Munitorum Field Manual/app**.
5. При споре открыть страницу, указанную в `detachments.json` или `datasheets.json`.

## Импортированные материалы

- Detachments: 4
- Stratagem cards: 15
- Datasheets/Imperial Armour entries: 1
- Legends entries проиндексировано: 0
- Rules Updates: PDF pages 9–11

## Известные ограничения

- Очки не зашиты в этот слой: это преднамеренно, чтобы устаревшие значения не выдавались как актуальные.
- Для supplement-паков нужен Codex или актуальный app export.
- Извлечение текста из двухколоночных страниц может менять порядок абзацев; визуальный PDF остаётся окончательным источником.
