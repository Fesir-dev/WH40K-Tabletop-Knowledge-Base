# Имперские Рыцари — быстрая проверка ростера и партии

**Snapshot:** MFM v1.2 / Faction Pack v1.1 / Universal Rules Updates v1.0  
**Проверено:** 2026-08-15

## Перед построением списка

1. Выбрать detachment или сочетание detachments.
2. Сложить Detachment Points.
3. Проверить повторяющиеся `unique_tags`.
4. Сверить Force Disposition каждого detachment.
5. Посчитать units с учётом цены соответствующей копии.
6. Добавить платные weapon options.
7. Добавить enhancements из правильного detachment.
8. Проверить Leader/Support links.
9. Наложить Universal Rules Updates v1.0 и faction-specific v1.1 updates; historical Balance Dataslate v3.3 не применять как самостоятельный 11e current override.
10. Перед турниром повторно открыть официальный MFM/App и current Faction Pack.

## Игровой профиль

Очень низкое число корпусов; каждая потеря резко меняет контроль карты и доступность действий.

### Приоритеты
- Разделить big Knights и Armigers по задачам до deployment.
- Не забывать sequencing ограничений Dataslate: not selected to move/shoot/fight.
- Учитывать duplicate price bands для почти всех больших Knights.

### Типичные ловушки
- ARMIGERS-tag конфликтует между двумя специализированными detachments.
- Rapid-fire battle cannon Knight Crusader оплачивается отдельно.

## Статистика импортированного live-слоя

- Units with points: 22
- Detachments: 8
- Enhancements: 26
- Leader/Support links: 0
- Dataslate checklist entries: 4
