# Adeptus Mechanicus — Rules Updates

Источник: Faction Pack v1.0, PDF pages 17–18.

Ниже сохранён извлечённый текст. При сомнении сверять визуально с PDF.

```text
[PDF PAGE 17]
ADEPTUS MECHANICUS
RULES UPDATES
This section presents updates and clarifications to your faction’s rules, designed to improve the gaming experience for all players.
Changes applied after the first iteration of this Faction Pack will be highlighted in red.
UPDATES
ARMY RULES
Doctrina Imperatives
Change Protector Imperative to:

▪Ranged weapons equipped by models in this unit have the
[HEAVY] ability.

▪Improve the Ballistic Skill characteristic of ranged weapons equipped
by models in this unit by 1.

▪Each time a melee attack targets this unit, if this unit has the
BATTLELINE keyword and/or it is within 6" of one or more friendly
ADEPTUS MECHANICUS BATTLELINE units, subtract 1 from the Hit roll.'
Change Conqueror Imperative to:

▪Ranged weapons equipped by models in this unit have the
[ASSAULT] ability.

▪Improve the Weapon Skill characteristic of melee weapons equipped
by models in this unit by 1.

▪Each time a model in this unit makes an attack, if this unit has the
BATTLELINE keyword and/or it is within 6" of one or more friendly
ADEPTUS MECHANICUS BATTLELINE units, improve the Armour
Penetration characteristic of that attack by 1.
COHORT CYBERNETICA DETACHMENT
Cyber-psalm Programming Detachment Rule
Change to:
‘Add 2" to the Move characteristic of models in LEGIO CYBERNETICA units
from your army. In addition, unless that unit is Battle‑shocked, add 1 to
the Objective Control characteristic of models in that unit.’
SKITARII HUNTER COHORT DETACHMENT
Veiled Hunter Enhancement
Change to:
‘SKITARII MARSHAL model only. After both players have deployed their
armies, you can select up to three SKITARII INFANTRY units from your
army and redeploy all of those units. When doing so, any of those units
can be placed into Strategic Reserves, regardless of how many units are
already in Strategic Reserves.’
DATASHEETS
Skitarii Marshal, Core Abilities section
Remove 'Leader', add 'Support'.
Technoarcheologist, Core Abilities section
Remove 'Leader', add 'Support'.
Skorpius Disintegrator, Skorpius Dunerider – Keywords section
Add the 'FRAME' keyword.
Archaeopter Fusilave, Archaeopter Stratoraptor – Core Abilities
section
Remove 'Hover'.
Archaeopter Fusilave, Archaeopter Stratoraptor – Profiles
Change M and OC to '-'.
Archaeopter Transvector
• Profile: Change M to 14".
• Keywords: Remove 'AIRCRAFT'.
Archaeopter Fusilave, Bomb Rack Ability
Change to:
'At the end of your opponent’s Fight phase, select one visible enemy
unit (excluding Lone Operative units) within 24" of this unit, and roll six
D6 for that unit: for each 4+, that unit suffers 1 mortal wound.'
Archaeopter Transvector, Aerial Deployment Ability
Change to:
'In your first Movement phase, this unit can make an ingress move.'
Belisarius Cawl

▪Move characteristic: change to 8".

▪Canticles of the Omnissiah Ability
Change to:
‘At the start of your Command phase, select one of the abilities in
the Canticles of the Omnissiah section. Until the start of your next
Command phase, this model has that ability.’

▪Invocation of Machine Vengeance Ability
Change to:
‘At the start of your Command phase, select one unit from your
opponent’s army. Until the start of your next Command phase, that
enemy unit is your Machine Vengeance target. Each time a model in
a friendly ADEPTUS MECHANICUS unit makes an attack that targets your
Machine Vengeance target, you can re-roll the Hit roll.’

▪Mantra of Discipline Ability
Change to:
‘This model has the BATTLELINE keyword and has the following
ability:Binharic Courage (Aura): While a friendly ADEPTUS
MECHANICUS unit is within 6" of this model, add 1 to the Objective
Control characteristic of models in that unit and each time you take a
Battle-shock or Leadership test for that unit, add 1 to that test.’

▪Shroudpsalm (Aura) Ability
Change to:
‘While a friendly ADEPTUS MECHANICUS unit is within 6" of this model,
that unit has the Stealth ability.’

▪Solar atomiser weapon: Change A to '3' and D to 'D6'.

[PDF PAGE 18]
Skitarii Marshal, Servo-skull Uplink Ability
Change to:
‘Once per battle, at the start of any phase, you can select one friendly
SKITARII unit that is Battle-shocked and within 6" of this model. That
unit is no longer Battle-shocked.’
Skorpius Dunerider, Core Abilities
Add ‘Firing Deck 2’.
Onager Dunecrawler

▪Daedalus missile launcher: Change A to '2'.

▪Eradication beamer: Change A to '3D3' and S to '10'.

▪Neutron laser: Change A to '3' and D to 'D6+2'.

▪Twin Onager heavy phosphor blaster: Change A to '12'.

▪Add the following ability:
'Scuttling Walker: Each time this model makes a Normal, Advance or
Fall Back move, it can move through friendly MONSTER and VEHICLE
models and sections of terrain features that are 4" or less in height.'
Ironstrider Ballistarii

▪Twin cognis autocannon: Change A to '4'.

▪Twin cognis lascannon: Change A to '2' .
Serberys Raiders, Tactica Obliqua Ability
Change to:'In your opponent's Movement phase, if an enemy unit ends a
move within 8” of this unit, if this unit is not within Engagement Range
of one or more enemy units, it can do one of the following:

▪Make a Normal move of up to D6"

▪Make a Normal move of up to 6" provided every model in this unit
ends that move wholly within 6" of one or more friendly ADEPTUS
MECHANICUS BATTLELINE units.'
Sicarian Infiltrators, Melee Weapons

▪Power weapon: Change A to '4'.

▪Taser goad: Change A to '3' and AP to '-1'.
Sicarian Ruststalkers, Melee Weapons

▪Transonic blades: Change A to '5' and S to '5'.

▪Transonic blades and chordclaw: Change A to '5' and S to '5'.

▪Transonic razor and chordclaw: Change A to '3' and S to '5'.
Skorpius Disintegrator, Ferrumite Cannon
Change D to 'D6+1'.
Cybernetica Datasmith, Core Abilities section
Remove 'Leader', add 'Support'.
FAQS
Q: If I target a unit with the Auto-divinatory Targeting Stratagem while
the Protector Imperative is active for my army, in what order are the
Ballistic Skill modifiers applied?
A: The Ballistic Skill characteristic of ranged weapons equipped by
models in that unit is first changed to 3+ by the Stratagem, then
improved by 1 by the Protector Imperative, for a final result of 2+
(assuming no other modifiers apply).
```
