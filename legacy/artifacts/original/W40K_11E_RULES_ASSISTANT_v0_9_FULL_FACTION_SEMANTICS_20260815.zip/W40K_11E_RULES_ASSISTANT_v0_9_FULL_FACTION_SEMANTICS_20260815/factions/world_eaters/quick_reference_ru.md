> **CURRENT v0.6 NOTE:** основной текст ниже — структурная памятка исходного Faction Pack v1.0. Для текущей игры поверх неё обязательно применяются `rules_updates_v1_1_20260722.json`, MFM v1.2 и Universal Rules Updates v1.0. Exact wording — из официального v1.1 PDF/App.

# Пожиратели Миров — быстрая памятка по Faction Pack v1.0

**Matched play:** с 20 июня 2026 года.  
**Статус покрытия:** Пакет дополняет Codex и не заменяет базовые datasheets, army rule и старые detachments.

## Detachments

| Detachment | Ключевое правило | Практический архетип | Enhancements | Stratagems |
|---|---|---|---:|---:|
| **Brazen Engines** / Медные машины | Rampaging Terrors | демонические машины и Battle-shock в ближнем бою | 2 | 3 |
| **Butchers of Khorne** / Мясники Кхорна | Adamantine Avalanche | терминаторы и Blessings of Khorne | 2 | 3 |
| **Vessels of Wrath** / Сосуды гнева | Wrath of Khorne | персонажи и персональные дары Кхорна | 2 | 3 |

## Как пользоваться во время партии

1. Сначала определить detachment и точный keyword целевого отряда.
2. Проверить **Rules Updates** этого pack.
3. Проверить актуальный **Balance Dataslate**.
4. Стоимость, размеры отрядов, Leader links, Detachment Points и Force Disposition брать только из актуального **Munitorum Field Manual/app**.
5. При споре открыть страницу, указанную в `detachments.json` или `datasheets.json`.

## Импортированные материалы

- Detachments: 3
- Stratagem cards: 9
- Datasheets/Imperial Armour entries: 1
- Legends entries проиндексировано: 0
- Rules Updates: PDF pages 7–8

## Известные ограничения

- Очки не зашиты в этот слой: это преднамеренно, чтобы устаревшие значения не выдавались как актуальные.
- Для supplement-паков нужен Codex или актуальный app export.
- Извлечение текста из двухколоночных страниц может менять порядок абзацев; визуальный PDF остаётся окончательным источником.
