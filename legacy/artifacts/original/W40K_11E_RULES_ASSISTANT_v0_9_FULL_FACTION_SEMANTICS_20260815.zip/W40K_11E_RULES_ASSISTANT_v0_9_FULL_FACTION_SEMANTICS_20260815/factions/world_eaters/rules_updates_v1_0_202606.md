# World Eaters — Rules Updates

Источник: Faction Pack v1.0, PDF pages 7–8.

Ниже сохранён извлечённый текст. При сомнении сверять визуально с PDF.

```text
[PDF PAGE 7]
WORLD EATERS
RULES UPDATES
This section presents updates and clarifications to your faction’s rules, designed to improve the gaming experience for all players.
Changes applied after the first iteration of this Faction Pack will be highlighted in red.
UPDATES
ARMY RULES
Blessings of Khorne, Unbridled Bloodlust
Change to:
'This unit has +1 to charge rolls.'
BERZERKER WARBAND DETACHMENT
Berzerker's Wrath Stratagem, Target and Effect Sections
Change to:
'TARGET: One KHORNE BERZERKERS unit from your army that can make a
surge move as a result of those attacks.
EFFECT: Do not roll a D6 to determine how far models in your unit
can move when they make a surge move. Instead, when making a
surge move, those models can move up to 8".'
GORETRACK ONSLAUGHT DETACHMENT
Fury Unleashed Stratagem, Effect Section
Change to:
'One KHORNE BERZERKERS unit embarked within your model can make a
disembark move and then make a surge move of up to D6+2".'
KHORNE DAEMONKIN DETACHMENT
Summoned by Slaughter Stratagem
Change to:
‘WHEN: Any phase, when the last model in a unit is destroyed, before
removing it from play. (If that unit is a TRANSPORT, any units embarked
within that TRANSPORT model must disembark first).
TARGET: One BLOODLETTERS unit from your army that is in Reserves.
EFFECT: Set your unit up anywhere on the battlefield wholly within 9"
of that destroyed model and more than 6" horizontally away from all
enemy units, then remove the destroyed model from play.
RESTRICTIONS: You cannot use this Stratagem more than once per
battle round.
POSSESSED SLAUGHTERBOUND DETACHMENT
Warp Stalkers Stratagem, Effect section
Change to:
‘Until the end of the phase, each time a model in your unit makes a
Normal, Advance, Fall Back or Charge move, it can move through enemy
models (excluding MONSTERS and VEHICLES). When doing so, it can
move within Engagement Range of such models but, unless that move
was a Charge move, it cannot end that move within Engagement Range
of them, and any Desperate Escape test is automatically passed.
Rapid Manifestation Stratagem
Change 3" to 6".
Brazen Fury Detachment Rule
Change to:
'In your opponent’s Shooting phase, when an enemy unit has shot, if a
model in this unit was destroyed as a result of those attacks, this unit
can make a surge move of up to D6". That surge move is a Brazen Fury
move.'
DATASHEETS
Heldrake

▪Profile: Change M to 12" and OC to '-'.

▪Keywords: Remove 'AIRCRAFT'.
Chaos Rhino, Meet Any Challenge Ability
Change 9" to 8".
Chaos Terminators, Blood Fury Ability
Change to:

▪'This unit’s ranged attacks that target the closest eligible target can
re-roll hit rolls.

▪When this unit declares a charge, you can use this part of this ability.
If you do:

▫This unit can re-roll that charge roll.

▫This unit must end that charge move engaged with the closest
charge target.'
Exalted Eightbound, Rend and Tear Ability
Change to:
‘Each time a model in this unit makes a melee attack that targets
a MONSTER or VEHICLE unit, until the end of the phase, improve the
Damage characteristic of that attack by 1.'
Goremongers, Loping Speed Ability
Change to:
'In your opponent's Movement phase, if an enemy unit ends a move
within 8" of this unit, if this unit is not within Engagement Range of one
or more enemy units, this unit can make a Normal move of up to D6".'
Khorne Berzerkers, Jakhals – Icon of Khorne Wargear Ability
Change to:
‘If the bearer’s unit contains one or more Icons of Khorne, each time the
bearer’s unit destroys an enemy unit, you gain 1 Bloodshed point. Each
time you make a Blessings of Khorne roll, roll one additional D6 for each
Bloodshed point you have, after which, all your Bloodshed points are
lost.'
Khorne Berzerkers, Blood Surge Ability
Change to:
'In your opponent’s Shooting phase, when an enemy unit has shot, if a
model in this unit was destroyed as a result of those attacks, this unit
can make a surge move of up to D6+2".'

[PDF PAGE 8]
Helbrute, Frenzy Ability
Change to:
'(Once per turn, per unit) In the Fight phase, when an enemy unit
targets this unit, after that unit has resolved its attacks, you can use
this ability. If you do, this unit is eligible to fight (even if it has already
fought this phase) and must be selected to fight next.'
Maulerfiend, Scent Of Blood Ability
Change to:'In the Charge phase, when this unit declares a charge:

▪If an enemy unit below starting strength is within 9" of this unit, this
unit has +1 to charge rolls.

▪Or: If an enemy unit below half strength is within 9" of this unit, this
unit has +2 to charge rolls.'
Slaughterbound, Melee Weapons,Lacerator and Daemonic Claw
Change S to '10'.
Chaos Land Raider, Chaos Predator Annihilator, Chaos Predator
Destructor, Chaos Rhino, Khorne Lord of Skulls – Keywords Section
Add 'FRAME'.
FAQS
Q: If Angron is destroyed and I use his Reborn in Blood ability, can I
still use the Wrath of Khorne Detachment ability for the Vessels of
Wrath Detachment?
A: Yes.
Q: While using the Khorne Daemonkin Detachment, can I select a
CHARACTER with the Disciple of Khorne Enhancement to be my WARLORD?
A: No.
Q: While using the Khorne Daemonkin Detachment, if I attach a Lord
on Juggernaut with the Disciple of Khorne Enhancement to a unit
of Bloodcrushers or Flesh Hounds, does that unit benefit from the
Blessings of Khorne ability, even though only the Lord on Juggernaut has
that ability?
A: Yes.
Q: Can I use the Summoned by Slaughter Stratagem to deploy
Bloodletters in the first battle round?
A: Bloodletter units that started the battle in Reserves cannot deploy
in the first battle round using the Summoned by Slaughter Stratagem.
Bloodletter units that started the battle on the battlefield and have
subsequently been placed into Strategic Reserves can deploy in the first
battle round.
```
