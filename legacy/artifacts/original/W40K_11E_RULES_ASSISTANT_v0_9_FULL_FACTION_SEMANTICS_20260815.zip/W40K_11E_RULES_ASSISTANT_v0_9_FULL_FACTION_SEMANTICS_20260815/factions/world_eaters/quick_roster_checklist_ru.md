# Пожиратели Миров — быстрая проверка ростера и партии

**Snapshot:** MFM v1.2 / Faction Pack v1.1 / Universal Rules Updates v1.0  
**Проверено:** 2026-08-15

## Перед построением списка

1. Выбрать detachment или сочетание detachments.
2. Сложить Detachment Points.
3. Проверить повторяющиеся `unique_tags`.
4. Сверить Force Disposition каждого detachment.
5. Посчитать units с учётом цены соответствующей копии.
6. Добавить платные weapon options.
7. Добавить enhancements из правильного detachment.
8. Проверить Leader/Support links.
9. Наложить Universal Rules Updates v1.0 и faction-specific v1.1 updates; historical Balance Dataslate v3.3 не применять как самостоятельный 11e current override.
10. Перед турниром повторно открыть официальный MFM/App и current Faction Pack.

## Игровой профиль

Армия staged melee pressure: угроза заряда, trade-последовательность и сохранение второго эшелона.

### Приоритеты
- Не выставлять все угрозы в один слой.
- Exalted Eightbound теперь особенно опасны для Monster/Vehicle.
- Проверять Leader pairing с Eightbound/Berzerkers.

### Типичные ловушки
- Brazen Engines и Goretrack Onslaught имеют общий ONSLAUGHT tag.
- Duplicate-copy thresholds различаются; считать только через current MFM.

## Статистика импортированного live-слоя

- Units with points: 30
- Detachments: 8
- Enhancements: 26
- Leader/Support links: 5
- Dataslate checklist entries: 2
