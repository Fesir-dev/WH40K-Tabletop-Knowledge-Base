# Адептус Кустодес — быстрая проверка ростера и партии

**Snapshot:** MFM v1.2 / Faction Pack v1.1 / Universal Rules Updates v1.0  
**Проверено:** 2026-08-15

## Перед построением списка

1. Выбрать detachment или сочетание detachments.
2. Сложить Detachment Points.
3. Проверить повторяющиеся `unique_tags`.
4. Сверить Force Disposition каждого detachment.
5. Посчитать units с учётом цены соответствующей копии.
6. Добавить платные weapon options.
7. Добавить enhancements из правильного detachment.
8. Проверить Leader/Support links.
9. Наложить Universal Rules Updates v1.0 и faction-specific v1.1 updates; historical Balance Dataslate v3.3 не применять как самостоятельный 11e current override.
10. Перед турниром повторно открыть официальный MFM/App и current Faction Pack.

## Игровой профиль

Небольшое число очень дорогих отрядов: каждое перемещение, сохранённый OC и выбор момента для боя критичны.

### Приоритеты
- Сначала определить задачу каждого элитного блока.
- Не отдавать два scoring-отряда за один обмен.
- Учитывать новые профили Jetbike/Vertus из Dataslate.

### Типичные ловушки
- ARMOURY и LIONS несовместимы с другим detachment того же unique-tag.
- Дубли дорогих машин и Guard/Wardens могут иметь copy-dependent цену; использовать current cost bands.

## Статистика импортированного live-слоя

- Units with points: 31
- Detachments: 9
- Enhancements: 30
- Leader/Support links: 8
- Dataslate checklist entries: 6
