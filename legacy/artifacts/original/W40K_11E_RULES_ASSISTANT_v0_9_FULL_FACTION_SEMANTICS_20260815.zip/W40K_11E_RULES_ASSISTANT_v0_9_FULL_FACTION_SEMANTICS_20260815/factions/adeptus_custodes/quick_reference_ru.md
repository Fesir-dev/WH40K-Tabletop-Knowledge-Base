> **CURRENT v0.6 NOTE:** основной текст ниже — структурная памятка исходного Faction Pack v1.0. Для текущей игры поверх неё обязательно применяются `rules_updates_v1_1_20260722.json`, MFM v1.2 и Universal Rules Updates v1.0. Exact wording — из официального v1.1 PDF/App.

# Адептус Кустодес — быстрая памятка по Faction Pack v1.0

**Matched play:** с 20 июня 2026 года.  
**Статус покрытия:** Пакет дополняет Codex и не заменяет базовые datasheets, army rule и старые detachments.

## Detachments

| Detachment | Ключевое правило | Практический архетип | Enhancements | Stratagems |
|---|---|---|---:|---:|
| **Might of the Moritoi** / Мощь Моритои | March of the Honoured Dead | дредноуты и Walker-отряды | 2 | 3 |
| **Silent Hunters** / Безмолвные охотницы | Skin-crawling Disorientation | Сёстры Безмолвия и охота на псайкеров | 2 | 3 |
| **Tharanatoi Hammerblow** / Удар молота Таранатои | The Hammer Falls | терминаторы и Ingress | 2 | 3 |
| **Lions of the Emperor** / Львы Императора | Against All Odds | разрозненные элитные отряды без близкой поддержки | 4 | 6 |
| **Solar Spearhead** / Солнечный авангард | Auric Armour, Moritoi Ancients | тяжёлая техника Кустодес | 4 | 6 |

## Как пользоваться во время партии

1. Сначала определить detachment и точный keyword целевого отряда.
2. Проверить **Rules Updates** этого pack.
3. Проверить актуальный **Balance Dataslate**.
4. Стоимость, размеры отрядов, Leader links, Detachment Points и Force Disposition брать только из актуального **Munitorum Field Manual/app**.
5. При споре открыть страницу, указанную в `detachments.json` или `datasheets.json`.

## Импортированные материалы

- Detachments: 5
- Stratagem cards: 21
- Datasheets/Imperial Armour entries: 13
- Legends entries проиндексировано: 0
- Rules Updates: PDF pages 35–35

## Известные ограничения

- Очки не зашиты в этот слой: это преднамеренно, чтобы устаревшие значения не выдавались как актуальные.
- Для supplement-паков нужен Codex или актуальный app export.
- Извлечение текста из двухколоночных страниц может менять порядок абзацев; визуальный PDF остаётся окончательным источником.
