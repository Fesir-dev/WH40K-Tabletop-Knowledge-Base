# Демоны Хаоса — быстрая проверка ростера и партии

**Snapshot:** MFM v1.2 / Faction Pack v1.1 / Universal Rules Updates v1.0  
**Проверено:** 2026-08-15

## Перед построением списка

1. Выбрать detachment или сочетание detachments.
2. Сложить Detachment Points.
3. Проверить повторяющиеся `unique_tags`.
4. Сверить Force Disposition каждого detachment.
5. Посчитать units с учётом цены соответствующей копии.
6. Добавить платные weapon options.
7. Добавить enhancements из правильного detachment.
8. Проверить Leader/Support links.
9. Наложить Universal Rules Updates v1.0 и faction-specific v1.1 updates; historical Balance Dataslate v3.3 не применять как самостоятельный 11e current override.
10. Перед турниром повторно открыть официальный MFM/App и current Faction Pack.

## Игровой профиль

Давление через Shadow of Chaos, Deep Strike, board-control и моно-божеские пакеты.

### Приоритеты
- Контроль центральных objectives расширяет Shadow.
- Планировать 6" deep strike только при выполнении точных условий.
- Не перегружать список лидерами без подходящих bodyguards.

### Типичные ловушки
- Нет отдельного faction-раздела в BDS v3.3, но действуют core changes.
- Duplicate-copy bands различаются по datasheet; считать только через current MFM.

## Статистика импортированного live-слоя

- Units with points: 53
- Detachments: 9
- Enhancements: 29
- Leader/Support links: 18
- Dataslate checklist entries: 1
