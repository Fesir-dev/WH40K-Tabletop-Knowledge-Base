> **CURRENT v0.6 NOTE:** основной текст ниже — структурная памятка исходного Faction Pack v1.0. Для текущей игры поверх неё обязательно применяются `rules_updates_v1_1_20260722.json`, MFM v1.2 и Universal Rules Updates v1.0. Exact wording — из официального v1.1 PDF/App.

# Демоны Хаоса — быстрая памятка по Faction Pack v1.0

**Matched play:** с 20 июня 2026 года.  
**Статус покрытия:** Пакет содержит полный Index-слой армии, включая army rules и matched-play datasheets.

## Detachments

| Detachment | Ключевое правило | Практический архетип | Enhancements | Stratagems |
|---|---|---|---:|---:|
| **Cavalcade of Chaos** / Кавалькада Хаоса | Unholy Avalanche | Mounted-отряды, отход с последующей атакой | 2 | 3 |
| **Lords of the Warp** / Владыки Варпа | Loci of Power | персонажи и локусы силы | 1 | 4 |
| **Warptide** / Варп-прилив | Shudderblink | Battleline, Advance и давление числом | 2 | 3 |
| **Blood Legion** / Кровавый легион | Murdercall, Blood Tainted | моно-Кхорн и агрессивный ближний бой | 4 | 6 |
| **Scintillating Legion** / Переливчатый легион | Fates in Flux | моно-Тзинч, Flux-токены и магическая гибкость | 4 | 6 |
| **Plague Legion** / Чумной легион | Melancholic Miasma | моно-Нургл, стойкость и дебаффы | 4 | 6 |
| **Legion of Excess** / Легион излишеств | Beguiling Aura, Seductive Gambit | моно-Слаанеш, Fall Back + Charge и рискованный Gambit | 4 | 0 |

## Как пользоваться во время партии

1. Сначала определить detachment и точный keyword целевого отряда.
2. Проверить **Rules Updates** этого pack.
3. Проверить актуальный **Balance Dataslate**.
4. Стоимость, размеры отрядов, Leader links, Detachment Points и Force Disposition брать только из актуального **Munitorum Field Manual/app**.
5. При споре открыть страницу, указанную в `detachments.json` или `datasheets.json`.

## Импортированные материалы

- Detachments: 7
- Stratagem cards: 28
- Datasheets/Imperial Armour entries: 54
- Legends entries проиндексировано: 0
- Rules Updates: PDF pages 130–130

## Известные ограничения

- Очки не зашиты в этот слой: это преднамеренно, чтобы устаревшие значения не выдавались как актуальные.
- Для supplement-паков нужен Codex или актуальный app export.
- Извлечение текста из двухколоночных страниц может менять порядок абзацев; визуальный PDF остаётся окончательным источником.
