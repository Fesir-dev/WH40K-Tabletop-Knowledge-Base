# Chaos Daemons — Rules Updates

Источник: Faction Pack v1.0, PDF pages 130–130.

Ниже сохранён извлечённый текст. При сомнении сверять визуально с PDF.

```text
[PDF PAGE 130]
THIEVES OF PAIN
LEGION OF EXCESS – STRATEGIC PLOY STRATAGEM
To exist, however fleetingly, in realspace is an
opportunity to indulge in every physical sensation.
So enraptured do the daemons of Slaanesh become
that they even steal one another’s agonies to enjoy.
WHEN: Any phase, just after an attack or mortal
wound is allocated to a model in a Legiones
Daemonica Slaanesh unit from your army
(excluding Monsters and Vehicles).
TARGET: That Legiones Daemonica Slaanesh unit.
EFFECT: Select one other friendly Legiones
Daemonica Slaanesh unit that is within 9" of and
visible to your unit. Until the end of the phase, while
the selected unit is on the battlefield, each time
a model in your unit would lose a wound, inflict 1
mortal wound on the selected unit instead.
OVERWHELMING EXCESS
LEGION OF EXCESS – BATTLE TACTIC STRATAGEM
Sensation gushes relentlessly into the
overstimulated minds of the enemy until their souls
strain fit to burst. Barely able to think or function,
they recoil in their desperate need to stem the
unstoppable tide.
WHEN: Your opponent’s Shooting phase or the
Fight phase, just after an enemy unit has selected
its targets.
TARGET: One Legiones Daemonica Slaanesh unit
from your army that was selected as the target of
one or more of the attacking unit’s attacks.
EFFECT: Until the end of the phase, each time an
attack targets your unit, subtract 1 from the Hit roll.
ARCHAGONISTS
LEGION OF EXCESS – BATTLE TACTIC STRATAGEM
These daemons perceive with absolute clarity
whereabouts on their victims’ bodies they must
strike to inflict the greatest possible excess
of suffering. 
WHEN: Fight phase.
TARGET: One Legiones Daemonica Slaanesh
Monster unit or up to two Legiones Daemonica
Slaanesh units (excluding Monsters) from your
army that have not been selected to fight this phase.
EFFECT: Until the end of the phase, each time a
model in one of those units makes an attack, add 1
to the Wound roll.
SENSORY EXCRUCIATION
LEGION OF EXCESS – STRATEGIC PLOY STRATAGEM
This entity causes the battlefield to flicker wildly
between the debauched Slaaneshi Warp interstice
and the most brutally mundane reality, faster than
even supernatural senses can perceive. The result
is a psychically devastating barrage of excess
and deprivation.
WHEN: Your Command phase.
TARGET: One Legiones Daemonica Slaanesh
Monster unit from your army that is on
the battlefield.
EFFECT: Each unit on the battlefield that is
within your army’s Shadow of Chaos must take a
Battle‑shock test, subtracting 1 from that test if they
are Below Half‑strength.
Designer’s Note: This Stratagem forces all friendly
and enemy units alike within your army’s Shadow
of Chaos to take a Battle‑shock test. This can
allow a Chaos Daemons player to heal units from
their army through the Daemonic Terror army rule,
at the risk of causing some of their own units to
become Battle‑shocked.
PHANTASMAL LONGING
LEGION OF EXCESS – STRATEGIC PLOY STRATAGEM
Against their wills, enemy combatants find
themselves wishing for the daemons of Slaanesh
to draw closer. It is child’s play for the daemons of
Slaanesh to harness such strong emotions and
transform them into manifest reality. 
WHEN: Your Movement phase or your Charge phase.
TARGET: One Legiones Daemonica Slaanesh unit
from your army.
EFFECT: Until the end of the phase, each time a
model in your unit makes a move, it can move
through terrain features.
CAVALCADE OF BLADES
LEGION OF EXCESS – BATTLE TACTIC STRATAGEM
The cavorting approach of Slaaneshi daemons is
hypnotic and enthralling. It is a whirling carousel of
eye‑searing colours and flashing blades that tempt
mortals to reach out with trembling eagerness until
they can just reach.
WHEN: Your Charge phase, just after a Legiones
Daemonica Slaanesh unit from your army ends a
Charge move.
TARGET: That Legiones Daemonica Slaanesh unit.
EFFECT: Select one enemy unit within Engagement
Range of your unit, then roll one D6 for each model
in your unit that is within Engagement Range of that
enemy unit, or roll six D6 instead if your unit is a
Monster unit: for each 4+, that enemy unit suffers 1
mortal wound.
1CP
1CP
2CP
1CP
1CP
1CP
130
```
