# v0.7 — Regression Certification

Checkpoint regression runner:

```bash
python tools/run_rules_engine_regressions_v0_7.py
```

На сборке v0.7 закрыты 19 executable cases:

- Normal Move phase cap;
- extra CP battle-round cap;
- same-Stratagem phase cap;
- same-target Stratagem cap;
- explicit named repeat permission;
- generic 0CP -> -1CP universal update;
- explicit named 0CP exception;
- version-precedence regression: July Character revival override поверх stale June core;
- валидный Incursion roster;
- single 3DP Incursion exception;
- DP overflow;
- empty Dedicated Transport;
- duplicate Epic Hero;
- Battleline duplicate limit;
- mandatory Support attachment.

Expected result: `19/19 PASS`.
