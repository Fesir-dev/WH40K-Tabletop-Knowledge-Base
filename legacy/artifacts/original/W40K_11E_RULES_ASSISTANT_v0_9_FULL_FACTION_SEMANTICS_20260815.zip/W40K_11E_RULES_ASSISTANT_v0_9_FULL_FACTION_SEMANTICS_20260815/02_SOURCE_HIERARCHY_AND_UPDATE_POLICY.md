# Иерархия источников и политика обновлений — v0.5 LIVE

Дата проверки: **2026-08-15**.

## Source-of-truth lock

Для любых ответов, расчётов ростера и rules-engine решений текущая версия правил определяется **в момент запроса**, а не по возрасту локального ZIP.

Приоритет источников:

1. **Текущие официальные Universal Rules Updates / errata / FAQ / faction updates / app rulings Games Workshop.**
2. **Текущий официальный Munitorum Field Manual** — points, unit sizes/cost bands, Leader/Support links, Detachment Points и Force Dispositions.
3. **Текущий официальный mission/event pack**, когда вопрос относится к этому формату.
4. **Текущий официальный Faction Pack / Codex / datasheet / detachment / enhancement / stratagem.**
5. **Core Rules 11th edition.**
6. **Wahapedia 11th edition** — структурированный secondary live source для навигации, поиска, cross-check и обнаружения пробелов.
7. Preview/news article — только контекст, если он не объявлен нормативным обновлением.
8. Локальный snapshot — evidence/cache, но не автоматическая текущая истина.
9. Вывод/интерпретация.

## Conflict lock

Если Wahapedia, локальный snapshot и официальный актуальный документ расходятся, **официальный актуальный документ побеждает всегда**. Разницу надо записать как discrepancy, а не тихо перезаписывать историю.

## Freshness gate

Перед ответом о points, roster legality, FAQ, faction rule, detachment, DP, disposition, Leader link или tournament mission:

1. проверить официальный downloads/MFM/app слой;
2. сверить Wahapedia 11e как вторичный индекс;
3. сравнить с локальным snapshot;
4. при несовпадении пометить локальные данные `STALE`/`SUPERSEDED`;
5. только после этого выполнять расчёт/рулинг.

## Snapshot policy

`data/mfm_live_snapshot_20260710.json` сохраняется неизменным как исторический checkpoint. Он **не является текущим MFM** после обновления 22.07.2026.

Текущий внешний state фиксируется отдельно в `data/live_rules_source_state_20260815.json`.

## Обновление проекта

При любом новом официальном документе:

1. записать URL, версию, publication/update date и checked-at;
2. создать новый source-state checkpoint, не переписывая предыдущий;
3. сравнить rule IDs/timing/target/effect/cost/keywords;
4. пометить прежние записи superseded;
5. запустить `python tools/validate_project.py`;
6. запустить `python tools/validate_live_layers.py`;
7. запустить `python tools/validate_source_freshness.py`;
8. обновить changelog и regression cases.
