#!/usr/bin/env python3
import json,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def n(s):return ' '.join(unicodedata.normalize('NFKC',s).casefold().replace('’',"'").split())
t=json.loads((ROOT/'data/transport_profiles_v0_8_20260815.json').read_text(encoding='utf-8'))
r=json.loads((ROOT/'data/unit_roles_current_v0_7_20260815.json').read_text(encoding='utf-8'))
m=json.loads((ROOT/'data/mfm_v1_2_user_factions_20260815.json').read_text(encoding='utf-8'))
profiles={(x['faction'],n(x['unit'])):x for x in t['profiles']}; errors=[]; required=[]
for f,fd in r['factions'].items():
    for u in fd['categories']['dedicated_transport']:
        required.append((f,n(u)))
        if (f,n(u)) not in profiles:errors.append(f'missing profile {f}/{u}')
for k,x in profiles.items():
    names={n(u['name_en']) for u in m['factions'][x['faction']]['units']}
    if n(x['unit']) not in names:errors.append(f'profile unit absent from MFM {x["faction"]}/{x["unit"]}')
    if int(x['capacity'])<=0:errors.append(f'bad capacity {x}')
print(f'dedicated transports covered: {len(profiles)}/{len(required)}')
if errors:print('\n'.join('ERROR '+x for x in errors));raise SystemExit(1)
print('PASS')
