#!/usr/bin/env python3
from __future__ import annotations
import json,sys,unicodedata,re
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CORE=json.loads((ROOT/'data/core_roster_rules_v0_7_20260815.json').read_text(encoding='utf-8'))
ROLES=json.loads((ROOT/'data/unit_roles_current_v0_7_20260815.json').read_text(encoding='utf-8'))
MFM=json.loads((ROOT/'data/mfm_v1_2_user_factions_20260815.json').read_text(encoding='utf-8'))
ENH=json.loads((ROOT/'data/enhancement_metadata_v0_7_20260815.json').read_text(encoding='utf-8'))
PRED=json.loads((ROOT/'data/enhancement_target_predicates_v0_8_20260815.json').read_text(encoding='utf-8'))
TRANS=json.loads((ROOT/'data/transport_profiles_v0_8_20260815.json').read_text(encoding='utf-8'))
SUPREME=json.loads((ROOT/'data/supreme_commander_rules_v0_8_20260815.json').read_text(encoding='utf-8'))
COMP=json.loads((ROOT/'data/faction_composition_rules_v0_8_20260815.json').read_text(encoding='utf-8'))
KWE=json.loads((ROOT/'data/local_datasheet_keyword_evidence_v0_8_20260815.json').read_text(encoding='utf-8'))
AVAIL=json.loads((ROOT/'data/army_availability_overrides_v0_8_20260815.json').read_text(encoding='utf-8'))
ENH_ALIASES=json.loads((ROOT/'data/enhancement_name_aliases_v0_8_20260815.json').read_text(encoding='utf-8'))

FACTION_KEYWORD={
 'adeptus_custodes':'ADEPTUS CUSTODES','adeptus_mechanicus':'ADEPTUS MECHANICUS','chaos_daemons':'LEGIONES DAEMONICA',
 'chaos_space_marines':'HERETIC ASTARTES','genestealer_cults':'GENESTEALER CULTS','imperial_knights':'IMPERIAL KNIGHTS',
 'thousand_sons':'THOUSAND SONS','world_eaters':'WORLD EATERS'}
TRACKED_COMPLETE_ROLES={'CHARACTER','EPIC HERO','BATTLELINE','DEDICATED TRANSPORT'}

def canon(s):
    s=unicodedata.normalize('NFKC',str(s)).replace('‑','-').replace('–','-').replace('—','-').replace('‐','-').replace('’',"'")
    return ' '.join(s.split())
def norm(s): return canon(s).casefold()
def tag(s): return canon(s).upper()
AVAIL_MAP={(x['army_faction'],norm(x['unit'])):x for x in AVAIL['overrides']}
def result(code,severity,message,**extra):
    d={'code':code,'severity':severity,'message':message}; d.update(extra); return d

def find_unit(slug,name):
    f=MFM['factions'].get(slug)
    if not f:return None
    n=norm(name)
    for u in f['units']:
        if n==norm(u['name_en']) or any(n==norm(a) for a in u.get('aliases',[])): return u
    return None

def cost_band(u,copy_no):
    for b in u['cost_bands']:
        if copy_no>=b['min_copy'] and (b['max_copy'] is None or copy_no<=b['max_copy']): return b
    return None

def unit_cost(u,copy_no,models,wargear):
    b=cost_band(u,copy_no)
    if not b or str(models) not in b['sizes']: raise ValueError(f"{u['name_en']}: invalid model count {models} for copy #{copy_no}")
    total=b['sizes'][str(models)]; lookup={norm(x['name']):x for x in u.get('wargear',[])}
    for w in wargear:
        x=lookup.get(norm(w['name']))
        if not x: raise ValueError(f"{u['name_en']}: unknown paid wargear {w['name']}")
        total += int(x['points'])*int(w.get('count',1))
    return total

def role_sets(slug):
    cats=ROLES['factions'][slug]['categories']
    return {k:{norm(x) for x in v} for k,v in cats.items()}

def local_kw(slug,name):
    n=norm(name)
    for x in KWE['factions'].get(slug,[]):
        if norm(x['unit'])==n:return x
    return None

def evidence_for(entry,source_slug,u,grants=None,availability_override=None):
    tags=set(); abilities=set(); evidence=[]
    if source_slug in FACTION_KEYWORD and not (availability_override and availability_override.get('native_faction_keyword') is False):
        tags.add(FACTION_KEYWORD[source_slug]); evidence.append('native_faction_keyword')
    if availability_override:
        tags.update(tag(x) for x in availability_override.get('add_keywords',[])); evidence.append('army_availability_override')
    if u:
        tags.add(tag(u['name_en']))
        for a in u.get('aliases',[]):tags.add(tag(a))
        rs=role_sets(source_slug); key=norm(u['name_en'])
        mapping={'battleline':'BATTLELINE','dedicated_transport':'DEDICATED TRANSPORT','epic_hero':'EPIC HERO','character':'CHARACTER'}
        for cat,t in mapping.items():
            if key in rs.get(cat,set()):tags.add(t)
        x=local_kw(source_slug,u['name_en'])
        if x:
            tags.update(x.get('keywords',[])); abilities.update(x.get('abilities',[])); evidence.append('retained_datasheet_positive_evidence')
    for x in entry.get('keywords',[]):tags.add(tag(x))
    for x in entry.get('abilities',[]):abilities.add(tag(x))
    if entry.get('keywords'):evidence.append('roster_keywords')
    if entry.get('abilities'):evidence.append('roster_abilities')
    for x in grants or []:tags.add(tag(x))
    return {'tags':tags,'abilities':abilities,'keywords_complete':bool(entry.get('keywords_complete',False)),'abilities_complete':bool(entry.get('abilities_complete',False)),'evidence':evidence}

def token_state(tok,ev):
    tok=tag(tok)
    if tok in ev['tags']:return True
    if tok in TRACKED_COMPLETE_ROLES:return False
    if ev['keywords_complete']:return False
    return None

def ability_state(tok,ev):
    tok=tag(tok)
    if tok in ev['abilities']:return True
    if ev['abilities_complete']:return False
    return None

def evaluate_pred(pred,ev):
    if pred.get('normalization_status')!='EXECUTABLE':return 'UNKNOWN','target clause not executable'
    unknown=[]
    for t in pred.get('required_all',[]):
        s=token_state(t,ev)
        if s is False:return 'FAIL',f'missing required keyword/tag {t}'
        if s is None:unknown.append(t)
    for grp in pred.get('required_any_groups',[]):
        states=[token_state(t,ev) for t in grp]
        if not any(x is True for x in states):
            if all(x is False for x in states):return 'FAIL',f'missing all alternatives {grp}'
            unknown.append('ANY('+','.join(grp)+')')
    for t in pred.get('excluded',[]):
        s=token_state(t,ev)
        if s is True:return 'FAIL',f'excluded keyword/tag present: {t}'
        if s is None:unknown.append('NOT '+t)
    for a in pred.get('required_abilities',[]):
        s=ability_state(a,ev)
        if s is False:return 'FAIL',f'missing required ability {a}'
        if s is None:unknown.append('ABILITY '+a)
    if unknown:return 'UNKNOWN','unproven target terms: '+', '.join(unknown)
    return 'PASS','target predicate satisfied'

def main():
    if len(sys.argv)!=2:
        print('Usage: validate_roster_v0_8.py roster.json'); return 2
    roster=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    slug=roster.get('faction'); battle=norm(roster.get('battle_size','strike_force')).replace(' ','_')
    out={'schema':'w40k11.roster_validation.result.v0.8','faction':slug,'battle_size':battle,'checks':[],'unknowns':[],'warnings':[]}
    if slug not in MFM['factions']:
        out['checks'].append(result('faction','ERROR',f'Unknown faction slug: {slug}')); print(json.dumps(out,ensure_ascii=False,indent=2)); return 1
    if battle not in CORE['battle_sizes']:
        out['checks'].append(result('battle_size','ERROR',f'Unknown battle size: {battle}')); print(json.dumps(out,ensure_ascii=False,indent=2)); return 1
    br=CORE['battle_sizes'][battle]; native=MFM['factions'][slug]; native_roles=role_sets(slug)
    det_lookup={norm(d['name_en']):d for d in native['detachments']}
    dets=roster.get('detachments',[]); selected_det_norm={norm(x) for x in dets}
    enh_cost={(norm(det),norm(name)):pts for det,rows in native['enhancement_costs'].items() for name,pts in rows.items()}
    enh_pred={(norm(x['detachment']),norm(x['name'])):x for x in PRED['factions'][slug]['entries']}
    alias_map={(norm(x['detachment']),norm(x['source_name'])):norm(x['current_name']) for x in ENH_ALIASES['aliases'] if x['faction']==slug}
    for x in PRED['factions'][slug]['entries']:
        for a in ENH_ALIASES['aliases']:
            if a['faction']==slug and norm(a['detachment'])==norm(x['detachment']) and norm(a['source_name'])==norm(x['name']): enh_pred[(norm(x['detachment']),norm(a['current_name']))]=x
    enh_type={k:v for k,v in enh_pred.items()}

    # Detachment validation/DP first because later faction rules depend on selected detachments.
    seen=Counter(norm(x) for x in dets); dp=0; tags=defaultdict(list); valid_dets=[]
    for name in dets:
        d=det_lookup.get(norm(name))
        if not d:out['checks'].append(result('detachment_known','ERROR',f'Unknown current-MFM detachment: {name}'));continue
        valid_dets.append(d);dp+=int(d['dp'])
        for ut in d.get('unique_tags',[]):tags[ut].append(d['name_en'])
    for n,c in seen.items():
        if c>1:out['checks'].append(result('detachment_duplicate','ERROR',f'Same detachment selected {c} times: {n}'))
    for ut,names in tags.items():
        if len(names)>1:out['checks'].append(result('detachment_unique_tag','ERROR',f'Unique tag {ut} conflict: {", ".join(names)}'))
    dp_ok=dp<=br['detachment_points_limit'] or (battle=='incursion' and len(valid_dets)==1 and dp==3)
    out['checks'].append(result('detachment_points','PASS' if dp_ok else 'ERROR',f'Detachment Points: {dp}/{br["detachment_points_limit"]}',used=dp,limit=br['detachment_points_limit']))

    # Detachment keyword-grant selections (currently Solar Spearhead Moritoi Ancients).
    grants_by_id=defaultdict(set)
    selections=roster.get('detachment_selections',{})
    for rule in COMP['rules']:
        if rule['army_faction']!=slug or rule['kind']!='keyword_grant_selection':continue
        det=rule['detachment_required']
        if norm(det) not in selected_det_norm:continue
        ids=list((selections.get(det) or {}).get(rule['selection_field'],[]))
        if len(ids)>int(rule['max_selected']):out['checks'].append(result('detachment_selection_limit','ERROR',f'{det}: selected {len(ids)} {rule["selection_field"]}, max {rule["max_selected"]}.'))
        for uid in ids:
            for g in rule['grant']:grants_by_id[uid].add(g)

    # Units: current cross-faction cost lookup + optional external units.
    entries=roster.get('units',[]);ids={};copies=defaultdict(Counter);total_points=0;infos=[]
    for e in entries:
        uid=e.get('id'); source=e.get('source_faction',slug); name=e.get('name',''); qty=int(e.get('quantity',1)); models=int(e.get('models',1))
        if uid:
            if uid in ids:out['checks'].append(result('unit_id_unique','ERROR',f'Duplicate unit id: {uid}'))
            else:ids[uid]=e
        u=find_unit(source,name) if source in MFM['factions'] else None
        external=False
        if not u:
            if 'external_points' in e:
                external=True; total_points+=int(e['external_points'])*qty
                out['unknowns'].append(f'{name}: points are user-supplied external_points, not locally certified MFM data.')
            else:
                out['checks'].append(result('unit_known','ERROR',f'Unknown current-MFM unit for source_faction={source}: {name}')); continue
        else:
            key=norm(u['name_en'])
            for i in range(qty):
                copies[source][key]+=1
                try:total_points+=unit_cost(u,copies[source][key],models,e.get('wargear',[]))
                except ValueError as ex:out['checks'].append(result('unit_cost','ERROR',str(ex)))
        ov=AVAIL_MAP.get((source,norm(u['name_en']))) if u else None
        ev=evidence_for(e,source,u,grants_by_id.get(uid,set()),ov)
        native=(source==slug and not (ov and ov.get('native_faction_keyword') is False))
        infos.append({'entry':e,'id':uid,'source_faction':source,'unit':u,'external':external,'canonical':u['name_en'] if u else name,'qty':qty,'models':models,'evidence':ev,'is_native':native,'availability_override':ov})

    info_by_id={x['id']:x for x in infos if x['id']}

    # Any rule that selects one concrete unit instance requires an ID that resolves to exactly one unit.
    # A roster row with quantity>1 is fine for bulk costing, but cannot safely be used as Warlord,
    # Enhancement target, attachment participant, transport/passenger, or detachment-selection target.
    referenced_ids=set()
    if roster.get('warlord_unit_id'): referenced_ids.add(roster['warlord_unit_id'])
    for x in roster.get('enhancements',[]):
        if x.get('target_unit_id'): referenced_ids.add(x['target_unit_id'])
    for x in roster.get('attachments',[]):
        if x.get('character_unit_id'): referenced_ids.add(x['character_unit_id'])
        if x.get('bodyguard_unit_id'): referenced_ids.add(x['bodyguard_unit_id'])
    for x in roster.get('dedicated_transport_loads',[]):
        if x.get('transport_unit_id'): referenced_ids.add(x['transport_unit_id'])
        referenced_ids.update(y for y in x.get('embarked_unit_ids',[]) if y)
    for _det,sel in selections.items():
        if isinstance(sel,dict):
            for _field,val in sel.items():
                if isinstance(val,list): referenced_ids.update(y for y in val if isinstance(y,str) and y)
    for uid in sorted(referenced_ids):
        inf=info_by_id.get(uid)
        if inf and inf['qty']>1:
            out['checks'].append(result('ambiguous_unit_id_quantity','ERROR',f'Unit id {uid} represents quantity={inf["qty"]}; rules that target a concrete unit require one roster row/id per unit.'))

    # Verify keyword grants require eligible target terms.
    for rule in COMP['rules']:
        if rule['army_faction']!=slug or rule['kind']!='keyword_grant_selection' or norm(rule['detachment_required']) not in selected_det_norm:continue
        for uid in (selections.get(rule['detachment_required']) or {}).get(rule['selection_field'],[]):
            inf=info_by_id.get(uid)
            if not inf:out['checks'].append(result('detachment_selection_id','ERROR',f'{rule["detachment_required"]}: unknown selected unit id {uid}'));continue
            fake={'normalization_status':'EXECUTABLE','required_all':rule['required_all'],'required_any_groups':[],'excluded':[],'required_abilities':[]}
            st,msg=evaluate_pred(fake,inf['evidence'])
            if st=='FAIL':out['checks'].append(result('detachment_selection_target','ERROR',f'{uid}: {msg}'))
            elif st=='UNKNOWN':out['unknowns'].append(f'{uid}: cannot fully prove eligibility for {rule["detachment_required"]} keyword grant: {msg}')
            else:out['checks'].append(result('detachment_selection_target','PASS',f'{uid}: eligible for {rule["detachment_required"]} keyword grant.'))

    # Unit limits per source faction, plus special non-Epic limits.
    for source,cc in copies.items():
        rs=role_sets(source)
        for key,count in cc.items():
            u=next((x for x in MFM['factions'][source]['units'] if norm(x['name_en'])==key),None); canonical=u['name_en'] if u else key
            if key in rs.get('epic_hero',set()):limit=CORE['unit_selection']['epic_hero_unit_limit']
            else:
                mult=CORE['unit_selection']['battleline_unit_limit_multiplier'] if key in rs.get('battleline',set()) else 1
                if key in rs.get('dedicated_transport',set()):mult=max(mult,CORE['unit_selection']['dedicated_transport_unit_limit_multiplier'])
                limit=br['unit_limit']*mult
            for sr in SUPREME['rules']:
                if sr['faction']==source and norm(sr['unit'])==key and sr.get('max_units') is not None:limit=min(limit,int(sr['max_units']))
            out['checks'].append(result('unit_limit','PASS' if count<=limit else 'ERROR',f'{canonical}: {count}/{limit} copies',unit=canonical,count=count,limit=limit,source_faction=source))

    # Faction/allied composition rules.
    allied=[x for x in infos if not x.get('is_native',False)]
    allowed_allied=set(); ally_states=defaultdict(list)
    for rule in COMP['rules']:
        if rule['army_faction']!=slug:continue
        reqdet=rule.get('detachment_required')
        if reqdet and norm(reqdet) not in selected_det_norm:continue
        if rule['kind']=='boolean_forbid':
            if roster.get(rule['roster_flag'])==rule['forbidden_value']:
                out['checks'].append(result('detachment_forbidden_option','ERROR',f'{reqdet}: roster flag {rule["roster_flag"]} is forbidden.'))

    # Build per-entry points for allied cap calculations (same MFM band semantics as costing pass).
    seq=defaultdict(Counter); unit_point_rows={}
    for inf in infos:
        e=inf['entry']; subtotal=0
        if inf['external']:subtotal=int(e['external_points'])*inf['qty']
        elif inf['unit']:
            key=norm(inf['unit']['name_en'])
            for _ in range(inf['qty']):
                seq[inf['source_faction']][key]+=1
                try:subtotal+=unit_cost(inf['unit'],seq[inf['source_faction']][key],inf['models'],e.get('wargear',[]))
                except ValueError:pass
        unit_point_rows[inf['id']]=subtotal

    for rule in COMP['rules']:
        if rule['army_faction']!=slug:continue
        reqdet=rule.get('detachment_required')
        if reqdet and norm(reqdet) not in selected_det_norm:continue
        if rule['kind']=='ally_unit_name_cap':
            selected=[]
            allowed_names={norm(x) for x in rule['allowed_units']}
            for inf in allied:
                if inf['source_faction']!=rule['allowed_source_faction']:continue
                st='PASS' if norm(inf['canonical']) in allowed_names else 'FAIL'
                ally_states[inf['id']].append((rule['id'],st,'unit-name allowlist'))
                if st=='PASS':allowed_allied.add(inf['id']);selected.append(inf)
            pts=sum(unit_point_rows.get(x['id'],0) for x in selected)
            out['checks'].append(result('allied_points_cap','PASS' if pts<=rule['point_cap'] else 'ERROR',f'{rule["id"]}: allied points {pts}/{rule["point_cap"]}.',points=pts,limit=rule['point_cap']))
        elif rule['kind']=='ally_keyword_cap':
            selected=[]
            for inf in allied:
                ev=inf['evidence']; fake={'normalization_status':'EXECUTABLE','required_all':rule['required_all'],'required_any_groups':[],'excluded':rule.get('excluded',[]),'required_abilities':[]}
                st,msg=evaluate_pred(fake,ev); ally_states[inf['id']].append((rule['id'],st,msg))
                if st=='PASS':allowed_allied.add(inf['id']);selected.append(inf)
            pts=sum(unit_point_rows.get(x['id'],0) for x in selected); limit=rule['point_caps'].get(battle)
            if limit is not None:out['checks'].append(result('allied_points_cap','PASS' if pts<=limit else 'ERROR',f'{rule["id"]}: verified allied points {pts}/{limit}.',points=pts,limit=limit))
    for inf in allied:
        if inf['id'] in allowed_allied:continue
        states=ally_states.get(inf['id'],[])
        if any(st=='UNKNOWN' for _,st,_ in states):
            details='; '.join(f'{rid}: {msg}' for rid,st,msg in states if st=='UNKNOWN')
            out['unknowns'].append(f'{inf["canonical"]}: non-native unit eligibility remains unverified ({details}).')
        else:
            details='; '.join(f'{rid}: {msg}' for rid,st,msg in states) or 'no active normalized ally rule'
            out['checks'].append(result('army_faction_unit','ERROR',f'{inf["canonical"]} is not allowed by active normalized ally rules: {details}.'))

    # Enhancements + executable target clauses.
    enh=roster.get('enhancements',[]);counted_choices=0;upgrade_seen=Counter();standard_seen=Counter();target_seen=Counter()
    for e in enh:
        key=(norm(e.get('detachment','')),norm(e.get('name',''))); cost_key=key
        if cost_key not in enh_cost and key in alias_map: cost_key=(key[0],alias_map[key])
        pts=enh_cost.get(cost_key)
        if pts is None:out['checks'].append(result('enhancement_known','ERROR',f'Unknown enhancement/detachment combination: {e.get("name")} / {e.get("detachment")}'));continue
        if key not in enh_pred and cost_key in enh_pred:key=cost_key
        if key[0] not in selected_det_norm:out['checks'].append(result('enhancement_selected_detachment','ERROR',f'{e["name"]} comes from unselected detachment {e["detachment"]}.'))
        total_points+=int(pts)
        m=enh_type.get(key);is_upgrade=m['is_upgrade'] if m else None
        tid=e.get('target_unit_id');inf=info_by_id.get(tid) if tid else None
        if not inf:out['checks'].append(result('enhancement_target','ERROR',f'Enhancement {e.get("name")} needs a valid target_unit_id.'));continue
        target_seen[tid]+=1
        if target_seen[tid]>1:out['checks'].append(result('enhancement_per_unit','ERROR',f'Unit {tid} has more than one enhancement.'))
        ev=inf['evidence']
        if 'EPIC HERO' in ev['tags']:out['checks'].append(result('enhancement_epic_hero','ERROR',f'Epic Hero {inf["canonical"]} cannot receive an enhancement.'))
        if is_upgrade is True:
            upgrade_seen[key]+=1
            if upgrade_seen[key]>CORE['enhancements']['upgrade_max_same_enhancement']:out['checks'].append(result('upgrade_copy_limit','ERROR',f'{e["name"]}: more than 3 Upgrade copies.'))
            if upgrade_seen[key]==1:counted_choices+=1
        elif is_upgrade is False:
            standard_seen[key]+=1;counted_choices+=1
            if standard_seen[key]>1:out['checks'].append(result('enhancement_duplicate','ERROR',f'Non-Upgrade enhancement duplicated: {e["name"]}'))
            if 'CHARACTER' not in ev['tags']:out['checks'].append(result('enhancement_character','ERROR',f'{e["name"]} targets unit not proven to be a Character: {inf["canonical"]}.'))
        else:
            counted_choices+=1;out['unknowns'].append(f'Enhancement type not normalized for {e["detachment"]} / {e["name"]}.')
        pr=enh_pred.get(key)
        if pr:
            st,msg=evaluate_pred(pr,ev)
            if st=='FAIL':out['checks'].append(result('enhancement_target_clause','ERROR',f'{e["name"]} -> {inf["canonical"]}: {msg}',clause=pr.get('raw_target_clause')))
            elif st=='UNKNOWN':out['unknowns'].append(f'{e["name"]} -> {inf["canonical"]}: {msg}; clause: {pr.get("raw_target_clause")}')
            else:out['checks'].append(result('enhancement_target_clause','PASS',f'{e["name"]} -> {inf["canonical"]}: target clause satisfied.',clause=pr.get('raw_target_clause')))
        else:out['unknowns'].append(f'{e["name"]}: no v0.8 target predicate available.')
    out['checks'].append(result('enhancement_limit','PASS' if counted_choices<=br['enhancement_limit'] else 'ERROR',f'Enhancement choices counted: {counted_choices}/{br["enhancement_limit"]}',count=counted_choices,limit=br['enhancement_limit']))

    # Warlord + Supreme Commander precedence.
    wid=roster.get('warlord_unit_id'); winfo=info_by_id.get(wid) if wid else None
    if not winfo:out['checks'].append(result('warlord','ERROR','A valid warlord_unit_id is required.'))
    else:
        if 'CHARACTER' not in winfo['evidence']['tags']:out['checks'].append(result('warlord_character','ERROR',f'Warlord {winfo["canonical"]} is not proven Character.'))
        if FACTION_KEYWORD[slug] not in winfo['evidence']['tags']:out['checks'].append(result('warlord_faction','ERROR',f'{winfo["canonical"]} does not have the selected army faction keyword.'))
        else:out['checks'].append(result('warlord','PASS',f'Warlord: {winfo["canonical"]}'))
    must=[]
    for sr in SUPREME['rules']:
        if sr['faction']!=slug:continue
        for inf in infos:
            if inf['source_faction']==slug and norm(inf['canonical'])==norm(sr['unit']):must.append(inf)
    if must:
        must_ids={x['id'] for x in must}
        if wid not in must_ids:out['checks'].append(result('supreme_commander','ERROR',f'Present Supreme Commander must be Warlord: {", ".join(x["canonical"] for x in must)}'))
        else:out['checks'].append(result('supreme_commander','PASS',f'Supreme Commander Warlord requirement satisfied: {winfo["canonical"]}.'))
    # Allied rule Warlord prohibitions.
    if winfo and not winfo.get('is_native',False):out['checks'].append(result('allied_warlord','ERROR',f'Non-native allied unit {winfo["canonical"]} cannot be selected as the army Warlord under normalized ally rules.'))

    # Leader/support assignments, plus Pactbound mark matching.
    graph=json.loads((ROOT/'factions'/slug/'leader_support_graph_v1_2.json').read_text(encoding='utf-8'))
    rel_by_char={norm(x['character']):x for x in graph['links']}
    attach=roster.get('attachments',[]);attached_chars=set();per_body=defaultdict(lambda:Counter())
    pactbound=slug=='chaos_space_marines' and norm('Pactbound Zealots') in selected_det_norm
    for a in attach:
        cid=a.get('character_unit_id');bid=a.get('bodyguard_unit_id');ci=info_by_id.get(cid);bi=info_by_id.get(bid)
        if not ci or not bi:out['checks'].append(result('attachment_ids','ERROR',f'Invalid attachment ids: {cid} -> {bid}'));continue
        if ci['source_faction']!=slug or bi['source_faction']!=slug:out['unknowns'].append(f'{cid}->{bid}: cross-faction Leader/Support attachment is not normalized.');continue
        link=rel_by_char.get(norm(ci['canonical']))
        if not link:out['checks'].append(result('attachment_relation','ERROR',f'{ci["canonical"]} has no current Leader/Support relation.'));continue
        if norm(bi['canonical']) not in {norm(x) for x in link['can_join']}:out['checks'].append(result('attachment_bodyguard','ERROR',f'{ci["canonical"]} cannot join {bi["canonical"]}.'));continue
        rel=link['relation'].upper();per_body[bid][rel]+=1;attached_chars.add(cid);out['checks'].append(result('attachment','PASS',f'{ci["canonical"]} ({rel}) -> {bi["canonical"]}'))
        if pactbound:
            cm=tag(ci['entry'].get('chaos_mark',''));bm=tag(bi['entry'].get('chaos_mark',''))
            if not cm or not bm:out['unknowns'].append(f'Pactbound attachment {cid}->{bid}: chaos_mark not supplied for both units.')
            elif cm!=bm:out['checks'].append(result('pactbound_attachment_mark','ERROR',f'Pactbound attached units must share a Chaos mark: {cm} != {bm}.'))
            else:out['checks'].append(result('pactbound_attachment_mark','PASS',f'Pactbound attached units share {cm}.'))
    for bid,c in per_body.items():
        if c['LEADER']>1:out['checks'].append(result('leader_per_bodyguard','ERROR',f'{bid}: more than one Leader attached.'))
        if c['SUPPORT']>1:out['checks'].append(result('support_per_bodyguard','ERROR',f'{bid}: more than one Support attached.'))
    for inf in infos:
        if inf['source_faction']!=slug or not inf['id']:continue
        link=rel_by_char.get(norm(inf['canonical']))
        if link and link['relation'].upper()=='SUPPORT' and inf['id'] not in attached_chars:out['checks'].append(result('support_must_attach','ERROR',f'Support unit {inf["canonical"]} ({inf["id"]}) is not attached.'))

    # Pactbound marks of Chaos.
    if pactbound:
        allowed={'KHORNE','TZEENTCH','NURGLE','SLAANESH','CHAOS UNDIVIDED'}
        for inf in infos:
            if inf['source_faction']!='chaos_space_marines':continue
            ev=inf['evidence'];mark=tag(inf['entry'].get('chaos_mark','')) if inf['entry'].get('chaos_mark') else ''
            if 'EPIC HERO' not in ev['tags']:
                # If current keywords already include a valid mark, explicit field is optional.
                inherent=allowed & ev['tags']; effective=mark or (next(iter(inherent)) if len(inherent)==1 else '')
                if not effective:out['checks'].append(result('pactbound_mark_required','ERROR',f'{inf["canonical"]}: Pactbound Zealots requires a Chaos mark on non-Epic Heretic Astartes units.'))
                elif effective not in allowed:out['checks'].append(result('pactbound_mark_value','ERROR',f'{inf["canonical"]}: invalid chaos_mark {effective}.'))
                if effective=='KHORNE':
                    ps=token_state('PSYKER',ev)
                    if ps is True:out['checks'].append(result('pactbound_khorne_psyker','ERROR',f'{inf["canonical"]}: PSYKER cannot select KHORNE.'))
                    elif ps is None:out['unknowns'].append(f'{inf["canonical"]}: cannot prove whether KHORNE restriction vs PSYKER applies; supply complete keywords.')

    # Dedicated Transport must start loaded + exact current capacity/eligibility for all six current user-faction DT profiles.
    profiles={(x['faction'],norm(x['unit'])):x for x in TRANS['profiles']}
    loads={x.get('transport_unit_id'):x.get('embarked_unit_ids',[]) for x in roster.get('dedicated_transport_loads',[])}
    for inf in infos:
        if not inf['unit'] or not inf['id']:continue
        rs=role_sets(inf['source_faction']);key=norm(inf['canonical'])
        if key not in rs.get('dedicated_transport',set()):continue
        embarked=loads.get(inf['id'],[])
        if not embarked:out['checks'].append(result('dedicated_transport_loaded','ERROR',f'{inf["canonical"]} ({inf["id"]}) has no friendly unit assigned as embarked at Declare Battle Formations.'));continue
        bad=[x for x in embarked if x not in info_by_id or x==inf['id']]
        if bad:out['checks'].append(result('dedicated_transport_load_ids','ERROR',f'{inf["id"]}: invalid embarked ids {bad}'));continue
        prof=profiles.get((inf['source_faction'],key))
        if not prof:out['unknowns'].append(f'{inf["canonical"]} ({inf["id"]}): exact transport profile not normalized.');continue
        used=0
        for pid in embarked:
            pi=info_by_id[pid];used += pi['models']*pi['qty']
            fake={'normalization_status':'EXECUTABLE','required_all':prof['requires_all'],'required_any_groups':[],'excluded':prof['excludes'],'required_abilities':[]}
            st,msg=evaluate_pred(fake,pi['evidence'])
            if st=='FAIL':out['checks'].append(result('transport_passenger','ERROR',f'{pi["canonical"]} cannot embark in {inf["canonical"]}: {msg}'))
            elif st=='UNKNOWN':out['unknowns'].append(f'{pi["canonical"]} -> {inf["canonical"]}: passenger eligibility not fully proven: {msg}')
            else:out['checks'].append(result('transport_passenger','PASS',f'{pi["canonical"]} eligible for {inf["canonical"]}.'))
            if pactbound and inf['source_faction']=='chaos_space_marines':
                tm=tag(inf['entry'].get('chaos_mark',''));pm=tag(pi['entry'].get('chaos_mark',''))
                if not tm or not pm:out['unknowns'].append(f'Pactbound transport {inf["id"]}: chaos_mark not supplied for transport/passenger {pid}.')
                elif tm!=pm:out['checks'].append(result('pactbound_transport_mark','ERROR',f'Pactbound transport/passenger must share Chaos mark: {tm} != {pm}.'))
        out['checks'].append(result('transport_capacity','PASS' if used<=prof['capacity'] else 'ERROR',f'{inf["canonical"]} capacity: {used}/{prof["capacity"]} models.',used=used,capacity=prof['capacity']))

    # Points + unresolved coverage.
    out['points']={'total':total_points,'limit':br['points_limit']}
    out['checks'].append(result('points_limit','PASS' if total_points<=br['points_limit'] else 'ERROR',f'Points: {total_points}/{br["points_limit"]}',total=total_points,limit=br['points_limit']))
    normalized_det_rules={norm(r.get('detachment_required')) for r in COMP['rules'] if r.get('army_faction')==slug and r.get('detachment_required')}
    for d in valid_dets:
        # Presence here doesn't mean every rule in detachment is composition-relevant. Keep narrow gate only for declared known gap list.
        if d.get('restrictions') and norm(d['name_en']) not in normalized_det_rules:out['unknowns'].append(f'{d["name_en"]}: one or more detachment restrictions remain unnormalized.')
    errors=sum(1 for x in out['checks'] if x['severity']=='ERROR')
    out['summary']={'errors':errors,'unknown_count':len(out['unknowns']),'warning_count':len(out['warnings']),'core_and_faction_legality':'FAIL' if errors else 'PASS','certification':'FAIL' if errors else ('PASS_WITH_UNVERIFIED_DETAILS' if out['unknowns'] else 'CURRENT_CERTIFIED')}
    print(json.dumps(out,ensure_ascii=False,indent=2));return 1 if errors else 0
if __name__=='__main__':raise SystemExit(main())
