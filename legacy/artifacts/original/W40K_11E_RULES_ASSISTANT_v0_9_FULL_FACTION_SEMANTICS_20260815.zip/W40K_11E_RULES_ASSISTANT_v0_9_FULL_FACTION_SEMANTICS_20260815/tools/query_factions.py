#!/usr/bin/env python3
from pathlib import Path
import argparse, json, re

ROOT = Path(__file__).resolve().parents[1]
INDEX = ROOT / "data" / "faction_page_search.jsonl"

p = argparse.ArgumentParser(description="Search imported W40K 11E faction-pack pages.")
p.add_argument("query", help="Text to search, e.g. 'Fell Back' or 'Resurgence points'")
p.add_argument("--faction", help="Optional faction slug filter")
p.add_argument("--limit", type=int, default=20)
args = p.parse_args()

needle = args.query.casefold()
hits = []
for line in INDEX.read_text(encoding="utf-8").splitlines():
    rec = json.loads(line)
    if args.faction and rec["faction_slug"] != args.faction:
        continue
    hay = rec["text"].casefold()
    pos = hay.find(needle)
    if pos < 0:
        continue
    start = max(0, pos - 180)
    end = min(len(rec["text"]), pos + len(args.query) + 280)
    snippet = re.sub(r"\s+", " ", rec["text"][start:end]).strip()
    hits.append((rec, snippet))
    if len(hits) >= args.limit:
        break

if not hits:
    print("No hits.")
else:
    for rec, snippet in hits:
        print(f"[{rec['faction_en']}] PDF p.{rec['pdf_page']} — {rec['source_file']}")
        print(snippet)
        print()
