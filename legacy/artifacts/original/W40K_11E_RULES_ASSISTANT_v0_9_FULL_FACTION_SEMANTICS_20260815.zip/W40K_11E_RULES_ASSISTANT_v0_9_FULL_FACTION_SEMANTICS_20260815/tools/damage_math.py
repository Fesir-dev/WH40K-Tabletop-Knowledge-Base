#!/usr/bin/env python3
"""Exact binomial distribution for a simple fixed attack profile.
This intentionally does not model rerolls, crit riders, allocation or variable damage.
Use it only when those effects are absent or already reduced to an effective probability.
"""
import argparse, math

def binom(n,k,p):
    return math.comb(n,k)*(p**k)*((1-p)**(n-k))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--attacks',type=int,required=True)
    ap.add_argument('--p-hit',type=float,required=True)
    ap.add_argument('--p-wound',type=float,required=True)
    ap.add_argument('--p-fail-save',type=float,required=True)
    ap.add_argument('--damage',type=float,default=1)
    args=ap.parse_args()
    p=args.p_hit*args.p_wound*args.p_fail_save
    exp=args.attacks*p
    print(f'Effective unsaved probability: {p:.6f}')
    print(f'Expected unsaved attacks: {exp:.4f}')
    print(f'Expected raw damage: {exp*args.damage:.4f}')
    print('Distribution:')
    for k in range(args.attacks+1):
        pr=binom(args.attacks,k,p)
        if pr>=0.0005:
            print(f'  {k} unsaved: {pr:.2%}')
if __name__=='__main__': main()
