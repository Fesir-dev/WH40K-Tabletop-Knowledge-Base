#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors = []
db_path = ROOT / "data" / "mfm_v1_2_user_factions_20260815.json"
bds_path = ROOT / "data" / "balance_dataslate_v3_3_user_factions.json"
if not db_path.exists(): errors.append("Missing MFM snapshot")
if not bds_path.exists(): errors.append("Missing BDS snapshot")
if errors:
    print("FAIL\n" + "\n".join(errors))
    raise SystemExit(1)

db = json.loads(db_path.read_text(encoding="utf-8"))
bds = json.loads(bds_path.read_text(encoding="utf-8"))
if len(db["factions"]) != 8: errors.append("Expected 8 MFM factions")
if len(bds["factions"]) != 8: errors.append("Expected 8 BDS factions")

unit_count = det_count = enh_count = link_count = 0
for slug, f in db["factions"].items():
    unit_count += len(f["units"])
    det_count += len(f["detachments"])
    enh_count += sum(len(x) for x in f["enhancement_costs"].values())
    link_count += len(f["leader_support_links"])
    fdir = ROOT / "factions" / slug
    for name in [
        "mfm_v1_2_points.json", "mfm_v1_2_detachments.json", "leader_support_graph_v1_2.json",
        "balance_dataslate_v3_3.json", "quick_roster_checklist_ru.md",
        "live_source_snapshot_20260815.json",
    ]:
        if not (fdir / name).exists():
            errors.append(f"Missing {slug}/{name}")
    for u in f["units"]:
        if not u["cost_bands"]:
            errors.append(f"{slug}: no bands for {u['name_en']}")
        for band in u["cost_bands"]:
            if not band["sizes"]:
                errors.append(f"{slug}: empty size map for {u['name_en']}")

# Structural smoke tests.
sample = ROOT / "templates" / "roster_input_example_v0_4.json"
p = subprocess.run([sys.executable, str(ROOT / "tools" / "cost_roster.py"), str(sample)],
                   capture_output=True, text=True)
if p.returncode != 0 or "STRUCTURAL CHECK: PASS" not in p.stdout or "TOTAL: 670 pts" not in p.stdout:
    errors.append("Roster cost smoke test failed:\n" + p.stdout + p.stderr)

p2 = subprocess.run([
    sys.executable, str(ROOT / "tools" / "check_detachments.py"),
    "adeptus_custodes", "Might of the Moritoi", "Solar Spearhead"
], capture_output=True, text=True)
if "FAIL" not in p2.stdout or "CONFLICT ARMOURY" not in p2.stdout:
    errors.append("Unique-tag conflict smoke test failed")

p3 = subprocess.run([
    sys.executable, str(ROOT / "tools" / "leader_lookup.py"),
    "chaos_space_marines", "Huron Blackheart"
], capture_output=True, text=True)
if "Chaos Terminator Squad" not in p3.stdout:
    errors.append("Leader lookup smoke test failed")

if errors:
    print("FAIL")
    print("\n".join(errors))
    raise SystemExit(1)

print(
    f"PASS: 8 factions; {unit_count} point entries; {det_count} detachments; "
    f"{enh_count} enhancements; {link_count} Leader/Support links; "
    f"{sum(len(x['changes']) for x in bds['factions'].values())} dataslate checklist entries."
)
