#!/usr/bin/env python3
"""Search the compact W40K 11e project database."""
from pathlib import Path
import sqlite3, argparse

DB = Path(__file__).resolve().parents[1] / 'data' / 'w40k11_rules.db'

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('query', help='substring, mission code, alias or topic')
    args=ap.parse_args()
    q=args.query.strip()
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    cur=con.cursor()
    print('== ALIASES ==')
    for r in cur.execute("SELECT * FROM aliases WHERE lower(alias) LIKE lower(?) OR lower(canonical) LIKE lower(?)",(f'%{q}%',f'%{q}%')):
        print(dict(r))
    print('== QUICK RULINGS ==')
    for r in cur.execute("SELECT * FROM quick_rulings WHERE lower(topic||' '||ruling||' '||source) LIKE lower(?)",(f'%{q}%',)):
        print(dict(r))
    print('== MISSIONS ==')
    for r in cur.execute("SELECT * FROM mission_pool WHERE lower(code||' '||primary_mission||' '||deployment) LIKE lower(?)",(f'%{q}%',)):
        print(dict(r))
    print('== APP REFERENCES ==')
    for r in cur.execute("SELECT * FROM app_references WHERE lower(name||' '||note||' '||status) LIKE lower(?)",(f'%{q}%',)):
        print(dict(r))
    con.close()
if __name__=='__main__': main()
