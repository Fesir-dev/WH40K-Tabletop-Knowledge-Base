#!/usr/bin/env python3
from __future__ import annotations
import json,sys,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
R=json.loads((ROOT/'data/unit_roles_current_v0_7_20260815.json').read_text(encoding='utf-8'))
def norm(s): return ' '.join(unicodedata.normalize('NFKC',s).casefold().replace('’',"'").split())
def main():
    if len(sys.argv)<2: print('Usage: query_unit_role_v0_7.py "unit name" [faction_slug]'); return 2
    q=norm(sys.argv[1]); selected=[sys.argv[2]] if len(sys.argv)>2 else list(R['factions'])
    hits=[]
    for slug in selected:
        f=R['factions'].get(slug)
        if not f: continue
        roles=[]; canonical=None
        for cat,names in f['categories'].items():
            for n in names:
                if norm(n)==q: canonical=n; roles.append(cat)
        if canonical: hits.append({'faction':slug,'unit':canonical,'roles':roles})
    print(json.dumps({'query':sys.argv[1],'hits':hits,'current_as_of':R['as_of']},ensure_ascii=False,indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
