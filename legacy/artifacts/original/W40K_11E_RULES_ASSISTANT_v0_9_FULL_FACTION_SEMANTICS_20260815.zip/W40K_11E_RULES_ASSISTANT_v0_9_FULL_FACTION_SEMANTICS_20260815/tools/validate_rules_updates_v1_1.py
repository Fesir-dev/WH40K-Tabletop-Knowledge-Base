#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
FAC=['adeptus_custodes','adeptus_mechanicus','chaos_daemons','chaos_space_marines','genestealer_cults','imperial_knights','thousand_sons','world_eaters']
errors=[]; changes=0
for slug in FAC:
    p=ROOT/'factions'/slug/'rules_updates_v1_1_20260722.json'
    if not p.exists(): errors.append(f'{slug}: missing current update file'); continue
    d=json.loads(p.read_text(encoding='utf-8'))
    src=d.get('official_faction_pack',{})
    if src.get('version')!='1.1': errors.append(f'{slug}: version {src.get("version")}')
    if src.get('legal_for_matched_play_from')!='2026-07-22': errors.append(f'{slug}: legal date mismatch')
    h=src.get('sha256_of_verified_external_pdf','')
    if len(h)!=64: errors.append(f'{slug}: missing/invalid verified PDF hash')
    cs=d.get('change_summary',[]); changes+=len(cs)
    if not cs: errors.append(f'{slug}: empty semantic delta')
    for x in cs:
        if not all(x.get(k) for k in ('scope','target','summary')): errors.append(f'{slug}: malformed change summary')
    man=json.loads((ROOT/'factions'/slug/'source_manifest.json').read_text(encoding='utf-8'))
    if man.get('source',{}).get('version')!='1.1': errors.append(f'{slug}: source_manifest source is not current v1.1')
if errors:
    print('FAIL'); print('\n'.join(errors)); raise SystemExit(1)
print(f'PASS: 8 current Faction Pack v1.1 semantic layers; {changes} summarized change groups; official-PDF provenance hashes present.')
