#!/usr/bin/env python3
import json,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def n(s):return ' '.join(unicodedata.normalize('NFKC',s).casefold().replace('’',"'").split())
m=json.loads((ROOT/'data/mfm_v1_2_user_factions_20260815.json').read_text(encoding='utf-8'))
s=json.loads((ROOT/'data/supreme_commander_rules_v0_8_20260815.json').read_text(encoding='utf-8'))
c=json.loads((ROOT/'data/faction_composition_rules_v0_8_20260815.json').read_text(encoding='utf-8'))
a=json.loads((ROOT/'data/army_availability_overrides_v0_8_20260815.json').read_text(encoding='utf-8'))
errors=[]
for x in s['rules']:
    if x['faction'] not in m['factions']:errors.append(f'unknown supreme faction {x}') ;continue
    if n(x['unit']) not in {n(u['name_en']) for u in m['factions'][x['faction']]['units']}:errors.append(f'supreme unit absent from MFM {x}')
for x in c['rules']:
    if x['army_faction'] not in m['factions']:errors.append(f'unknown composition faction {x}')
    det=x.get('detachment_required')
    if det and n(det) not in {n(d['name_en']) for d in m['factions'][x['army_faction']]['detachments']}:errors.append(f'unknown detachment {x["id"]}: {det}')
for x in a['overrides']:
    if n(x['unit']) not in {n(u['name_en']) for u in m['factions'][x['army_faction']]['units']}:errors.append(f'availability override unit missing: {x}')
print(f'supreme={len(s["rules"])} composition={len(c["rules"])} availability_overrides={len(a["overrides"])}')
if errors:print('\n'.join('ERROR '+x for x in errors));raise SystemExit(1)
print('PASS')
