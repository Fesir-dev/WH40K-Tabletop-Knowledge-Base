#!/usr/bin/env python3
import json, sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB = json.loads((ROOT / "data" / "mfm_v1_2_user_factions_20260815.json").read_text(encoding="utf-8"))

def n(s): return " ".join(s.casefold().split())

if len(sys.argv) < 3:
    print("Usage: check_detachments.py faction_slug 'Detachment 1' ['Detachment 2' ...] [--limit N]")
    raise SystemExit(2)

slug = sys.argv[1]
args = sys.argv[2:]
limit = None
if "--limit" in args:
    i = args.index("--limit")
    limit = int(args[i+1])
    args = args[:i]
f = DB["factions"][slug]
lookup = {n(d["name_en"]): d for d in f["detachments"]}
total = 0
tags = defaultdict(list)
for name in args:
    d = lookup.get(n(name))
    if not d:
        raise SystemExit(f"Unknown detachment: {name}")
    total += d["dp"]
    print(f"{d['name_en']}: {d['dp']} DP | {d['force_disposition']} | {d['unique_tags'] or ['none']}")
    for tag in d["unique_tags"]:
        tags[tag].append(d["name_en"])
print(f"Total: {total} DP" + (f" / {limit}" if limit is not None else ""))
bad = False
for tag, names in tags.items():
    if len(names) > 1:
        bad = True
        print(f"CONFLICT {tag}: {', '.join(names)}")
if limit is not None and total > limit:
    bad = True
    print("LIMIT EXCEEDED")
print("PASS" if not bad else "FAIL")
