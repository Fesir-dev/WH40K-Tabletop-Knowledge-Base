#!/usr/bin/env python3
from pathlib import Path
import json, sys

ROOT = Path(__file__).resolve().parents[1]
errors = []
catalog = json.loads((ROOT / "data" / "user_faction_catalog.json").read_text(encoding="utf-8"))
if len(catalog) != 8:
    errors.append(f"Expected 8 factions, found {len(catalog)}")

required = [
    "source_manifest.json", "pack_index.json", "detachments.json", "datasheets.json",
    "rules_updates_en.md", "quick_reference_ru.md", "coverage_gaps_ru.md",
    "regression_tests.json", "legends_index.json",
]
for row in catalog:
    fdir = ROOT / "factions" / row["slug"]
    for rel in required:
        if not (fdir / rel).exists():
            errors.append(f"Missing {row['slug']}/{rel}")
    dets = json.loads((fdir / "detachments.json").read_text(encoding="utf-8"))
    if len(dets) != row["detachments"]:
        errors.append(f"{row['slug']}: detachment count mismatch")
    tests = json.loads((fdir / "regression_tests.json").read_text(encoding="utf-8"))
    if len(tests) < 10:
        errors.append(f"{row['slug']}: fewer than 10 regression tests")

cust = json.loads((ROOT / "factions" / "adeptus_custodes" / "source_manifest.json").read_text(encoding="utf-8"))
if not cust["duplicate_notes"] or not cust["duplicate_notes"][0]["identical_to_primary"]:
    errors.append("Custodes duplicate was not verified")

search_lines = (ROOT / "data" / "faction_page_search.jsonl").read_text(encoding="utf-8").splitlines()
if len(search_lines) < 250:
    errors.append(f"Search index unexpectedly small: {len(search_lines)}")

if errors:
    print("FAIL")
    print("\n".join(errors))
    sys.exit(1)

print(
    "PASS: 8 factions; "
    f"{sum(r['detachments'] for r in catalog)} detachments; "
    f"{sum(r['stratagems'] for r in catalog)} stratagems; "
    f"{sum(r['datasheets'] for r in catalog)} datasheets; "
    f"{len(search_lines)} searchable matched-play pages."
)
