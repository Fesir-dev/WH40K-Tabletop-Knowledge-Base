#!/usr/bin/env python3
from __future__ import annotations
import json,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
M=json.loads((ROOT/'data/mfm_v1_2_user_factions_20260815.json').read_text(encoding='utf-8'))
R=json.loads((ROOT/'data/unit_roles_current_v0_7_20260815.json').read_text(encoding='utf-8'))
def norm(s): return ' '.join(unicodedata.normalize('NFKC',s).casefold().replace('’',"'").split())
errors=[]; counts={}
for slug,f in R['factions'].items():
    pool={norm(u['name_en']) for u in M['factions'][slug]['units']}; cats=f['categories']; counts[slug]={k:len(v) for k,v in cats.items()}
    for cat,names in cats.items():
        for n in names:
            if norm(n) not in pool: errors.append(f'{slug}/{cat}: not current-MFM unit: {n}')
    chars={norm(x) for x in cats['character']}; epics={norm(x) for x in cats['epic_hero']}; war={norm(x) for x in cats['warlord_eligible']}
    if not epics <= chars: errors.append(f'{slug}: Epic Hero set not subset of Character')
    if not war <= chars: errors.append(f'{slug}: Warlord-eligible set not subset of Character')
print(json.dumps({'status':'PASS' if not errors else 'FAIL','factions':counts,'errors':errors},ensure_ascii=False,indent=2))
raise SystemExit(1 if errors else 0)
