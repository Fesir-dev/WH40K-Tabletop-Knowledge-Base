#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

CURRENT_MFM_BANNER = "CURRENT USER-FACTION RUNTIME: MFM 1.2, official update 2026-07-22, reconciled/checked 2026-08-15. Re-check official sources at tournament submission time."
DB = json.loads((ROOT / "data" / "mfm_v1_2_user_factions_20260815.json").read_text(encoding="utf-8"))

def norm(s: str) -> str:
    return " ".join(s.casefold().replace("’", "'").split())

def find_unit(faction: dict, name: str) -> dict:
    n = norm(name)
    for u in faction["units"]:
        if n == norm(u["name_en"]) or any(n == norm(a) for a in u.get("aliases", [])):
            return u
    raise KeyError(f"Unknown unit: {name}")

def applicable_band(u: dict, copy_no: int) -> dict:
    for b in u["cost_bands"]:
        if copy_no >= b["min_copy"] and (b["max_copy"] is None or copy_no <= b["max_copy"]):
            return b
    raise ValueError(f"No cost band for {u['name_en']} copy #{copy_no}")

def unit_cost(u: dict, copy_no: int, models: int, selected_wargear: list[dict]) -> tuple[int, list[str]]:
    b = applicable_band(u, copy_no)
    key = str(models)
    if key not in b["sizes"]:
        raise ValueError(
            f"{u['name_en']} copy #{copy_no}: invalid model count {models}; "
            f"valid: {', '.join(b['sizes'].keys())}"
        )
    total = b["sizes"][key]
    notes = [f"base {total}"]
    wg_lookup = {norm(x["name"]): x for x in u.get("wargear", [])}
    for chosen in selected_wargear:
        name = chosen["name"]
        count = int(chosen.get("count", 1))
        w = wg_lookup.get(norm(name))
        if not w:
            raise ValueError(f"{u['name_en']}: unknown paid wargear '{name}'")
        add = w["points"] * count
        total += add
        notes.append(f"{w['name']} +{add}")
    return total, notes

def main() -> int:
    print(CURRENT_MFM_BANNER)
    if len(sys.argv) != 2:
        print("Usage: cost_roster.py roster.json")
        return 2
    roster = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    slug = roster["faction"]
    if slug not in DB["factions"]:
        raise KeyError(f"Unknown faction slug: {slug}")
    faction = DB["factions"][slug]
    det_lookup = {norm(d["name_en"]): d for d in faction["detachments"]}
    enh_lookup = {
        (norm(det), norm(name)): pts
        for det, entries in faction["enhancement_costs"].items()
        for name, pts in entries.items()
    }

    total = 0
    copy_counter = defaultdict(int)
    print(f"Faction: {faction['meta']['name_en']}")
    print("\nUNITS")
    for entry in roster.get("units", []):
        u = find_unit(faction, entry["name"])
        qty = int(entry.get("quantity", 1))
        models = int(entry.get("models", 1))
        for _ in range(qty):
            copy_counter[u["name_en"]] += 1
            copy_no = copy_counter[u["name_en"]]
            cost, notes = unit_cost(u, copy_no, models, entry.get("wargear", []))
            total += cost
            print(f"- {u['name_en']} ({models}), copy #{copy_no}: {cost} pts [{'; '.join(notes)}]")

    print("\nENHANCEMENTS")
    for e in roster.get("enhancements", []):
        key = (norm(e["detachment"]), norm(e["name"]))
        if key not in enh_lookup:
            raise ValueError(f"Unknown enhancement/detachment combination: {e}")
        pts = enh_lookup[key]
        total += pts
        print(f"- {e['name']} ({e['detachment']}): {pts} pts")

    selected = []
    dp_total = 0
    tags = defaultdict(list)
    print("\nDETACHMENTS")
    for name in roster.get("detachments", []):
        d = det_lookup.get(norm(name))
        if not d:
            raise ValueError(f"Unknown detachment: {name}")
        selected.append(d)
        dp_total += d["dp"]
        for tag in d["unique_tags"]:
            tags[tag].append(d["name_en"])
        print(f"- {d['name_en']}: {d['dp']} DP; {d['force_disposition']}; tags={d['unique_tags'] or ['none']}")

    conflicts = {tag: names for tag, names in tags.items() if len(names) > 1}
    limit = roster.get("dp_limit")
    print(f"\nTOTAL: {total} pts")
    print(f"DETACHMENT POINTS: {dp_total}" + (f" / {limit}" if limit is not None else ""))
    if limit is not None and dp_total > int(limit):
        print("ERROR: Detachment Points limit exceeded.")
    if conflicts:
        print("ERROR: unique-tag conflicts:")
        for tag, names in conflicts.items():
            print(f"  {tag}: {', '.join(names)}")
    if not conflicts and (limit is None or dp_total <= int(limit)):
        print("STRUCTURAL CHECK: PASS")
    print("Reminder: this is not a full Codex/app legality check.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
