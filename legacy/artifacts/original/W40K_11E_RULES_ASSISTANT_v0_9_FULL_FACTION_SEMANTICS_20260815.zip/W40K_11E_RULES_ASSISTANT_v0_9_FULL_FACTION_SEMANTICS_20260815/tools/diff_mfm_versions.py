#!/usr/bin/env python3
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
x=json.loads((ROOT/'data'/'mfm_v1_2_user_faction_diff_20260815.json').read_text(encoding='utf-8'))
slug=sys.argv[1] if len(sys.argv)>1 else None
items=x['factions'].items() if slug is None else [(slug,x['factions'][slug])]
for f,d in items:
    print(f'\n## {f}')
    for u in d['unit_cost_changes']:
        print(f"UNIT: {u['unit']}")
    for q in d['detachment_changes']:
        print(f"DETACHMENT: {q['detachment']} -> {q['changes']}")
