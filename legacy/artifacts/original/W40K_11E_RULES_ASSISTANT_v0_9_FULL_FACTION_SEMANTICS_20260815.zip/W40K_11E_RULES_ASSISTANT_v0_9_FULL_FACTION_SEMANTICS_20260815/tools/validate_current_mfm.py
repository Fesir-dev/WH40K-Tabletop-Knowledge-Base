#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'data'/'mfm_v1_2_user_factions_20260815.json'
D=ROOT/'data'/'mfm_v1_2_user_faction_diff_20260815.json'
errors=[]
for p in [P,D]:
    if not p.exists(): errors.append(f'Missing {p.relative_to(ROOT)}')
if errors: print('FAIL\n'+'\n'.join(errors)); raise SystemExit(1)
x=json.loads(P.read_text(encoding='utf-8')); d=json.loads(D.read_text(encoding='utf-8'))
if x.get('certification')!='CURRENT_USER_FACTIONS_20260815': errors.append('bad certification')
if x.get('source',{}).get('interactive_version')!='1.2': errors.append('bad MFM version')
if len(x.get('factions',{}))!=8: errors.append('expected 8 factions')
checks={
 ('adeptus_custodes','Aleya',1,1):55,
 ('adeptus_custodes','Venatari Custodians',3,3):160,
 ('adeptus_mechanicus','Skorpius Dunerider',1,4):85,
 ('chaos_daemons','Lord of Change',1,3):340,
 ('chaos_space_marines','Chosen',10,3):280,
 ('genestealer_cults','Reductus Saboteur',1,3):80,
 ('imperial_knights','Knight Castellan',1,2):450,
 ('thousand_sons','Sekhetar Robots',4,3):190,
 ('world_eaters','Exalted Eightbound',6,3):280,
}
def cost(f,u,models,copy):
    unit=next(z for z in x['factions'][f]['units'] if z['name_en']==u)
    band=next(b for b in unit['cost_bands'] if copy>=b['min_copy'] and (b['max_copy'] is None or copy<=b['max_copy']))
    return band['sizes'][str(models)]
for key,val in checks.items():
    got=cost(*key)
    if got!=val: errors.append(f'{key}: expected {val}, got {got}')
det_checks={
 ('adeptus_custodes','Might of the Moritoi'):(1,'Take and Hold'),
 ('adeptus_mechanicus','Haloscreed Battle Clade'):(3,'Priority Assets'),
 ('chaos_daemons','Lords of the Warp'):(1,'Take and Hold'),
 ('chaos_space_marines','Murdertalon Raiders'):(1,'Reconnaissance'),
 ('genestealer_cults','Xenocult Masses'):(1,'Reconnaissance'),
 ('imperial_knights','Freeblade Company'):(3,'Priority Assets'),
 ('thousand_sons','Hexwarp Thrallband'):(3,'Take and Hold'),
 ('world_eaters','Butchers of Khorne'):(1,'Take and Hold'),
}
for (f,n),exp in det_checks.items():
    z=next(q for q in x['factions'][f]['detachments'] if q['name_en']==n)
    got=(z['dp'],z['force_disposition'])
    if got!=exp: errors.append(f'{f}/{n}: expected {exp}, got {got}')
if errors:
    print('FAIL'); print('\n'.join(errors)); raise SystemExit(1)
uc=sum(len(v['unit_cost_changes']) for v in d['factions'].values())
dc=sum(len(v['detachment_changes']) for v in d['factions'].values())
print(f'PASS: current MFM 1.2 runtime; 8 factions; {uc} unit cost-band changes; {dc} detachment/enhancement changes; sentinel costs/dispositions verified.')
