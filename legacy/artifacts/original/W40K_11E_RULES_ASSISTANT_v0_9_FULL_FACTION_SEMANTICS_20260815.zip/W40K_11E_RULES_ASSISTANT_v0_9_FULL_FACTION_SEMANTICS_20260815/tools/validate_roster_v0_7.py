#!/usr/bin/env python3
from __future__ import annotations
import json, sys, unicodedata
from collections import Counter, defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CORE=json.loads((ROOT/'data/core_roster_rules_v0_7_20260815.json').read_text(encoding='utf-8'))
ROLES=json.loads((ROOT/'data/unit_roles_current_v0_7_20260815.json').read_text(encoding='utf-8'))
MFM=json.loads((ROOT/'data/mfm_v1_2_user_factions_20260815.json').read_text(encoding='utf-8'))
ENH=json.loads((ROOT/'data/enhancement_metadata_v0_7_20260815.json').read_text(encoding='utf-8'))

def norm(s): return ' '.join(unicodedata.normalize('NFKC',s).casefold().replace('’',"'").split())
def result(code,severity,message,**extra):
    d={'code':code,'severity':severity,'message':message}; d.update(extra); return d

def find_unit(faction,name):
    n=norm(name)
    for u in faction['units']:
        if n==norm(u['name_en']) or any(n==norm(a) for a in u.get('aliases',[])): return u
    return None

def cost_band(u,copy_no):
    for b in u['cost_bands']:
        if copy_no>=b['min_copy'] and (b['max_copy'] is None or copy_no<=b['max_copy']): return b
    return None

def unit_cost(u,copy_no,models,wargear):
    b=cost_band(u,copy_no)
    if not b or str(models) not in b['sizes']: raise ValueError(f"{u['name_en']}: invalid model count {models} for copy #{copy_no}")
    total=b['sizes'][str(models)]; lookup={norm(x['name']):x for x in u.get('wargear',[])}
    for w in wargear:
        x=lookup.get(norm(w['name']))
        if not x: raise ValueError(f"{u['name_en']}: unknown paid wargear {w['name']}")
        total += int(x['points'])*int(w.get('count',1))
    return total

def main():
    if len(sys.argv)!=2:
        print('Usage: validate_roster_v0_7.py roster.json'); return 2
    roster=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    slug=roster.get('faction'); battle=norm(roster.get('battle_size','strike_force')).replace(' ','_')
    out={'schema':'w40k11.roster_validation.result.v0.7','faction':slug,'battle_size':battle,'checks':[],'unknowns':[],'warnings':[]}
    if slug not in MFM['factions']:
        out['checks'].append(result('faction','ERROR',f'Unknown faction slug: {slug}')); print(json.dumps(out,ensure_ascii=False,indent=2)); return 1
    if battle not in CORE['battle_sizes']:
        out['checks'].append(result('battle_size','ERROR',f'Unknown battle size: {battle}')); print(json.dumps(out,ensure_ascii=False,indent=2)); return 1
    faction=MFM['factions'][slug]; br=CORE['battle_sizes'][battle]; cats=ROLES['factions'][slug]['categories']
    catsets={k:{norm(x) for x in v} for k,v in cats.items()}
    det_lookup={norm(d['name_en']):d for d in faction['detachments']}
    enh_cost={(norm(det),norm(name)):pts for det,rows in faction['enhancement_costs'].items() for name,pts in rows.items()}
    enh_type={(norm(x['detachment']),norm(x['name'])):x for x in ENH['factions'][slug]['entries']}
    graph=json.loads((ROOT/'factions'/slug/'leader_support_graph_v1_2.json').read_text(encoding='utf-8'))
    rel_by_char={norm(x['character']):x for x in graph['links']}

    entries=roster.get('units',[]); ids={}; copies=Counter(); total_points=0; unit_rows=[]
    for e in entries:
        name=e.get('name',''); u=find_unit(faction,name)
        if not u:
            out['checks'].append(result('unit_known','ERROR',f'Unknown current-MFM unit: {name}')); continue
        qty=int(e.get('quantity',1)); models=int(e.get('models',1)); uid=e.get('id')
        if uid:
            if uid in ids: out['checks'].append(result('unit_id_unique','ERROR',f'Duplicate unit id: {uid}'))
            else: ids[uid]=e
        if qty>1 and uid and any(x.get('target_unit_id')==uid for x in roster.get('enhancements',[])):
            out['checks'].append(result('ambiguous_target','ERROR',f'Unit id {uid} has quantity >1 but is enhancement-targeted; split copies into separate entries.'))
        for i in range(qty):
            copies[norm(u['name_en'])]+=1
            try: total_points += unit_cost(u,copies[norm(u['name_en'])],models,e.get('wargear',[]))
            except ValueError as ex: out['checks'].append(result('unit_cost','ERROR',str(ex)))
        unit_rows.append((e,u,qty))
    # Duplicate unit limits.
    for key,count in copies.items():
        canonical=next((u['name_en'] for u in faction['units'] if norm(u['name_en'])==key),key)
        if key in catsets.get('epic_hero',set()): limit=CORE['unit_selection']['epic_hero_unit_limit']
        else:
            mult=CORE['unit_selection']['battleline_unit_limit_multiplier'] if key in catsets.get('battleline',set()) else 1
            if key in catsets.get('dedicated_transport',set()): mult=max(mult,CORE['unit_selection']['dedicated_transport_unit_limit_multiplier'])
            limit=br['unit_limit']*mult
        sev='PASS' if count<=limit else 'ERROR'
        out['checks'].append(result('unit_limit',sev,f'{canonical}: {count}/{limit} copies',unit=canonical,count=count,limit=limit))

    # Detachments and DP.
    dets=roster.get('detachments',[]); seen=Counter(norm(x) for x in dets); dp=0; tags=defaultdict(list); valid_dets=[]
    for name in dets:
        d=det_lookup.get(norm(name))
        if not d: out['checks'].append(result('detachment_known','ERROR',f'Unknown current-MFM detachment: {name}')); continue
        valid_dets.append(d); dp+=int(d['dp'])
        for tag in d.get('unique_tags',[]): tags[tag].append(d['name_en'])
    for n,c in seen.items():
        if c>1: out['checks'].append(result('detachment_duplicate','ERROR',f'Same detachment selected {c} times: {n}'))
    for tag,names in tags.items():
        if len(names)>1: out['checks'].append(result('detachment_unique_tag','ERROR',f'Unique tag {tag} conflict: {", ".join(names)}'))
    dp_ok=dp<=br['detachment_points_limit']
    if battle=='incursion' and len(valid_dets)==1 and dp==3: dp_ok=True
    out['checks'].append(result('detachment_points','PASS' if dp_ok else 'ERROR',f'Detachment Points: {dp}/{br["detachment_points_limit"]}'+(' (Incursion single-3DP exception)' if battle=='incursion' and dp==3 and len(valid_dets)==1 else ''),used=dp,limit=br['detachment_points_limit']))

    # Enhancements.
    enh=roster.get('enhancements',[]); counted_choices=0; upgrade_seen=Counter(); standard_seen=Counter(); target_seen=Counter()
    for e in enh:
        key=(norm(e.get('detachment','')),norm(e.get('name',''))); pts=enh_cost.get(key)
        if pts is None:
            out['checks'].append(result('enhancement_known','ERROR',f'Unknown enhancement/detachment combination: {e.get("name")} / {e.get("detachment")}')); continue
        total_points += int(pts)
        meta=enh_type.get(key); is_upgrade=meta['is_upgrade'] if meta else None
        tid=e.get('target_unit_id'); target=ids.get(tid) if tid else None
        if not tid or not target:
            out['checks'].append(result('enhancement_target','ERROR',f'Enhancement {e.get("name")} needs a valid target_unit_id.')); continue
        tu=find_unit(faction,target['name']); tname=norm(tu['name_en']) if tu else ''
        target_seen[tid]+=1
        if target_seen[tid]>1: out['checks'].append(result('enhancement_per_unit','ERROR',f'Unit {tid} has more than one enhancement.'))
        if tname in catsets.get('epic_hero',set()): out['checks'].append(result('enhancement_epic_hero','ERROR',f'Epic Hero {tu["name_en"]} cannot receive an enhancement.'))
        if is_upgrade is True:
            upgrade_seen[key]+=1
            if upgrade_seen[key]>CORE['enhancements']['upgrade_max_same_enhancement']:
                out['checks'].append(result('upgrade_copy_limit','ERROR',f'{e["name"]}: more than 3 Upgrade copies.'))
            if upgrade_seen[key]==1: counted_choices+=1
            out['warnings'].append(f'{e["name"]}: Upgrade target restriction is detachment-specific and not yet globally executable.')
        elif is_upgrade is False:
            standard_seen[key]+=1; counted_choices+=1
            if standard_seen[key]>1: out['checks'].append(result('enhancement_duplicate','ERROR',f'Non-Upgrade enhancement duplicated: {e["name"]}'))
            if tname not in catsets.get('character',set()): out['checks'].append(result('enhancement_character','ERROR',f'{e["name"]} targets non-Character {tu["name_en"]}.'))
        else:
            counted_choices+=1
            out['unknowns'].append(f'Enhancement type (Upgrade vs standard) not normalized for {e["detachment"]} / {e["name"]}; targeting semantics not fully certified.')
    out['checks'].append(result('enhancement_limit','PASS' if counted_choices<=br['enhancement_limit'] else 'ERROR',f'Enhancement choices counted: {counted_choices}/{br["enhancement_limit"]}',count=counted_choices,limit=br['enhancement_limit']))

    # Warlord.
    wid=roster.get('warlord_unit_id'); we=ids.get(wid) if wid else None
    if not we: out['checks'].append(result('warlord','ERROR','A valid warlord_unit_id is required.'))
    else:
        wu=find_unit(faction,we['name']); wk=norm(wu['name_en'])
        if wk not in catsets.get('character',set()): out['checks'].append(result('warlord_character','ERROR',f'Warlord {wu["name_en"]} is not classified as Character.'))
        elif wk not in catsets.get('warlord_eligible',set()): out['checks'].append(result('warlord_faction','ERROR',f'{wu["name_en"]} does not have the selected army faction keyword for Warlord eligibility.'))
        else: out['checks'].append(result('warlord','PASS',f'Warlord: {wu["name_en"]}'))

    # Leader/support assignments.
    attach=roster.get('attachments',[]); attached_chars=set(); per_body=defaultdict(lambda:Counter())
    for a in attach:
        cid=a.get('character_unit_id'); bid=a.get('bodyguard_unit_id'); ce=ids.get(cid); be=ids.get(bid)
        if not ce or not be:
            out['checks'].append(result('attachment_ids','ERROR',f'Invalid attachment ids: {cid} -> {bid}')); continue
        cu=find_unit(faction,ce['name']); bu=find_unit(faction,be['name']); link=rel_by_char.get(norm(cu['name_en']))
        if not link:
            out['checks'].append(result('attachment_relation','ERROR',f'{cu["name_en"]} has no current Leader/Support relation.')); continue
        if norm(bu['name_en']) not in {norm(x) for x in link['can_join']}:
            out['checks'].append(result('attachment_bodyguard','ERROR',f'{cu["name_en"]} cannot join {bu["name_en"]}.')); continue
        rel=link['relation'].upper(); per_body[bid][rel]+=1; attached_chars.add(cid)
        out['checks'].append(result('attachment','PASS',f'{cu["name_en"]} ({rel}) -> {bu["name_en"]}'))
    for bid,c in per_body.items():
        if c['LEADER']>1: out['checks'].append(result('leader_per_bodyguard','ERROR',f'{bid}: more than one Leader attached.'))
        if c['SUPPORT']>1: out['checks'].append(result('support_per_bodyguard','ERROR',f'{bid}: more than one Support attached.'))
    for uid,e in ids.items():
        u=find_unit(faction,e['name']); link=rel_by_char.get(norm(u['name_en'])) if u else None
        if link and link['relation'].upper()=='SUPPORT' and uid not in attached_chars:
            out['checks'].append(result('support_must_attach','ERROR',f'Support unit {u["name_en"]} ({uid}) is not attached.'))

    # Dedicated transports must have something embarked. Capacity/eligibility stays unverified.
    loads={x.get('transport_unit_id'):x.get('embarked_unit_ids',[]) for x in roster.get('dedicated_transport_loads',[])}
    for uid,e in ids.items():
        u=find_unit(faction,e['name']); key=norm(u['name_en']) if u else ''
        if key in catsets.get('dedicated_transport',set()):
            embarked=loads.get(uid,[])
            if not embarked: out['checks'].append(result('dedicated_transport_loaded','ERROR',f'{u["name_en"]} ({uid}) has no friendly unit assigned as embarked at Declare Battle Formations.'))
            else:
                bad=[x for x in embarked if x not in ids or x==uid]
                if bad: out['checks'].append(result('dedicated_transport_load_ids','ERROR',f'{uid}: invalid embarked ids {bad}'))
                else: out['checks'].append(result('dedicated_transport_loaded','PASS',f'{u["name_en"]} ({uid}) starts with {len(embarked)} unit(s) embarked.'))
                out['unknowns'].append(f'{u["name_en"]} ({uid}): transport capacity and passenger keyword eligibility are not yet globally normalized.')

    # Points cap.
    out['points']={'total':total_points,'limit':br['points_limit']}
    out['checks'].append(result('points_limit','PASS' if total_points<=br['points_limit'] else 'ERROR',f'Points: {total_points}/{br["points_limit"]}',total=total_points,limit=br['points_limit']))
    # Full faction detachment restrictions are deliberately not claimed.
    if valid_dets: out['unknowns'].append('Detachment-specific army composition/restriction clauses are only partially normalized; core legality can pass while faction-specific legality remains UNVERIFIED.')
    errors=sum(1 for x in out['checks'] if x['severity']=='ERROR')
    out['summary']={'errors':errors,'unknown_count':len(out['unknowns']),'warning_count':len(out['warnings']),
                    'core_legality':'FAIL' if errors else 'PASS',
                    'certification':'FAIL' if errors else ('PASS_WITH_UNVERIFIED_FACTION_RULES' if out['unknowns'] else 'CURRENT_CERTIFIED')}
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 1 if errors else 0
if __name__=='__main__': raise SystemExit(main())
