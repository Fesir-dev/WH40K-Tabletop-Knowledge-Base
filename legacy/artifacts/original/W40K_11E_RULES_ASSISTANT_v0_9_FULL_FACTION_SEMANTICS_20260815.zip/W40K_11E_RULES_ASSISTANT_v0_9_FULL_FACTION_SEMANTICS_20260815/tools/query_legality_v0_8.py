#!/usr/bin/env python3
import argparse,json,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def n(s):return ' '.join(unicodedata.normalize('NFKC',str(s)).casefold().replace('’',"'").split())
ap=argparse.ArgumentParser();ap.add_argument('query',nargs='?',default='');ap.add_argument('--faction');args=ap.parse_args();q=n(args.query)
files=['enhancement_target_predicates_v0_8_20260815.json','transport_profiles_v0_8_20260815.json','supreme_commander_rules_v0_8_20260815.json','faction_composition_rules_v0_8_20260815.json','army_availability_overrides_v0_8_20260815.json','enhancement_name_aliases_v0_8_20260815.json']
hits=[]
for fn in files:
 d=json.loads((ROOT/'data'/fn).read_text(encoding='utf-8'))
 def walk(x,path=''):
  if isinstance(x,dict):
   f=x.get('faction') or x.get('army_faction')
   if (not args.faction or f==args.faction or f is None) and (not q or q in n(json.dumps(x,ensure_ascii=False))):hits.append({'file':fn,'path':path,'record':x})
   for k,v in x.items():
    if isinstance(v,(dict,list)):walk(v,path+'/'+str(k))
  elif isinstance(x,list):
   for i,v in enumerate(x):walk(v,path+'/'+str(i))
 walk(d)
# de-duplicate by record JSON; prefer smaller nested records over parents.
seen=set();out=[]
for h in reversed(hits):
 k=json.dumps(h['record'],ensure_ascii=False,sort_keys=True)
 if k not in seen:seen.add(k);out.append(h)
print(json.dumps(list(reversed(out[-50:])),ensure_ascii=False,indent=2))
