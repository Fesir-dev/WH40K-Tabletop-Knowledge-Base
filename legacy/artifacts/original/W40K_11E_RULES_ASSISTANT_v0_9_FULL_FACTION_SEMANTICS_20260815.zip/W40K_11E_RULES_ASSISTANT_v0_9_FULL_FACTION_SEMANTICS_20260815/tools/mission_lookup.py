#!/usr/bin/env python3
from pathlib import Path
import json, sys
p=Path(__file__).resolve().parents[1]/'data'/'tournament_mission_pool.json'
data=json.loads(p.read_text(encoding='utf-8'))
q=(sys.argv[1] if len(sys.argv)>1 else '').strip().lower()
for m in data:
    if q in {m['code'].lower(),m['primary_mission'].lower(),m['deployment'].lower()} or q in m['primary_mission'].lower() or q in m['deployment'].lower():
        print(json.dumps(m,ensure_ascii=False,indent=2))
