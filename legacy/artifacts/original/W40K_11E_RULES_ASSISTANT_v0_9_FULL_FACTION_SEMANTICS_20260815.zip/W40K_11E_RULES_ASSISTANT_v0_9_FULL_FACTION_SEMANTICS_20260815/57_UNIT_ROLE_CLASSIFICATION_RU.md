# v0.7 — Current Unit Role Classification

Файл `data/unit_roles_current_v0_7_20260815.json` нормализует специальные категории unit для всех 8 пользовательских фракций:

- BATTLELINE;
- DEDICATED TRANSPORT;
- EPIC HERO;
- CHARACTER;
- Warlord-eligible native faction Characters.

Категории сверены с текущим 11e live layer и затем отфильтрованы по фактическому current MFM v1.2 pool, поэтому Legends/чужие allied entries не могут случайно попасть в локальный runtime.

`tools/validate_unit_roles_v0_7.py` проверяет, что все classified names существуют в current MFM, EPIC HERO является подмножеством CHARACTER, а Warlord-eligible — подмножеством CHARACTER.

`tools/query_unit_role_v0_7.py` позволяет быстро проверить роль:

```bash
python tools/query_unit_role_v0_7.py "Custodian Guard" adeptus_custodes
python tools/query_unit_role_v0_7.py "Kairos Fateweaver" thousand_sons
```

Второй пример специально показывает различие между `CHARACTER` и `warlord_eligible`: союзный Character может быть доступен армии, но не иметь faction keyword, необходимого для Warlord этой army faction.
