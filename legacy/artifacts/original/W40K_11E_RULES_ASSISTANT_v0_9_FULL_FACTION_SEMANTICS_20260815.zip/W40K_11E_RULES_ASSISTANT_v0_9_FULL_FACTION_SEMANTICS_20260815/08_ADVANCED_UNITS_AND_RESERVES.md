# Advanced Units and Reserves

## Monsters and Vehicles (`17`)

### Movement

During Normal or Advance, MONSTER/VEHICLE models can move through friendly and enemy models except other MONSTER/VEHICLE models.

### FRAME

Measure all positional relationships to the closest point of the FRAME model, not necessarily the base. This affects range, engagement, objectives, auras and setup distances.

### Shooting at engaged Monsters/Vehicles

An engaged enemy MONSTER/VEHICLE can be targeted by ranged attacks in the shooter's Shooting phase. Subtract 1 from the hit roll, except qualifying close-quarters attacks from a unit engaged with that target.

This rule does not make an engaged attacking unit eligible to shoot by itself. The attacker still needs a legal shooting type, usually Close-quarters Shooting.

## Transports (`18`)

### Embark

After a Normal, Advance or Fall-back move, a unit may embark if:

- every model is within 3";
- it was not set up this turn;
- datasheet permits it;
- capacity is sufficient.

Embarked units are not on the battlefield.

### Disembark modes

#### Rapid Disembark - 3"

Used after the transport made a Normal or Ingress move. Unit cannot charge that turn.

#### Tactical Disembark - 3"

Used when transport remained stationary or has not moved yet and setup is possible. After setup, immediately select the unit to make a Normal or Advance move.

#### Combat Disembark - 6"

Fallback mode when other modes do not apply. Hazard roll per model. Can set up engaged with enemies the transport is engaged with. Unit becomes battle-shocked and cannot charge.

### Emergency Disembark - 6"

After transport destruction:

- hazard roll per model;
- set up as close as possible within 6";
- models that cannot be placed are destroyed;
- unit becomes battle-shocked and cannot charge.

Resolve embarked-unit emergency disembark before Deadly Demise.

## Attached units (`19`)

### Formation

One bodyguard unit can normally have one Leader and one Support. The combination is one unit for rules purposes.

### Toughness

- While any bodyguard remains: use highest bodyguard Toughness.
- If no bodyguard remains: use highest Leader/Support Toughness.

### Keywords

The unit has every keyword possessed by any component unit. Individual models do not inherit each other's keywords.

Consequences:

- `[ANTI-PSYKER]` can affect the whole unit because a Leader is a PSYKER.
- A rule requiring a PSYKER model still applies only to the actual PSYKER model.

### Ability persistence

A unit-wide ability lasts until its source is destroyed. If destroyed by an attack, it persists until the attacking unit finishes all its attacks. A Leader's “while leading” ability can continue after the bodyguard dies if it began the battle attached.

## Strategic Reserves (`20`)

### Pre-battle cap

Normally up to 50% of the army's points limit can be placed in Strategic Reserves, including passengers inside reserved transports.

### Standard Ingress

- normally from battle round 2;
- wholly within 6" of one or more battlefield edges;
- more than 8" horizontally from all enemies;
- before round 3, not inside opponent deployment zone;
- normally no other move until the start of the next Charge phase.

At end of battle round 3, unused reserve units are destroyed, excluding listed transport/reposition exceptions.

### Deep Strike

If every model has Deep Strike, an Ingress move may set up anywhere more than 8" from enemies, including opponent deployment zone.

### Repositioned units

Persistent state is retained:

- Advance/Fall-back/Disembark history remains;
- Battle-shock remains for its duration;
- timed effects remain while their conditions continue;
- aura effects depend on the unit's new position.

## Surge moves (`21.02`)

Eligible only if triggered, unengaged, not battle-shocked and not already moved in the phase.

- choose closest enemy as target;
- engage it if possible, otherwise get as close as possible;
- cannot contact a different enemy;
- cannot move again that phase.

## Aircraft (`23`)

- Must begin in Strategic Reserves.
- Can only make Ingress moves.
- At end of opponent's turn, return all battlefield AIRCRAFT to Strategic Reserves.
- Other models can move through AIRCRAFT.
- Non-FLY units generally ignore AIRCRAFT when selecting closest enemy for pile-in, consolidation or surge.
- AIRCRAFT cannot charge; can melee only FLYING units.
- Only FLYING units can charge or melee AIRCRAFT.
- Plunging Fire does not apply to or from AIRCRAFT.
