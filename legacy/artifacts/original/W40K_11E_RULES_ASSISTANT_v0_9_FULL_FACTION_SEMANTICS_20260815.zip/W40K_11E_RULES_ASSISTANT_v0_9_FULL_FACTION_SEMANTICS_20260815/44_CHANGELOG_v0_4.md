# Changelog v0.4

- Импортирован официальный live snapshot MFM от 2026-07-10.
- Добавлено 282 записей unit points с duplicate-copy bands.
- Добавлено 79 detachments с Detachment Points, Force Dispositions и unique-tags.
- Добавлено 267 enhancement costs.
- Добавлено 74 Leader/Support links.
- Добавлено 43 оперативных проверок Balance Dataslate v3.3.
- Исправлены пороги стоимости повторных копий, размеры Hastarii, Goremongers и Khorne Berzerkers.
- Исправлены официальные названия World Eaters и Thousand Sons units.
- Исправлены enhancement names/costs для Adeptus Mechanicus, Genestealer Cults, Imperial Knights, Thousand Sons и World Eaters.
- Исправлено платное wargear Defiler и Forgefiend.
- Добавлены `cost_roster.py`, `check_detachments.py`, `leader_lookup.py`.
- QA: base validator + live-layer validator + roster smoke tests.
