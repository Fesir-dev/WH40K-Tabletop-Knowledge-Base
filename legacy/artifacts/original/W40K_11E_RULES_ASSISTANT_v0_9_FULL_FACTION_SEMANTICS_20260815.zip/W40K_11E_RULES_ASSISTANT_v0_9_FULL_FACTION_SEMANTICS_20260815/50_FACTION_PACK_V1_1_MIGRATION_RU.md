# Faction Pack v1.1 — migration

Все восемь пользовательских фракций имеют текущий `rules_updates_v1_1_20260722.json` и verified SHA-256 внешнего официального v1.1 PDF.

Правила в JSON намеренно хранятся как semantic summaries, а не как полные копии текста. Для точной формулировки применяется текущий официальный PDF/app.

Points/DP/Force Dispositions не дублируются из Faction Pack: они живут в current MFM 1.2 runtime.
