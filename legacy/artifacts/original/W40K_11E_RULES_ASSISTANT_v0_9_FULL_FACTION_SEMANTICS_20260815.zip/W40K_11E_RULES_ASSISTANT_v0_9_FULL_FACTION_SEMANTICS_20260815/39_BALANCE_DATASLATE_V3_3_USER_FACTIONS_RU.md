> **HISTORICAL 10E/TRANSITION EVIDENCE ONLY:** этот v3.3 snapshot не является самостоятельным current 11e rules override. Для v0.6 использовать Universal Rules Updates v1.0 + Faction Pack v1.1 + current App/MFM.

# Balance Dataslate v3.3 — восемь армий пользователя

Проверено: 2026-07-10. Файл содержит оперативные пересказы, а не замену официального текста.

## Адептус Кустодес

- **Shield Host – Martial Mastery**: Выбор одного пункта производится в начале боевого раунда; эффект действует до начала следующего боевого раунда.
- **Auric Champions – Assemblage of Might**: В начале своей Command phase выбирается вражеский отряд; CHARACTER-отряды Custodes получают +1 к wound против него до следующей Command phase.
- **Shield-Captain on Dawneagle Jetbike**: T 7, W 8.
- **Salvo launcher**: 24", A1, BS2+, S10, AP-3, D D6+1, Twin-linked.
- **Vertus hurricane bolter**: 18", A3, BS2+, S4, AP-1, D2, Rapid Fire 3, Twin-linked.
- **Vertus Praetors**: T 7, W 5. Quicksilver Execution: один раз за бой после Normal/Advance можно выбрать не-MONSTER/VEHICLE цель, над которой прошёл отряд; за каждую модель бросить D6, на 2+ цель получает 2 mortal wounds.

## Адептус Механикус

- **Doctrina Imperatives – Protector**: Ranged weapons получают Heavy; BS улучшается на 1; вражеские melee attacks имеют -1 hit против Battleline-отряда или отряда в 6" от friendly Battleline.
- **Doctrina Imperatives – Conqueror**: Ranged weapons получают Assault; WS melee weapons улучшается на 1; атаки получают AP +1, если отряд Battleline или в 6" от friendly Battleline.
- **Cohort Cybernetica**: LEGIO CYBERNETICA получает +2" M и +1 OC, пока отряд не Battle-shocked.
- **Haloscreed – Transoracular Dyad Wafers**: Только Datasmith; прикреплённые Kastelan получают Halo Override и больше не могут выбираться Noospheric Transference.
- **Faction ability additions**: Doctrina Imperatives добавлена Cawl, Corpuscarii, Datasmith, Fulgurite, Kastelan, Dominus, Enginseer, Manipulus и Technoarcheologist.
- **Belisarius Cawl**: M 8. Canticles выбирается в начале Command phase. Machine Vengeance отмечает цель и даёт reroll hit. Mantra делает Cawl Battleline и даёт aura +1 OC и +1 к Battle-shock/Leadership. Shroudpsalm aura даёт Stealth.
- **Weapon profiles**: Обновлены Solar atomiser, Onager missile/beamer/neutron/phosphor, Ironstrider autocannon/lascannon, ferrumite cannon, Sicarian Infiltrators и Ruststalkers. Полные профили сохранены в официальном v3.3; перед расчётом урона сверять их.

## Демоны Хаоса

- **Balance Dataslate v3.3**: Отдельного раздела Chaos Daemons в оглавлении нет. Использовать Faction Pack, Core Dataslate changes и актуальный app/MFM.

## Космодесант Хаоса

- **Dread Talons – Screaming Descent**: Размещение более чем в 6" от врага; заряд в этот ход запрещён; затем один видимый INFANTRY/MOUNTED отряд в 9" проходит Battle-shock.
- **Chaos Predator Annihilator**: При распределении ranged attack в MONSTER/VEHICLE можно перебросить Damage roll.
- **Heretic Astartes Daemon Prince**: Получает Lone Operative, пока находится в 3" от friendly HERETIC ASTARTES INFANTRY.
- **Lord Discordant**: M 14", invulnerable save 4+. Corrupt Machine Spirits наносит Vehicle mortal wounds по таблице D6; Spirit Thief отмечает Vehicle и даёт friendly HERETIC ASTARTES reroll wound 1 против него.
- **Impaler chainglaive**: Melee, A5, WS2+, S8, AP-3, D3, Lance.
- **Vashtorr**: Lone Operative рядом с friendly DAEMON VEHICLE; Reorder Reality даёт атакующему -1 hit и Hazardous; Unholy Mechanisms aura даёт friendly DAEMON VEHICLE weapons +2 S. Hammer: strike A6 S14 AP-3 D3; sweep A12 S8 AP-1 D2, оба Anti-Vehicle 4+ и Devastating Wounds.
- **Warp Talons**: В конце Fight phase, если уничтожили вражеский отряд и не engaged, могут уйти в Strategic Reserves.

## Культы генокрадов

- **Cult Ambush – Resurgence pool**: Incursion 6, Strike Force 10, Onslaught 14 Resurgence points.
- **Cult Ambush – return costs**: Aberrants 5/10: 4/8; Acolytes и Metamorphs 5/10: 2/4; Atalan 5/10: 2/6; Neophytes 10/20: 3/6; Purestrain 5/10: 2/6.
- **Cult Ambush – process**: За RP создаётся идентичный отряд в Cult Ambush на Starting Strength; marker 32 mm ставится более чем в 9". Cult Ambush считается Strategic Reserves и не использует Rapid Ingress. Marker удаляется, если non-Aircraft враг завершает движение в 9". В конце Reinforcements шага следующей Movement phase противника отряд ставится более чем в 9", касаясь marker, остальные модели wholly within 3".
- **Biosanctic – Evasive Vanguard**: После завершения врагом движения в 9" marker можно перенести более чем в 9" от всех врагов до его удаления.
- **Host of Ascension**: Primed and Readied стоит 2CP; Return to the Shadows применяется в конце Fight phase противника к не-engaged INFANTRY; Tunnel Crawlers ставит более чем в 6".
- **Outlander Claw**: Mounted/Vehicle получают +1 OC, пока не Battle-shocked; Jackals могут удерживать objective до превышения противником Level of Control. Along Shadowed Trails перемещает marker более чем в 9".
- **Xenocreed**: Deeds That Speak to the Masses даёт +2 Resurgence points; The Downtrodden Rise выставляет Cult Ambush unit более чем в 6" без marker.
- **Datasheets**: Demolition charges/caches имеют range 8". Kelermorph реагирует на движение врага в 9" стрельбой и D6 Normal move. Primus даёт ведущему отряду +1 hit.

## Имперские Рыцари

- **Valourstrike Lance – Bold Gallantry**: После Advance ranged weapons IMPERIAL KNIGHTS получают Assault до конца хода.
- **Run Them Through!**: Цель — IMPERIAL KNIGHTS unit, ещё не выбранный для fight в этой фазе.
- **Full Tilt**: Цель — IMPERIAL KNIGHTS unit, ещё не выбранный для move в этой фазе.
- **Vow of Retribution**: Цель — IMPERIAL KNIGHTS unit, ещё не выбранный для shoot в этой фазе.

## Тысяча Сынов

- **Cabal of Sorcerers**: В начале Shooting phase модели по одной пытаются проявить Rituals: модель не может повторно пытаться в этот ход, и один Ritual не может повторно выбираться армией в этот ход, кроме прямого исключения.
- **Destiny’s Ruin**: Видимая цель в 24": THOUSAND SONS/SCINTILLATING LEGIONS reroll hit 1; при Psychic test 10+ — полный reroll hit.
- **Temporal Surge**: Friendly не-engaged unit в 24" делает Normal move D6", либо до 6" при 10+; charge в этот ход запрещён.
- **Twist of Fate**: Видимая цель в 24": AP улучшается на 1; при 12+ — на 2.
- **Grand Coven – Incandaeum**: Только Exalted Sorcerer; один раз за бой может выбрать Doombolt, даже если другой model уже пытался проявить его в этой фазе.
- **Sorcerer in Terminator Armour**: Marked by Fate: в начале Shooting phase выбрать видимую цель; ведущий отряд получает +1 hit против неё до конца фазы.
- **Kairos Fateweaver**: Infernal Gateway: 24"; Witchfire D6+3 attacks S9 AP-2 D3; Focused D3+6 attacks S9 AP-2 D3, Hazardous; оба Blast, Indirect Fire, Psychic.
- **Lord of Change**: Bolt of Change: 18", 9 attacks; normal S9 AP-1 D1, focused S9 AP-2 D3 Hazardous; Rod of Sorcery: 18", A6, S8 AP-1 D2.

## Пожиратели Миров

- **Exalted Eightbound – Rend and Tear**: Melee attacks против MONSTER/VEHICLE получают +1 Damage до конца фазы.
- **Slaughterbound – lacerator and daemonic claw**: Melee, A6, WS2+, S10, AP-2, D2.
