# Схема армейского слоя

Для каждой фракции создаётся каталог `factions/<slug>/`:

- `source_manifest.json` — faction pack/Codex, errata, app snapshot, MFM version.
- `faction_rules.json` — army rules с timing/target/effect/restrictions.
- `detachments.json` — detachment rules, DP, Force Disposition.
- `datasheets.json` — profiles, weapons, abilities, keywords, composition, wargear.
- `leaders_and_support.csv` — кто к кому присоединяется.
- `enhancements.json` — restrictions, timing, cost/DP.
- `stratagems.json` — type, CP, timing, target, effect, restrictions.
- `points.csv` — points и sizes с version/date.
- `quick_reference_ru.md` — краткая памятка.
- `tactical_archetypes_ru.md` — роли units, matchups, scoring plan.
- `regression_tests.json` — спорные взаимодействия фракции.

## Обязательные поля правила

`id`, `name_en`, `name_ru`, `source_id`, `source_locator`, `version`, `timing`, `actor`, `target`, `cost`, `conditions`, `effect`, `duration`, `keywords`, `exceptions`, `notes`, `verified`.

## Обязательные QA

- каждый points entry связан с MFM snapshot;
- unit size и points-per-size не смешаны;
- Leader links проверены по MFM и datasheet;
- DP и Force Disposition проверены;
- weapon profiles не объединены, если различаются BS/WS/S/AP/D или abilities;
- exact wording сохранён только в пределах необходимого для личной справки; русское описание отдельно помечено как paraphrase;
- ни один preview не назначен нормативным источником.

Готовый шаблон: `templates/faction_profile_template.json`.
