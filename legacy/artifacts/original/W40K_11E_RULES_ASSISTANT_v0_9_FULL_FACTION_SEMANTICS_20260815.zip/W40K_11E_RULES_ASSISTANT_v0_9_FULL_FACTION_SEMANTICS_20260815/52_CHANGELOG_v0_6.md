# v0.6 LIVE changelog

- Migrated eight user factions to MFM 1.2 (official update 2026-07-22).
- Added current per-faction point/detachment files and immutable v1.0 historical copies.
- Reconciled duplicate-copy taxes, Detachment Points and Force Dispositions.
- Added Faction Pack v1.1 semantic delta JSON for all eight factions.
- Added current monolithic runtime + machine-readable MFM diff.
- Routed costing/detachment/leader tools to current runtime.
- Added current-MFM validator and version diff tool.
- Preserved historical 2026-07-10 snapshot for provenance.

- Reconciled current-facing docs and generic aliases to prevent stale v1.0 fallback.
- Added `query_current.py` for current-only MFM/Faction Pack search.
- Added `validate_rules_updates_v1_1.py` and executable `run_current_regressions.py`.
- Historical BDS v3.3 is explicitly quarantined as historical evidence.
