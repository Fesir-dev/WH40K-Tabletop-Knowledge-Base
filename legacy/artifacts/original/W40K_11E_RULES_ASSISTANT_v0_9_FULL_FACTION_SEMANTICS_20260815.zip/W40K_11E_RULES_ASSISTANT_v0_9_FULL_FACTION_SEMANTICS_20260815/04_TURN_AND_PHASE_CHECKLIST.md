# Turn and Phase Checklist

## Battle round

1. Start of battle round triggers.
2. First player's turn.
3. Second player's turn.
4. End-of-round non-mission triggers.
5. End-of-round mission scoring/triggers.

The same player takes the first turn in every battle round unless the mission says otherwise (`07.02`).

## Start of turn

- Resolve all “start of turn” rules.
- Confirm active and opposing player.
- Record current CP, secured objectives, ongoing actions and persistent effects.

## Command phase

1. Start-of-Command triggers (`08.01`).
2. **Both players gain 1 Core CP** (`08.02`).
3. Battle-shock rolls for every active-player unit that:
   - is already battle-shocked; and/or
   - is at or below half-strength (`08.03`).
4. Command-phase abilities (`08.04`).
5. End-of-Command non-mission triggers, then mission triggers (`08.05`).

Battle-shock reminder:

- OC becomes `-`;
- controller cannot target the unit with stratagems;
- cannot start an action;
- cannot complete an action already started.

## Movement phase

For every unit, including units in reserves or transports, select exactly one legal move type (`09.02`).

- Remain Stationary.
- Normal Move.
- Advance Move.
- Fall-back Move.
- Disembark Move.
- Ingress Move.
- Other rule-defined move.

Checklist before ending each move:

- coherency legal;
- no model embedded in model/terrain surface;
- engagement condition legal;
- all “After Moving” clauses met;
- action/shoot/charge restrictions recorded.

### Move consequences

- Advance: normally cannot charge or start an action.
- Fall Back: normally cannot shoot, charge or start an action.
- Battle-shocked Fall Back normally forces Desperate Escape.
- Desperate Escape: hazard roll per model; can move through enemy models; may require a Battle-shock roll afterward.

## Shooting phase

For each selected unit:

1. Confirm it is on the battlefield and has not already been selected to shoot.
2. Select one legal shooting type:
   - Normal;
   - Assault;
   - Close-quarters;
   - Indirect;
   - Snap or another rule-defined type.
3. Select weapons model by model.
4. Select targets weapon by weapon.
5. Resolve attacks by target and identical attack pool.
6. Apply post-shooting action restrictions.

A unit can be eligible to shoot even if it has no ranged weapons; it simply cannot make ranged attacks. This matters for actions and other rules.

## Charge phase

For each charging unit:

1. Confirm it is on the battlefield, unengaged, within 12" of an enemy, and did not Advance/Fall Back unless an exception applies.
2. Declare the charge.
3. Roll 2D6.
4. Choose charge targets that are both within 12" and within the rolled maximum distance.
5. Verify the unit can end engaged with every declared target and no undeclared enemy.
6. Move models, obeying closer/within-1"/engaged-if-possible requirements.
7. Mark all models in the unit as Fights First until end of turn.

## Fight phase

### Step 1 - Start triggers

Resolve start-of-Fight rules.

### Step 2 - Pile in

- Active player moves all chosen eligible units first.
- Opponent then moves all chosen eligible units.
- Eligible: engaged, charged this turn, or selected for an overrun fight.
- Base-contact models cannot move.
- Maintain engagement with every enemy unit the model started engaged with.

### Step 3 - Fight

1. Resolve Fights First combats, alternating, starting with the player whose turn it is.
2. Resolve remaining combats, starting with the player who transitioned the sequence into this step.
3. Re-enter Fights First if a new Fights First unit becomes eligible.
4. Every eligible unit must ultimately fight unless the special “eligible but unable” pass rule applies.

Fight types:

- Normal Fight: unit is engaged.
- Overrun Fight: unit is unengaged, or began the Fight step unengaged and later became engaged; make an extra pile-in then fight.

### Step 4 - Consolidate

- Active player moves eligible units first; opponent second.
- Modes are mandatory in order:
  1. Ongoing Consolidation if engaged.
  2. Engaging Consolidation if unengaged and within 3" of enemy.
  3. Objective Consolidation if neither above and within 3" of objective.
- Engaging a unit that has not fought can immediately make it eligible and selected to fight.

### Step 5 - End triggers

Resolve end-of-Fight rules.

## End of turn

1. Resolve non-mission end-of-turn triggers.
2. Resolve mission end-of-turn triggers/scoring.
3. Check unit coherency and destroy models until legal.
4. Update secured objectives and expiring effects.
