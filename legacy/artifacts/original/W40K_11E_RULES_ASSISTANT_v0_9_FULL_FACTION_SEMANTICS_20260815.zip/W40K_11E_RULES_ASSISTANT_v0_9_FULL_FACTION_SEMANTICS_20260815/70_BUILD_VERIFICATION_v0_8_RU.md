# v0.8 — Build Verification

Expected checkpoint QA:

- project structural validation — PASS;
- 8 faction validation — PASS;
- current MFM v1.2 — PASS;
- Faction Pack v1.1 semantic layers — PASS;
- unit-role dataset — PASS;
- 169-entry Stratagem semantic index — PASS;
- Enhancement predicates — 115/115 executable;
- Dedicated Transport profiles — 6/6 current role entries;
- faction legality layer — 7 Supreme / 7 composition / 11 availability overrides;
- v0.6 regressions — 18/18;
- v0.7 regressions — 19/19;
- v0.8 regressions — 25/25;
- Python compilation — PASS.

The release ZIP is valid only after regenerating `project_manifest.json`, `SHA256SUMS.txt`, checking every hash and running archive integrity/path-safety checks.

## Final package counts

- files hashed in `project_manifest.json` (excluding manifest and SHA256SUMS): **334**;
- expected `SHA256SUMS.txt` entries (all files except SHA256SUMS itself): **335**;
- cumulative executable regressions: **62/62 PASS**.
