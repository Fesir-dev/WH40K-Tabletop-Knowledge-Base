# Movement, Charge and Fight Positioning

## Universal movement geometry (`03.01`)

A model can move through:

- friendly models;
- any space its base can physically fit through.

It cannot normally move its base through enemy models or across the battlefield edge.

Measure straight-line segments from the same point on the base. Rotating a based model around the centre of its base costs no movement. FRAME models without bases rotate around their central axis.

## Coherency (`03.03`)

Every model in a multi-model unit must be:

- within 2" horizontally and 5" vertically of at least one other model in the unit; and
- within 9" horizontally and 5" vertically of every other model in the unit.

This is both a local link and a maximum unit diameter rule. Check it at setup and after every move type.

At End of Turn, remove models until the unit is coherent. These models are destroyed but do not trigger “when destroyed” rules.

## Engagement (`03.04`)

Engagement Range is 2" horizontally and 5" vertically.

A unit is engaged if at least one model is engaged. This affects the whole unit's movement and shooting eligibility, even if many models are outside Engagement Range.

## Normal and Advance

- Normal: battlefield, unengaged, move up to M, end unengaged.
- Advance: battlefield, unengaged, move M + D6, end unengaged; normally no charge or action afterward.

## Fall Back

- Eligible only while engaged.
- Ordered Retreat is available if not battle-shocked.
- Desperate Escape is mandatory if Ordered Retreat is unavailable; it may also be chosen voluntarily.
- Desperate Escape: hazard roll per model and models can pass through enemies.
- End unengaged; normally no shoot, charge or action for the rest of turn.

## Monster and Vehicle movement

During Normal or Advance, MONSTER/VEHICLE models can pass through friendly and enemy non-MONSTER/VEHICLE models. They still cannot end overlapping models and remain subject to terrain and final-position legality.

## Flying

Before a Normal, Advance, Fall-back or Charge move, a FLYING unit can take to the skies:

- maximum distance -2";
- ignore vertical distance;
- pass through all models;
- pass through all terrain categories horizontally and vertically.

HOVER removes the -2" penalty.

## Charge legality (`11`)

A charge is not simply “roll high enough.” Before moving:

- declare one or more targets within 12" and within the rolled maximum distance;
- the final unit must be engaged with every declared target;
- the final unit cannot be engaged with undeclared enemies;
- each model must finish closer to a charge target;
- if a model can end within 1" of a target, it must;
- if it can end engaged with a target, it must.

A target can be within the charge roll yet impossible to charge because terrain/pathing prevents the required final engagement.

## Pile-in (`12.03`)

- Separate Fight phase step before attacks.
- Up to 3".
- Base-contact models cannot move.
- If engaged, every engaged enemy unit is a pile-in target.
- If unengaged but eligible, choose enemy unit(s) within 5".
- Each moved model ends closer to the closest pile-in target and engaged if possible.
- A model that began engaged with a specific enemy unit must remain engaged with it.

## Fight order (`12.04`)

### Fights First

Players alternate eligible Fights First units, starting with the player whose turn it is.

### Remaining combats

The player who transitioned the sequence from Fights First to remaining combats selects first. Then alternate.

If a new Fights First unit becomes eligible, return to the Fights First sequence.

## Overrun fight

A unit can make an Overrun Fight if it is eligible to fight but unengaged, or if it began the Fight step unengaged and later became engaged. It gains an additional pile-in move, then fights.

This permits combat chains after a transport is destroyed or a target disappears, but does not waive general fight eligibility.

## Consolidation (`12.08`)

Up to 3", only for a unit that was eligible to fight.

Mandatory mode priority:

1. **Ongoing** - if engaged; remain engaged with all enemies the model began engaged with.
2. **Engaging** - if unengaged and within 3" of enemy; must engage selected enemies.
3. **Objective** - if no enemy mode applies and within 3" of objective; must get within range if possible.

Engaging Consolidation can grant an unfought enemy unit an immediate fight opportunity. Treat it as a deliberate risk, not free movement.

## Positioning questions to ask

- Which individual models are within Engagement Range?
- Is the whole unit coherent after every move?
- Does a declared charge accidentally contact an undeclared unit?
- Are any models in base contact and therefore unable to pile in/consolidate?
- Can the unit maintain engagement with every enemy it was required to retain?
- Does moving onto terrain require vertical distance or a legal keyword?
- Does a movement path require the base to fit, not just the model's body?
