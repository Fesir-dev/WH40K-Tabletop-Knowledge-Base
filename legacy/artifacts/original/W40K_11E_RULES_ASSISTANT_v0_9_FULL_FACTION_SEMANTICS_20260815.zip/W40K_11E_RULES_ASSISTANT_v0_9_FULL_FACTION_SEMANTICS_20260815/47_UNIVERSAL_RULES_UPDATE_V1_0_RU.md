# Universal Rules Updates v1.0 — нормализованный слой

Источник: официальный Games Workshop document, **Version 1.0**, legal for matched play from **22.07.2026**.

Этот checkpoint не копирует документ дословно; он хранит executable-oriented смысловые правила и provenance.

## Нормализованные overrides

1. Generic 0CP effects для неназванного Stratagem трактуются как уменьшение его стоимости на 1CP.
2. Generic разрешение повторно использовать Stratagem не обходит лимит, если правило не называет конкретный Stratagem.
3. Stratagem-based ranged targeting protection, использовавшая 12-inch threshold, стандартизируется на 18 inches.
4. Stratagem, создающий новую копию уничтоженного юнита, получает once-per-battle restriction.

Machine layer: `data/universal_rules_updates_v1_0_20260722.json`.

## Engine consequence

Эти правила должны применяться как global override **после чтения исходного faction/datasheet rule, но до финального ruling**.
