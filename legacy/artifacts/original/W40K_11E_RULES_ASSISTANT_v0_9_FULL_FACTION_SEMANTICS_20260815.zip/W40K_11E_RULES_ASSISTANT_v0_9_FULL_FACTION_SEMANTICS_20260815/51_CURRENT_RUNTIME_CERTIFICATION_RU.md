# Current Runtime Certification — 2026-08-15

**Scope:** восемь пользовательских фракций.

**Certified current locally:** MFM 1.2 points, unit-size bands, duplicate-copy taxes, Detachment Points, Force Dispositions, enhancement costs; Faction Pack v1.1 semantic delta; Universal Rules Updates v1.0.

**Leader/Support:** граф перенесён из MFM snapshot 10.07 после проверки July delta; явных изменений связей в этом migration pass не обнаружено. Точная live-формулировка официального MFM/App всегда имеет приоритет.

**Post-July app:** data v913 затрагивает CSM Cypher только typo/wording correction; v925 не дал выявленных изменений для восьми пользовательских фракций.

**Important:** внешний источник проверяется заново при запросе, чувствительном к актуальности, и перед турнирной подачей ростера.
