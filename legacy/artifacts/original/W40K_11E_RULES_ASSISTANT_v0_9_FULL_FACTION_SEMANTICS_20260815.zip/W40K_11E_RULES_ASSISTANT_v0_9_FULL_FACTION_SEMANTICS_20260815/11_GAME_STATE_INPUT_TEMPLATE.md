# Game State Input Template

Copy this template when asking for a ruling or tactical recommendation.

## Rules question

```text
Question:
Battle round:
Whose turn:
Phase and exact step:
Mission / mission rule involved:

My unit:
- faction and datasheet:
- models remaining and wounds:
- keywords:
- Leader/Support/Bodyguard composition:
- current Battle-shock state:
- move made this turn:
- shot / charged / fought already:
- action status:
- active rules, enhancements and stratagems:

Enemy unit:
- faction and datasheet:
- models remaining and wounds:
- keywords:
- attached composition:
- current state:

Geometry:
- distance between closest models:
- visibility:
- terrain areas and categories:
- objective location/control:
- base contact / engagement details:

Exact rule texts involved:
- source and wording 1:
- source and wording 2:

Desired answer:
- quick legal ruling / deep explanation / probability / best play
```

## Turn analysis

```text
Game size and mission:
Score now:
Battle round and active turn:
CP: me / opponent:
Primary and secondary objectives:

My units:
- position, wounds/models, OC, Battle-shock, available abilities

Opponent units:
- position, wounds/models, OC, likely threat ranges

Terrain and lines of sight:

My candidate plans:
A.
B.
C.

Risk tolerance:
- conservative / balanced / high variance
```

## Damage calculation

```text
Attacker weapon:
Number of models/weapons:
A, BS/WS, S, AP, D:
Abilities:
Hit modifiers/rerolls:
Wound modifiers/rerolls:
Critical thresholds:

Target:
T, Sv, InSv, W per model:
Model count:
Feel No Pain / damage reduction:
Cover and other defensive rules:
Attached-unit groups:

Need:
- expected damage
- kill probability
- full distribution
- compare two weapon modes
```
