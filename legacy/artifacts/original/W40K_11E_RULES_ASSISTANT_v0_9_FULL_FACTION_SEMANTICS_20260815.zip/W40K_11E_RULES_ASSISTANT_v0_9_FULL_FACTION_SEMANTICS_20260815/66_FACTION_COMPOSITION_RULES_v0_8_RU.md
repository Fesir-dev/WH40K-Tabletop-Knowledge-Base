# v0.8 — Faction Composition Rules

`data/faction_composition_rules_v0_8_20260815.json` хранит первые faction-specific muster predicates, которые уже можно безопасно исполнять.

Текущий checkpoint содержит **7 rules**:

1. Thousand Sons — Scintillating Legions: allied point caps + allied models cannot be Warlord.
2. World Eaters — Blood Legions: allied point caps + allied models cannot be Warlord.
3. Genestealer Cults / Final Day — Star Children's Blessings: Tyranids Vanguard Invader subset, exclusions, point cap, no allied Warlord.
4. Imperial Knights / Questor Forgepact — exact Adeptus Mechanicus ally allowlist + 500-point cap.
5. Adeptus Custodes / Solar Spearhead — Moritoi Ancients selection, up to two eligible WALKER models gain CHARACTER.
6. Chaos Space Marines / Pactbound Zealots — Marks of Chaos restrictions, PSYKER/KHORNE restriction, attached-unit and transport mark matching.
7. Chaos Space Marines / Renegade Warband — incompatible Cults of the Dark Gods option forbidden.

Это **не** число всех faction rules. Ненормализованные detachment restrictions остаются gate/UNKNOWN и не достраиваются автоматически.
