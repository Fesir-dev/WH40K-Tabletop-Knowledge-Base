# Changelog v0.5 LIVE — 2026-08-15

- Переведена архитектура source-of-truth с frozen MFM snapshot на official-live-first.
- Зафиксирован текущий официальный Core Rules / Universal Rules Updates / MFM state.
- Добавлен Universal Rules Updates v1.0 normalized override layer.
- Wahapedia 11e добавлена как secondary live source с explicit conflict policy.
- `mfm_live_snapshot_20260710.json` переведён в historical/stale-for-current-points state без удаления.
- Добавлен `live_rules_source_state_20260815.json`.
- Добавлен `validate_source_freshness.py`.
- `cost_roster.py` теперь предупреждает, что старый MFM snapshot нельзя выдавать как гарантированно current.
- Добавлены migration/policy документы 45–47.
- Полный MFM 1.2 re-import оставлен следующим обязательным data migration step.
