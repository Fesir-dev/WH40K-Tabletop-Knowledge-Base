# Chapter Approved Tournament Companion v1.5 — последовательность партии

Эта схема действует для официального турнирного формата Companion v1.5. Она не должна автоматически применяться к casual-игре с полным Chapter Approved deck.

## Подготовка

1. **Muster Armies.** Собрать армии по текущим правилам и MFM.
2. **Determine Mission.** Использовать одну из 20 готовых комбинаций пула; Twists и Challenger cards не применяются.
3. **Read Mission.** Прочитать точный текст Primary и условия начисления VP.
4. **Place Objectives.** Турнирная поправка: плоские круглые маркеры 40 мм, модели могут завершать на них любой тип движения.
5. **Create Battlefield.** Strike Force, примерно 44×60 дюймов; выбрать совместимый layout 1–8.
6. **Attacker/Defender.** Roll-off; победитель выбирает роль.
7. **Select Secondaries.** Оба тайно выбирают Fixed или Tactical; при Fixed также две карты, затем одновременно раскрывают.
8. **Declare Battle Formations.** Тайно записать Leader→Bodyguard, embarked units и Reserves, затем раскрыть.
9. **Deploy Armies.** По одному подразделению, начиная с Defender. После выставления Titanic пропустить следующий свой выбор для deployment.
10. **Redeploy.** Чередование правил redeploy, начиная с Attacker, если не сказано иначе.
11. **First Turn.** Победитель roll-off обязательно получает первый ход.
12. **Pre-battle Rules.** Чередование, начиная с игрока первого хода.
13. **Begin Battle.** Пять battle rounds.
14. **End Battle.** Игра не прекращается из-за полного уничтожения одной армии.
15. **Determine Victor.** Больше VP — победа; равенство — ничья.

## Incursion note

Companion предлагает для Incursion: не более двух units с одним datasheet name, либо четырёх для Battleline/Dedicated Transport, и не более одного Titanic Character. Основные layouts документа всё равно спроектированы прежде всего под Strike Force.

## Reserves

На старте в Reserves можно поместить не более половины подразделений и не более половины points армии. Подразделения внутри транспорта в Reserves учитываются. Обычно нельзя прибыть в первом раунде; не прибывшие к концу третьего считаются destroyed. Исключение Companion относится к подразделениям, помещённым в Strategic Reserves уже в ходе битвы.

## VP

- Primary: максимум 50.
- Secondary: максимум 40.
- Battle Ready: 10.
- Общий максимум: 100.
- Fixed: максимум 20 с каждой выбранной карты.

## Судейский чек перед началом

- версия Companion;
- версия MFM и points snapshot;
- Force Disposition, зафиксированная правилами события;
- mission code A–T;
- terrain layout;
- exact card text;
- event pack deviations;
- base sizes, если событие требует Guide.
