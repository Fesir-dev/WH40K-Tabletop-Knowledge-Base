# v0.7 — Source Conflict Gate

В v0.7 действует fail-safe для конфликтов между версиями источников.

Первый case — revival уничтоженного Character — теперь **RESOLVED**. Июньский Core Rules PDF всё ещё отражает более старую attached-unit логику, однако официальный July Update от 22.07.2026 прямо меняет это поведение: возвращаемый уничтоженный Character возвращается отдельно как unit из одного. По правилу version precedence более новый официальный update перекрывает старый официальный core snapshot.

Registry: `data/source_conflict_registry_v0_7_20260815.json`.

Порядок разрешения:

1. более новый точный официальный rules update/FAQ;
2. официальный app text той же версии;
3. официальный explanatory article, если он явно сообщает изменение относительно старого текста;
4. Wahapedia как current structured cross-check;
5. исторический local snapshot только как evidence/diff.

Если версия/Scope всё равно неоднозначны, движок обязан вернуть `UNKNOWN`, а не угадывать.
