# Реестр живых источников — v0.6 CURRENT

Последняя внешняя проверка: **2026-08-15**.

| ID | Источник | Текущий статус | Роль |
|---|---|---|---|
| CORE_11E_CURRENT_20260815 | Games Workshop Core Rules | 11e, June 2026 | базовая механика |
| UNIVERSAL_RULES_UPDATES_1_0_20260722 | Games Workshop Universal Rules Updates | v1.0, legal 22.07.2026 | глобальные overrides |
| MFM_CURRENT_20260722 | Games Workshop Munitorum Field Manual | **v1.2 / updated 22.07.2026** | points, sizes, Leader/Support, DP, dispositions, enhancements |
| WH40K_APP_11E | Official Warhammer 40,000 App | living | официальный living rules/roster слой |
| FACTION_PACKS_1_1_20260722 | Official Faction Packs | v1.1 / legal 22.07.2026 | faction rules updates |
| WAHAPEDIA_11E | Wahapedia 11e | live secondary | навигация, structured cross-check, gap detection |

Machine metadata: `data/live_rules_source_state_20260815.json`.

## Authority order

1. Текущий официальный rules document / Faction Pack / Universal Rules Update.
2. Текущий официальный MFM / официальный Warhammer 40,000 App.
3. Официальные Downloads/update articles для version/date/provenance.
4. Wahapedia 11e и иные структурированные secondary indexes — только для навигации и reconciliation.
5. Локальные historical snapshots — только evidence/diff.

## Runtime state

Полный MFM 1.2 reconciliation восьми пользовательских фракций завершён в `data/mfm_v1_2_user_factions_20260815.json`; старый `mfm_live_snapshot_20260710.json` больше не участвует в current costing.

Wahapedia не имеет права отменять официальный документ. При несовпадении система обязана пометить conflict и использовать официальный источник.
