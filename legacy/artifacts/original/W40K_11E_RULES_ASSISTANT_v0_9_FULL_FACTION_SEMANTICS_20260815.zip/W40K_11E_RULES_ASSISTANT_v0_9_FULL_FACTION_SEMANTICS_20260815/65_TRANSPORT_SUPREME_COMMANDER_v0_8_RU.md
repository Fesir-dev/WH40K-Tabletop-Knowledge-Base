# v0.8 — Transport & Supreme Commander Layer

## Dedicated Transport

`data/transport_profiles_v0_8_20260815.json` содержит exact current profiles для всех **6/6** units, которые текущий user-faction role dataset классифицирует как DEDICATED TRANSPORT:

- Anathema Psykana Rhino;
- Skorpius Dunerider;
- Chaos Rhino (Chaos Space Marines);
- Goliath Truck;
- Chaos Rhino (Thousand Sons);
- Chaos Rhino (World Eaters).

Движок проверяет:

- transport не пуст на Declare Battle Formations;
- passenger unit IDs существуют;
- вместимость;
- required faction/INFANTRY keywords;
- текущие explicit exclusions;
- для Pactbound Zealots — совпадение Chaos mark transport/passenger.

Это покрытие не заявляет все TRANSPORT datasheets или Legends: только текущую категорию DEDICATED TRANSPORT восьми runtime-фракций.

## Supreme Commander / Warlord

`data/supreme_commander_rules_v0_8_20260815.json` нормализует 7 подтверждённых current rules:

- Trajann Valoris;
- Belisarius Cawl;
- Be'lakor;
- Abaddon the Despoiler;
- Patriarch;
- Magnus the Red;
- Angron.

Если соответствующий обязательный Warlord присутствует, выбор другого Warlord является ошибкой. Для Patriarch дополнительно исполняется его special max-one restriction.
