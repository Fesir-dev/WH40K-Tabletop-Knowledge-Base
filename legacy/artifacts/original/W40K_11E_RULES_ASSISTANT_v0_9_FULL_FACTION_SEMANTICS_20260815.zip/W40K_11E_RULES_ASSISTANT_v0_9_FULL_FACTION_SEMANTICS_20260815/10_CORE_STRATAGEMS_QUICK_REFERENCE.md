# Core Stratagems Quick Reference (`15`)

## Global restrictions (`15.01`)

- Same player cannot use the same Stratagem more than once in the same phase.
- Unless stated otherwise, the same player cannot target the same unit with more than one Stratagem in the same phase.
- Select target, pay CP, then resolve effect.
- A battle-shocked unit cannot be targeted by its controller's Stratagems.

## Command Re-roll - 1CP (`15.02`)

**When:** just after a friendly unit/model makes an Advance, Charge, Damage, Hazard, Hit, Save, Wound or number-of-attacks roll.

**Effect:** reroll one die; a Charge roll is rerolled in full.

## Epic Challenge - 1CP (`15.03`)

**When:** Fight phase, just after friendly CHARACTER unit selected to fight.

**Effect:** one CHARACTER model's melee weapons gain `[PRECISION]` for the phase.

## Insane Bravery - 1CP (`15.04`)

**When:** before a Battle-shock roll in own Command phase.

**Effect:** automatic success.

**Limit:** once per battle.

## Explosives - 1CP (`15.05`)

**When:** own Shooting phase.

**Target:** unengaged EXPLOSIVES/GRENADES unit eligible to shoot and not Advanced.

**Effect:** choose one qualifying model and a visible unengaged enemy within 8"; roll 6D6, each 4+ causes 1 mortal wound.

## Crushing Impact - 1CP (`15.06`)

**When:** just after friendly MONSTER/VEHICLE ends a charge.

**Effect:** choose engaged enemy and engaged friendly model; roll dice equal to friendly model's T. Each 1 causes own unit 1 mortal; each 5+ causes enemy 1 mortal, maximum 6.

## Rapid Ingress - 1CP (`15.07`)

**When:** end of opponent Movement phase.

**Target:** non-AIRCRAFT unit in Strategic Reserves.

**Effect:** make an Ingress move.

**Restriction:** not battle round 1.

## Fire Overwatch - 1CP (`15.08`)

**When:** end of opponent Movement phase.

**Target:** friendly unengaged non-TITANIC unit.

**Effect:** Snap Shooting.

### Snap Shooting (`15.09`)

- one visible enemy unit within 24";
- only unmodified 6 hits;
- no hit rerolls.

## Smokescreen - 1CP (`15.10`)

**When:** start of opponent Shooting phase.

**Target:** friendly SMOKE unit.

**Effect:** Benefit of Cover for that unit and for units not fully visible due to intervening models from the SMOKE unit.

## Heroic Intervention - 1CP, optional +1CP (`15.11`)

**When:** end of opponent Charge phase.

**Target:** friendly unengaged unit within 12" of enemy. VEHICLE only if CHARACTER or WALKER.

Modes:

- **Leap to Defend:** charge only enemies that charged this phase.
- **Into the Fray (+1CP):** charge roll capped at 6; may target any enemy within 6" and within maximum distance.

## Counteroffensive - 2CP (`15.12`)

**When:** opponent Fight phase, just after an enemy unit resolves attacks.

**Target:** friendly unit eligible to fight.

**Effect:** gains Fights First for the phase and must be the next unit you select to fight.

## Tactical CP priorities

High-leverage uses commonly include:

- Counteroffensive to interrupt a multi-charge turn;
- Rapid Ingress to create a protected movement turn and charge threat;
- Command Re-roll on a high-impact charge, save, damage or attack-count die;
- Smokescreen where a BS penalty changes a large volume of attacks;
- Heroic Intervention to alter objective control or activation order.

Always compare CP value against mission points, not only damage.
