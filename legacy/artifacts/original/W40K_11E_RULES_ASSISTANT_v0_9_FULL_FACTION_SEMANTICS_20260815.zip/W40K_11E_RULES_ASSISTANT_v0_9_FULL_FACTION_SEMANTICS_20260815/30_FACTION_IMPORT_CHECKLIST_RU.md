# Чек-лист импорта фракции

1. Определить точное название фракции и доступные detachments.
2. Получить current faction pack/Codex/app entries.
3. Зафиксировать errata/FAQ.
4. Снять MFM snapshot: points, unit sizes, Leaders, DP, Force Dispositions.
5. Нормализовать datasheets без потери keywords/timing.
6. Построить Leader/Bodyguard/Support graph.
7. Индексировать stratagems и enhancements.
8. Создать русскую quick reference без подмены official wording.
9. Добавить damage presets и role tags.
10. Написать минимум 15 regression tests.
11. Проверить на конкретном ростере.
12. Зафиксировать дату и источники.

Без шага 4 нельзя давать окончательный ответ о стоимости или legality списка.
