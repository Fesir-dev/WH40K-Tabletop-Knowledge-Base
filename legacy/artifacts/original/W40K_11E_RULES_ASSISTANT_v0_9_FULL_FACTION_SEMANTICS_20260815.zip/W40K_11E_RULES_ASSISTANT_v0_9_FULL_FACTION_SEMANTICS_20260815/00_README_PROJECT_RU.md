> **v0.9 FULL FACTION SEMANTICS / MFM 1.2 / Faction Pack 1.1 (checkpoint 2026-08-15)**

# Warhammer 40,000 11-я редакция — Rules Assistant Project v0.9 FULL FACTION SEMANTICS

Текущий migration checkpoint: **2026-08-15**. Историческая базовая сборка: **2026-07-10**.

## Назначение

Это рабочая база для быстрых подсказок во время партии, судейского разбора спорных взаимодействий, анализа списков, миссий, позиций и вероятностей. Проект не заменяет официальные источники: он индексирует их, задаёт строгий порядок проверки и хранит краткие производные справочники.

## Что покрыто

- 88-страничные Core Rules: разделы `01–24`, печатный Rules Appendix и четыре FAQ из него.
- Chapter Approved Tournament Companion **v1.5**: последовательность подготовки, Fixed/Tactical, New Orders, Reserves, deployment/redeploy, окончание игры, лимиты VP, турнирные Actions, FAQ, пул из 20 миссий и совместимость с 8 terrain layouts.
- Force Dispositions: Take and Hold, Disruption, Purge the Foe, Priority Assets, Reconnaissance.
- Текущий локальный runtime: **MFM v1.2 / official update 22.07.2026 / reconciled 15.08.2026**. Исторический snapshot 2026-07-10 сохранён только для diff/evidence.
- Схема армейского слоя: datasheets, detachments, enhancements, stratagems, Leader links, support units, DP, Force Disposition и points snapshot.
- Машиночитаемые JSON/CSV/SQLite-индексы и утилиты поиска.
- Исполняемый v0.8 legality engine: всё ядро v0.7 + faction composition, exact Enhancement targets, Supreme Commander, transport capacity/passengers и separation `army availability != native faction keyword`.
- Source-conflict gate: неоднозначный live interaction возвращает `UNKNOWN`, а не догадку.

## Главные файлы

1. `01_MASTER_PROMPT_W40K11_RULES_ASSISTANT_RU.md` — главный промпт.
2. `16_CHAPTER_APPROVED_TOURNAMENT_SEQUENCE_RU.md` — подготовка и проведение турнирной партии.
3. `17_MISSION_ACTIONS_AND_SCORING_RU.md` — Actions, Fixed/Tactical, VP.
4. `18_TOURNAMENT_MISSION_POOL_RU.md` и `data/tournament_mission_pool.*` — 20 официальных комбинаций.
5. `19_MISSION_FAQ_QUICK_RULINGS_RU.md` — быстрые миссионные решения.
6. `22_CORE_RULES_APPENDIX_AND_APP_GAPS_RU.md` — что реально извлечено из Appendix и чего ещё нет из приложения.
7. `25_FACTION_LAYER_SCHEMA_RU.md` — стандарт импорта конкретной армии.
8. `26_GAME_ASSISTANT_COMMANDS_RU.md` — короткие команды для работы в чате.
9. `data/w40k11_rules.db` — SQLite-база для быстрого поиска.

## Статус полноты

- Core Rules: **структурно покрыты**.
- Печатный Rules Appendix: **покрыт**.
- Полный app-only Rules Appendix: **не получен**; позиции перечислены как пробелы, без выдумывания текста.
- Chapter Approved Tournament Companion v1.5: **ключевые игровые и судейские положения покрыты**.
- Полный текст платных карточек Chapter Approved: **не включён**. Для конкретного начисления VP необходима карточка/скриншот или её точный текст.
- Армейский слой: **8 пользовательских фракций reconciled** с MFM v1.2 и Faction Pack v1.1 на checkpoint 15.08.2026; полный Codex/App corpus остаётся live-source-first.

## Принцип безопасного ответа

Любой ответ должен разделять: `официальное правило` → `официальное FAQ/миссионная поправка` → `вывод` → `тактический совет`. При отсутствии точного текста datasheet, mission card или app-only FAQ ответ помечается как неполный, а не достраивается по памяти.


## v0.3 — пользовательские фракции

Добавлен каталог `factions/` для восьми армий пользователя:
Genestealer Cults, Chaos Space Marines, World Eaters, Chaos Daemons,
Thousand Sons, Imperial Knights, Adeptus Custodes и Adeptus Mechanicus.

Быстрый поиск по импортированным страницам:

```bash
python tools/query_factions.py "Fell Back"
python tools/query_factions.py "Resurgence points" --faction genestealer_cults
python tools/query_factions.py "Deep Strike" --faction chaos_daemons
```

Для финальной проверки legality/points требуется текущий официальный MFM + текущие official updates/Faction Pack; Wahapedia 11e используется как secondary cross-check.


## v0.4 — MFM, Leader graph и Balance Dataslate (HISTORICAL)

Snapshot от 2026-07-10:

- interactive MFM v1.0;
- MFM PDF v4.3;
- Balance Dataslate v3.3;
- 282 записей стоимости units;
- 79 detachments;
- 267 enhancement costs;
- 74 Leader/Support links;
- 43 оперативных Dataslate-checks.

Главная проверка:

```bash
python tools/validate_live_layers.py
```

Расчёт ростера:

```bash
python tools/cost_roster.py templates/roster_input_example_v0_4.json
```


## v0.6 CURRENT RUNTIME

- Current runtime for the eight user factions: `data/mfm_v1_2_user_factions_20260815.json`.
- Official MFM update: 22.07.2026; reconciliation checked 15.08.2026.
- Faction Pack v1.1 semantic deltas are stored per faction.
- `cost_roster.py`, `check_detachments.py`, and `leader_lookup.py` now route to the current runtime.
- Historical 10.07 snapshot remains immutable evidence and is not used for current costing.


## v0.8 FACTION LEGALITY

- `tools/validate_roster_v0_8.py` — основной current roster validator.
- 115/115 извлечённых Enhancement target clauses нормализованы в executable predicates.
- 6/6 текущих Dedicated Transport role entries имеют exact capacity/passenger profiles.
- 7 Supreme Commander/Warlord rules, 7 faction-composition rules и 11 availability overrides исполняются.
- `CURRENT_CERTIFIED` выдаётся только для конкретного ростера без errors и без unresolved gates.
- v0.8 regressions: 25/25 PASS; cumulative executable regressions v0.6–v0.8: 62/62 PASS.

См. `63_FACTION_LEGALITY_ENGINE_v0_8_RU.md` — `70_BUILD_VERIFICATION_v0_8_RU.md`.


## v0.9 FULL FACTION SEMANTICS

- `tools/validate_roster_v0_9.py` adds current keyword auto-evidence and generic transport validation.
- `data/keyword_membership_current_v0_9_20260815.json`: 62 keyword records / 435 positive membership assertions; 52 sets are complete for the local current-MFM corpus.
- `data/transport_profiles_v0_9_20260815.json`: 14 exact current transport profiles (6 Dedicated + 8 non-Dedicated).
- Exact executable faction target clauses override the generic CHARACTER fallback when the faction rule explicitly permits another target type.
- v0.9 regressions: 18/18 PASS; cumulative v0.6-v0.9 executable regressions: 80/80 PASS.

See documents `71`–`76` for the v0.9 semantic layer and build verification.
