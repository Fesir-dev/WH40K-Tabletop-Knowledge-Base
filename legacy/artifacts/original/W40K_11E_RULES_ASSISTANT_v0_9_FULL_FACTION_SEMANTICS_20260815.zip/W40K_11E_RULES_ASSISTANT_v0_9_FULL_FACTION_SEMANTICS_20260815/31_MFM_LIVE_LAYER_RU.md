# Munitorum Field Manual — текущий live-слой

**Current runtime:** MFM interactive **v1.2**.  
**Official update:** **22.07.2026**.  
**Reconciliation checkpoint:** **15.08.2026**.

MFM является текущим источником истины для:
- points values и оплачиваемых unit configurations;
- duplicate-copy cost bands;
- Leader/Support links;
- Detachment Points;
- Force Dispositions;
- enhancement costs.

## Runtime

- `data/mfm_v1_2_user_factions_20260815.json` — текущий консолидированный слой восьми пользовательских фракций.
- `data/mfm_v1_2_user_faction_diff_20260815.json` — машинный diff против исторического checkpoint.
- `data/mfm_status.json` — version/freshness metadata.
- `factions/<slug>/mfm_v1_2_points.json` — current points per faction.
- `factions/<slug>/mfm_v1_2_detachments.json` — current DP/disposition/enhancement layer.
- `factions/<slug>/leader_support_graph_v1_2.json` — current local Leader/Support graph.

Generic faction filenames `mfm_v1_points.json`, `mfm_v1_detachments.json` и `leader_support_graph.json` в v0.6 являются **current aliases**, чтобы старые команды не попадали в stale data.

## Historical evidence

`data/mfm_live_snapshot_20260710.json` и `factions/<slug>/mfm_v1_0_*_20260710.json` сохранены неизменными для diff/reproducibility и **не используются current costing engine**.

## Политика актуальности

Перед ответом, чувствительным к текущей стоимости/legality, и перед турнирной подачей требуется live-проверка официального GW MFM/App. Wahapedia 11e/другие structured mirrors разрешены только как secondary cross-check; при конфликте побеждает официальный источник.
