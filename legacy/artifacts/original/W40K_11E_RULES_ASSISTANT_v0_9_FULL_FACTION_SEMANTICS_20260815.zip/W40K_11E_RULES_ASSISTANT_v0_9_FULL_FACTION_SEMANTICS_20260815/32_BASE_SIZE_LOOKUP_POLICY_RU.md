# Base Size Guide — политика проверки

Tournament Companion v1.5 включает официальный Base Size Guide, last updated February 2026. Он предназначен для matched/tournament clarity и прямо отмечает, что не является обязательным для всех casual games.

## Правило ответа

- Для tournament legality использовать guide и event pack.
- Для Hull/Unique entries не подставлять вымышленный диаметр.
- При conversion спросить organiser, если model не помещается на стандартную base.
- Не переносить base size из старого издания или магазина без сверки guide.

В v0.6 полный справочник всё ещё не дублируется, чтобы избежать неполной/ошибочной таблицы. Источник указан в registry; при импорте конкретной фракции её relevant base sizes добавляются в faction layer.
