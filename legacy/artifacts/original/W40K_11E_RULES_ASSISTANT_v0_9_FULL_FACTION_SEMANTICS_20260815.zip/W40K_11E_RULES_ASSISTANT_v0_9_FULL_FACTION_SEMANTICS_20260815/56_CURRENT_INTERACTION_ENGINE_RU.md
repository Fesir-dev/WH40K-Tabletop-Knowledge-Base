# v0.7 — Current Interaction Engine

`tools/rules_engine_v0_7.py` — первый исполняемый слой для универсальных взаимодействий 11-й редакции.

Поддерживаются запросы:

- `can_make_normal_move` — второй Normal Move той же unit в одной phase;
- `gain_extra_cp` — лимит дополнительного CP за battle round;
- `can_use_stratagem` — повтор того же Stratagem и повторное target той же unit;
- `adjust_stratagem_cp_cost` — July Universal Rules Update для generic "0 CP";
- `revived_character_attachment` — применяет официальный July 22 override: возвращённый уничтоженный Character становится отдельной unit из одного.

Пример:

```json
{
  "query": "can_use_stratagem",
  "same_stratagem_uses_this_phase": 1,
  "target_stratagems_this_phase": 0,
  "explicit_named_repeat_permission": false
}
```

Запуск:

```bash
python tools/rules_engine_v0_7.py query.json
```

Это именно rules engine: результат строится по нормализованному rule state, а не по поиску похожей фразы в старом PDF.
