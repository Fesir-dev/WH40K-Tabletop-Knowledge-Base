# v0.7 — Stratagem Semantic Index

Добавлен `data/stratagem_semantic_index_v0_7_20260815.json` — безопасный нормализованный индекс 169 Stratagems из уже удерживаемых faction-pack слоёв восьми пользовательских фракций.

Индекс хранит не полный текст правила, а:

- faction;
- detachment;
- название;
- CP cost;
- phase tags;
- source pages;
- current-status относительно известных v1.1 deltas;
- признак применения Universal Rules Updates v1.0.

Если Stratagem затронут current v1.1 update, индекс помечает его `CURRENT_DELTA_TOUCHED_CONSULT_V1_1_EXACT_TEXT` и не выдаёт старый source block как актуальное решение.

Поиск:

```bash
python tools/query_stratagem_v0_7.py "Flawless Construction" adeptus_custodes
python tools/query_stratagem_v0_7.py "Movement" world_eaters
```

QA:

```bash
python tools/validate_stratagem_index_v0_7.py
```

Текущий объём: **169 Stratagem metadata entries**.
