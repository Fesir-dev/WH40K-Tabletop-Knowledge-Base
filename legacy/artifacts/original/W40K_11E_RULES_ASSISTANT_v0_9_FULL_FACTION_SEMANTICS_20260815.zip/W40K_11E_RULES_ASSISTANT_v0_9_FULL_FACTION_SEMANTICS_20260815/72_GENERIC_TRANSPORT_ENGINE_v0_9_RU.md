# v0.9 — Generic Transport Engine

`validate_roster_v0_9.py` расширяет Dedicated-only проверку v0.8 до любого транспорта, для которого есть exact current profile.

## Coverage

- 6 current Dedicated Transport profiles.
- 8 current non-Dedicated profiles.
- Итого: 14 exact profiles.

Добавлены Venerable Land Raider, Coronus Grav-carrier, Orion Assault Dropship, Archaeopter Transvector, Chaos Land Raider для CSM/TS/WE и Goliath Rockgrinder.

## Исполняется

- пассажирские keyword requirements;
- exclusions;
- capacity;
- space multipliers (`TERMINATOR`, `POSSESSED`, `MUTILATORS`);
- special passenger slots;
- Orion: один разрешённый Custodes Dreadnought и снижение обычной infantry capacity до 6;
- Dedicated Transport обязан иметь стартовую загрузку; обычный Transport может начинать пустым.
