# Матрица покрытия пользовательских фракций — v0.6 CURRENT

Для всех восьми пользовательских фракций MFM 1.2 и Faction Pack v1.1 reconciled в current runtime. `CURRENT` означает текущий локальный derived/cache слой на checkpoint 15.08.2026; официальный live source всё равно перепроверяется при чувствительном к актуальности запросе.

| Фракция | Local faction coverage | Faction Pack | MFM | Reconciliation |
|---|---|---|---|---|
| Адептус Кустодес | supplement | v1.1 / 22.07 | v1.2 / 22.07 | **CURRENT 15.08.2026** |
| Адептус Механикус | supplement | v1.1 / 22.07 | v1.2 / 22.07 | **CURRENT 15.08.2026** |
| Демоны Хаоса | full_index_plus_pack | v1.1 / 22.07 | v1.2 / 22.07 | **CURRENT 15.08.2026** |
| Космодесант Хаоса | supplement | v1.1 / 22.07 | v1.2 / 22.07 | **CURRENT 15.08.2026** |
| Культы генокрадов | supplement | v1.1 / 22.07 | v1.2 / 22.07 | **CURRENT 15.08.2026** |
| Имперские Рыцари | supplement | v1.1 / 22.07 | v1.2 / 22.07 | **CURRENT 15.08.2026** |
| Тысяча Сынов | supplement | v1.1 / 22.07 | v1.2 / 22.07 | **CURRENT 15.08.2026** |
| Пожиратели Миров | supplement | v1.1 / 22.07 | v1.2 / 22.07 | **CURRENT 15.08.2026** |

Universal Rules Updates v1.0 применяется поверх faction layers. Большинство Faction Packs являются supplement, поэтому полный Codex/App corpus локально по-прежнему не зеркалируется; exact datasheet wording берётся source-first из official App/PDF.
