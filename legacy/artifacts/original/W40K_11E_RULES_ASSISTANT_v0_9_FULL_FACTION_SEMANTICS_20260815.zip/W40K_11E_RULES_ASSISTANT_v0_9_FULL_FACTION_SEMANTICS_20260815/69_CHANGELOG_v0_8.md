# Changelog v0.8 — 2026-08-15

## Added

- faction-specific roster legality layer;
- 115 executable Enhancement target predicates;
- Enhancement selected-detachment validation;
- 6/6 current Dedicated Transport capacity/passenger profiles;
- 7 Supreme Commander / mandatory Warlord rules;
- 7 normalized faction-composition rules;
- 11 army-availability overrides separating MFM availability from native Faction Keyword;
- retained-datasheet positive keyword/ability evidence for 93 datasheets;
- alias-safe current Enhancement name reconciliation;
- external/allied unit input support with explicit provenance gate;
- targeted-unit ID ambiguity guard for `quantity > 1`;
- v0.8 query/validators and 25-case regression suite;
- a minimal `CURRENT_CERTIFIED` Custodes example roster.

## Safety changes

- an MFM faction bucket is no longer treated as proof of native Faction Keyword;
- missing unit keyword evidence yields UNKNOWN, not guessed FAIL/PASS, except for complete role sets and explicit availability overrides;
- MFM Enhancement price is no longer treated as proof of target wording;
- `CURRENT_CERTIFIED` is only emitted when the concrete input has zero errors and zero unresolved gates.
