# Конфликты версий и ловушки устаревших источников

## 1. Preview vs Tournament Companion v1.5

Предрелизная статья описывала постоянную выдачу двух новых Secondary и иные лимиты. Финальный Companion v1.5 задаёт: в первую Command phase две карты, затем добор до двух активных; максимум 50 Primary и 40 Secondary. Использовать финальный документ.

## 2. Турнирное objective правило vs Core Rules

В Tournament Companion модели могут завершать движения на плоских 40-мм objective markers. Это форматная поправка. Не переносить её автоматически на narrative/casual mission, где objective может быть physical artefact или terrain area.

## 3. Старые Core Rules Updates / Commentary

Официальный домен может продолжать индексировать 10th-edition PDFs. Дата размещения или доступность не доказывает применимость к 11-й. Проверять терминологию, номера разделов и прямое обозначение редакции.

## 4. Старый Balance Dataslate

Не применять старый dataslate к новой редакции без прямого указания Games Workshop. Новый MFM сам по себе не подтверждает перенос старых balance amendments.

## 5. Points в локальном файле

Points быстро меняются. Любая таблица без `source_version`, `updated_at` и `checked_at` считается непригодной для финальной проверки.

## 6. Mission names без card text

Название Primary/Secondary не даёт права реконструировать scoring. Требуется точная карточка текущего набора или официальная errata.
