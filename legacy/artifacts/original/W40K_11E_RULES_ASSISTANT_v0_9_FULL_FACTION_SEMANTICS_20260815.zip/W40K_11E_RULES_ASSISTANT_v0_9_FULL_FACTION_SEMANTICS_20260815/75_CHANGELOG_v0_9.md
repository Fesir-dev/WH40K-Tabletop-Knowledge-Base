# Changelog v0.9 — 2026-08-15

- Added provenance-aware current keyword membership dataset.
- Added automatic proven-negative semantics for keyword sets complete against local current MFM.
- Added 8 exact non-Dedicated Transport profiles; total exact transport profiles now 14.
- Added generic `transport_loads` validation while preserving mandatory starting load for Dedicated Transports.
- Added capacity multipliers and special passenger-slot semantics.
- Added Orion Assault Dropship Dreadnought-slot handling.
- Fixed Enhancement semantics: an executable specific faction target clause overrides generic CHARACTER fallback.
- Added `query_semantics_v0_9.py`.
- Added keyword/transport semantic validator.
- Added 18 v0.9 executable regressions; cumulative v0.6–v0.9 = 80/80 PASS.
