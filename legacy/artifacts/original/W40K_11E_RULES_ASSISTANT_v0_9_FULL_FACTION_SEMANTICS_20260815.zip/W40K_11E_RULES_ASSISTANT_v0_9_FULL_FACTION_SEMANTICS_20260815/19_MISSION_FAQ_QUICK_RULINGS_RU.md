# Быстрые решения из Chapter Approved Tournament Companion v1.5

## Attached Units

- **Cull the Horde:** starting strength Bodyguard оценивается так, как если бы он не входил в Attached Unit.
- **Action после гибели компонента:** оставшиеся component units могут завершить уже выполняемый Action.
- **Marked for Death:** уничтожить Bodyguard и как минимум одного из прикреплённых Leaders. Нельзя выбрать отдельного Leader, пока он внутри Attached Unit.

## Terraform

- Можно перезаписать objective, ранее terraformed соперником.
- После успешного выполнения objective считается terraformed новым игроком.
- Игрок не может выполнять Terraform на objective внутри собственной deployment zone; поэтому objective в зоне соперника нельзя «отвоевать обратно» самим владельцем зоны.

## Objectives и зоны

- При установке objective и определении границ Search and Destroy измерять от центра маркера.
- В Burden of Trust можно guard objective в собственной deployment zone.
- Timing guard различается для игрока первого и второго хода; проверять FAQ перед подсчётом.

## Sabotage

Только выполняющее подразделение обязано быть вне своей deployment zone; выбранная terrain feature не обязана целиком находиться вне неё.

## Возвращённые модели

Миссии на уничтожение Character могут начислить VP повторно, если возвращённая модель/юнит снова уничтожены, если карта прямо не запрещает это.

## Charges и Ruins

Mission pack не вводит исключение, позволяющее закончить charge внутри стены. Реальная геометрия solid sections может вынудить обход и увеличить требуемый charge roll.
