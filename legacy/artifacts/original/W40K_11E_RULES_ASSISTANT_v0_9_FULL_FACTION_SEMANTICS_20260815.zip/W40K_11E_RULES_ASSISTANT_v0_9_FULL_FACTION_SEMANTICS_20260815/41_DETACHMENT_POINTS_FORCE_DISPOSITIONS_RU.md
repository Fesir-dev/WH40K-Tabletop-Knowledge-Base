# Detachment Points и Force Dispositions — MFM 1.2 CURRENT

**Official MFM update:** 22.07.2026  
**Local reconciliation:** 15.08.2026

## Адептус Кустодес / Adeptus Custodes

| Detachment | DP | Force Disposition | Unique tags |
|---|---:|---|---|
| Auric Champions | 2 | Priority Assets | — |
| Lions of the Emperor | 2 | Disruption | LIONS |
| Might of the Moritoi | 1 | Take and Hold | ARMOURY |
| Null Maiden Vigil | 2 | Reconnaissance | — |
| Shield Host | 2 | Purge the Foe | — |
| Silent Hunters | 1 | Reconnaissance | — |
| Solar Spearhead | 2 | Take and Hold | ARMOURY |
| Talons of the Emperor | 3 | Take and Hold | — |
| Tharanatoi Hammerblow | 1 | Priority Assets | LIONS |

## Адептус Механикус / Adeptus Mechanicus

| Detachment | DP | Force Disposition | Unique tags |
|---|---:|---|---|
| Cohort Acquisitus | 1 | Reconnaissance | — |
| Cohort Cybernetica | 2 | Take and Hold | — |
| Data-Psalm Conclave | 2 | Disruption | DATA-PSALM |
| Eradication Cohort | 3 | Purge the Foe | — |
| Explorator Maniple | 2 | Priority Assets | — |
| Haloscreed Battle Clade | 3 | Priority Assets | — |
| Lords of the Forge | 1 | Priority Assets | — |
| Luminen Auto-choir | 1 | Disruption | DATA-PSALM |
| Rad-zone Corps | 2 | Take and Hold | — |
| Skitarii Hunter Cohort | 2 | Reconnaissance | — |

## Демоны Хаоса / Chaos Daemons

| Detachment | DP | Force Disposition | Unique tags |
|---|---:|---|---|
| Blood Legion | 2 | Purge the Foe | — |
| Cavalcade of Chaos | 1 | Disruption | — |
| Daemonic Incursion | 3 | Disruption | — |
| Legion of Excess | 2 | Priority Assets | — |
| Lords of the Warp | 1 | Take and Hold | — |
| Plague Legion | 2 | Take and Hold | — |
| Scintillating Legion | 2 | Priority Assets | — |
| Shadow Legion | 2 | Purge the Foe | — |
| Warptide | 1 | Reconnaissance | — |

## Космодесант Хаоса / Chaos Space Marines

| Detachment | DP | Force Disposition | Unique tags |
|---|---:|---|---|
| Cabal of Chaos | 1 | Disruption | — |
| Chaos Cult | 2 | Priority Assets | — |
| Creations of Bile | 3 | Purge the Foe | — |
| Cult of the Arkifane | 2 | Priority Assets | — |
| Deceptors | 2 | Disruption | — |
| Devotees of Destruction | 1 | Priority Assets | — |
| Dread Talons | 2 | Disruption | — |
| Fellhammer Siege-host | 2 | Take and Hold | — |
| Huron’s Marauders | 3 | Disruption | — |
| Murdertalon Raiders | 1 | Reconnaissance | NIGHTMARE |
| Nightmare Hunt | 2 | Disruption | NIGHTMARE |
| Pactbound Zealots | 3 | Priority Assets | — |
| Renegade Raiders | 3 | Reconnaissance | — |
| Renegade Warband | 2 | Priority Assets | — |
| Soulforged Warpack | 2 | Take and Hold | — |
| Veterans of the Long War | 2 | Take and Hold | — |
| Warpstrike Champions | 2 | Disruption | — |

## Культы генокрадов / Genestealer Cults

| Detachment | DP | Force Disposition | Unique tags |
|---|---:|---|---|
| Biosanctic Broodsurge | 2 | Take and Hold | PURESTRAIN |
| Brood Brothers Auxilia | 2 | Take and Hold | — |
| Final Day | 2 | Purge the Foe | — |
| Heroes of the Uprising | 1 | Disruption | — |
| Host of Ascension | 3 | Take and Hold | HOSTS |
| Outlander Claw | 2 | Reconnaissance | — |
| Purestrain Broodswarm | 1 | Priority Assets | PURESTRAIN |
| Xenocreed Congregation | 2 | Priority Assets | — |
| Xenocult Masses | 1 | Reconnaissance | HOSTS |

## Имперские Рыцари / Imperial Knights

| Detachment | DP | Force Disposition | Unique tags |
|---|---:|---|---|
| Dominus Foebreakers | 1 | Priority Assets | — |
| Freeblade Company | 3 | Priority Assets | — |
| Gate Warden Lance | 2 | Take and Hold | — |
| Questor Forgepact | 1 | Disruption | — |
| Questoris Companions | 3 | Take and Hold | — |
| Spearhead-at-Arms | 2 | Reconnaissance | ARMIGERS |
| Throne-bonded Outriders | 1 | Reconnaissance | ARMIGERS |
| Valourstrike Lance | 2 | Purge the Foe | — |

## Тысяча Сынов / Thousand Sons

| Detachment | DP | Force Disposition | Unique tags |
|---|---:|---|---|
| Changehost of Deceit | 2 | Reconnaissance | — |
| Grand Coven | 3 | Priority Assets | — |
| Hexwarp Thrallband | 3 | Take and Hold | — |
| Ritual of Regeneration | 1 | Take and Hold | — |
| Rubricae Phalanx | 3 | Take and Hold | — |
| Sekhetar Cohort | 1 | Disruption | — |
| Servants of Change | 1 | Reconnaissance | MUTANT |
| Warpforged Cabal | 2 | Disruption | — |
| Warpmeld Pact | 2 | Purge the Foe | MUTANT |

## Пожиратели Миров / World Eaters

| Detachment | DP | Force Disposition | Unique tags |
|---|---:|---|---|
| Berzerker Warband | 3 | Purge the Foe | — |
| Brazen Engines | 1 | Disruption | ONSLAUGHT |
| Butchers of Khorne | 1 | Take and Hold | — |
| Cult of Blood | 2 | Priority Assets | — |
| Goretrack Onslaught | 2 | Take and Hold | ONSLAUGHT |
| Khorne Daemonkin | 2 | Reconnaissance | — |
| Possessed Slaughterband | 2 | Purge the Foe | — |
| Vessels of Wrath | 1 | Priority Assets | — |

> Значения берутся из `data/mfm_v1_2_user_factions_20260815.json`. Перед турнирной подачей перепроверить официальный live MFM/App.
