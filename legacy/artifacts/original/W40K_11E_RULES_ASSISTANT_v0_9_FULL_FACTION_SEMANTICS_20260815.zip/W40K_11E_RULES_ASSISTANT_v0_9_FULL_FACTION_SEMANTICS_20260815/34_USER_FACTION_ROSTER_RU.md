# Армии пользователя — импортированный набор

| Фракция | Pack | Detachments | Stratagems | Datasheets imported | Coverage |
|---|---:|---:|---:|---:|---|
| Культы генокрадов / Genestealer Cults | 1.0 | 4 | 15 | 0 | supplement |
| Космодесант Хаоса / Chaos Space Marines | 1.0 | 9 | 45 | 10 | supplement |
| Пожиратели Миров / World Eaters | 1.0 | 3 | 9 | 1 | supplement |
| Демоны Хаоса / Chaos Daemons | 1.0 | 7 | 28 | 54 | full_index_plus_pack |
| Тысяча Сынов / Thousand Sons | 1.0 | 4 | 15 | 1 | supplement |
| Имперские Рыцари / Imperial Knights | 1.0 | 4 | 15 | 10 | supplement |
| Адептус Кустодес / Adeptus Custodes | 1.0 | 5 | 21 | 13 | supplement |
| Адептус Механикус / Adeptus Mechanicus | 1.0 | 5 | 21 | 4 | supplement |

Файлы Adeptus Custodes были загружены дважды. SHA-256 совпадает; в проект включена одна копия.

Приоритет дальнейшей работы: загрузить/импортировать Codex/app-слой для supplement-фракций, затем полный MFM 4.3 и Balance Dataslate 3.3.
