# LIVE Rules Migration — checkpoint 2026-08-15

## Цель

Перевести Rules Assistant с модели `snapshot 2026-07-10 = live` на `external current sources = truth; local snapshots = versioned cache/evidence`.

## Текущее состояние

- Core Rules: 11th edition, June 2026.
- Universal Rules Updates: v1.0, legal from 22.07.2026.
- Munitorum Field Manual: v1.2, official update 22.07.2026.
- 8 user factions: MFM 1.2 reconciliation **закрыт**.
- 8 user factions: Faction Pack v1.1 semantic migration **закрыта**.
- Current tools route to `data/mfm_v1_2_user_factions_20260815.json`.
- Historical 20260710 files остаются immutable evidence.

## Реализовано

1. Official-live-first source hierarchy.
2. Wahapedia 11e как secondary structured cross-check.
3. Universal Rules Updates v1.0 normalized override layer.
4. Current MFM points/sizes/copy bands/enhancements/DP/dispositions.
5. Current per-faction v1.1 semantic rules-update summaries.
6. Current Leader/Support namespace with live-source priority.
7. Freshness/current-MFM/faction-pack validators.
8. Executable current regression suite.
9. Current-only query tool.

## Остающиеся границы

- Полный официальный App/Codex datasheet corpus не зеркалируется локально.
- Exact wording для спорного правила всегда source-first из официального current PDF/App.
- Любой update после 15.08.2026 автоматически делает затронутый derived слой кандидатом на `STALE` до reconciliation.
