# v0.8 — Army Availability vs Native Faction Keyword

В 11e текущий MFM bucket конкретной Army Faction может включать units, которые разрешены этой армии специальным правилом, но **не получают её native Faction Keyword**.

Поэтому v0.8 разделяет два понятия:

1. `available_to_army` — unit может быть выбран/имеет current MFM costing в этой army context;
2. `native_faction_keyword` — unit действительно имеет Faction Keyword выбранной армии и может удовлетворять правилам, которые требуют именно этот keyword.

`data/army_availability_overrides_v0_8_20260815.json` сейчас содержит **11 overrides**:

### Thousand Sons / SCINTILLATING LEGIONS

- Kairos Fateweaver;
- Lord of Change;
- Blue Horrors;
- Pink Horrors;
- Screamers;
- Flamers.

### World Eaters / BLOOD LEGIONS

- Skarbrand;
- Bloodthirster;
- Bloodletters;
- Flesh Hounds;
- Bloodcrushers.

Следствие: такие units могут быть доступны армии и корректно стоить points, но не становятся THOUSAND SONS/WORLD EATERS Warlord candidates автоматически.
