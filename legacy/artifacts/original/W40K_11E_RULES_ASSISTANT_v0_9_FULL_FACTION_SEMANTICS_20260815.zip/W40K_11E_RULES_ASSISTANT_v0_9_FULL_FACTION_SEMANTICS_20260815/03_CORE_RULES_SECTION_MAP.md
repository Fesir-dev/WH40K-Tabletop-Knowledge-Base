# Core Rules Section Map

The 11th-edition Core Rules use numbered internal references. Use these numbers in every ruling.

## Basic Rules

| Ref | Section | PDF pages | Main questions |
|---|---|---:|---|
| 01 | Core Concepts | 8-9 | units, models, active player, dice, Leadership, Battle-shock |
| 02 | Datasheets | 10-11 | profiles, weapons, keywords, composition, wargear |
| 03 | Moving | 12-15 | movement geometry, setup, coherency, engagement |
| 04 | Making Attacks | 16-17 | weapons, targets, attack pools, split melee attacks |
| 05 | Attack Sequence | 18-23 | hit, wound, save groups, allocation, damage |
| 06 | Other Concepts | 24-25 | visibility, mortal wounds, hazard rolls |

## Battle Round

| Ref | Section | PDF pages | Main questions |
|---|---|---:|---|
| 07 | Battle Round | 28-29 | round order, turn order, mission timing |
| 08 | Command Phase | 30-31 | CP, Battle-shock, command abilities |
| 09 | Movement Phase | 32-33 | remain, normal, advance, fall back |
| 10 | Shooting Phase | 34-35 | shooting eligibility and shooting types |
| 11 | Charge Phase | 36-37 | declaring and completing charges |
| 12 | Fight Phase | 38-43 | pile-in, fight alternation, overrun, consolidation |

## Battlefields and Tactics

| Ref | Section | PDF pages | Main questions |
|---|---|---:|---|
| 13 | Terrain | 46-51 | categories, movement, cover, hidden, obscuring, solid |
| 14 | Objectives | 52-53 | control, terrain objectives, secured objectives |
| 15 | Stratagems | 54-57 | usage limits, costs, Core Stratagems |
| 16 | Actions | 58 | eligibility, interruption, completion |

## Advanced Rules

| Ref | Section | PDF pages | Main questions |
|---|---|---:|---|
| 17 | Monsters and Vehicles | 62-63 | movement through models, frame, engaged shooting |
| 18 | Transports | 64-65 | embark, disembark modes, emergency disembark |
| 19 | Attached Units | 66-67 | Leaders, Supports, Toughness, keywords, abilities |
| 20 | Strategic Reserves | 68-69 | reserve cap, ingress, repositioning |
| 21 | Flying and Surging | 70-71 | surge moves, take to the skies |
| 22 | Other Rules and Abilities | 72-73 | aura, faction, psychic, wargear, plunging fire |
| 23 | Aircraft | 74 | deployment, recurring reserves, shooting and melee |

## Reference

| Ref | Section | PDF pages | Main questions |
|---|---|---:|---|
| 24 | Core Abilities | 78-85 | universal unit and weapon abilities |
| App. | Rules Appendix | 86-88 | strength state, destruction, mixed keywords, revival, FAQs |

## High-frequency lookup paths

- “Can this unit do X after moving?” -> `09`, then `10`, `11` or `16`.
- “Can I shoot this target?” -> `04.02`, `06.01`, `10`, `13.07`, `17.03`.
- “Who fights first?” -> `12.04`, then `24.13`, then `15.12`.
- “Where does damage go?” -> `05.03-05.04`, then `19.02`, `24.28`.
- “Does this keyword affect the whole attached unit?” -> `19.03`, Appendix Mixed Keywords.
- “Can a reserve arrive here?” -> `20.03-20.04`, then `24.09`.
- “Does cover apply?” -> `13.08`, then `[IGNORES COVER]`, Stealth, Smokescreen.
