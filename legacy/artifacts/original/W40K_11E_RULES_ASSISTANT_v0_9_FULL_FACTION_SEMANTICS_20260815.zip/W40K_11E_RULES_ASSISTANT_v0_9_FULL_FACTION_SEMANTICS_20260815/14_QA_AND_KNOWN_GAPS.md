> Current live migration state: see `45_LIVE_RULES_MIGRATION_20260815_RU.md`. Historical statements below must be read in that context.

# QA and Known Gaps — v0.9 FULL FACTION SEMANTICS

## Validated

- Core Rules PDF: 88 pages; sections 01–24 and printed Rules Appendix indexed.
- Core Abilities and Core Stratagems retained from v0.1.
- Chapter Approved Tournament Companion v1.5 sequence, scoring caps, Actions, Reserves, FAQ and mission pool A–T indexed.
- Mission pool contains exactly 20 entries.
- SQLite/JSON validation and minimum regression-test counts pass.
- Preview-vs-final and 10th-edition stale-source traps are explicitly recorded.

## Known gaps

1. **Full app-only Rules Appendix.** Only the printed selection and four printed FAQs are captured. Green app references without exported text remain `missing_app_export`.
2. **Exact Chapter Approved card text.** The project stores the official tournament combinations and general amendments, but not the complete paid mission deck. Exact scoring requires the current card or an authorised source.
3. **Full Codex/App corpus.** Eight user factions are imported/reconciled for local faction-pack + MFM layers, but supplement packs do not mirror every Codex/App datasheet and exact living wording.
4. **Live updates.** MFM, app FAQs and event packs can change; every final roster or tournament answer needs a current check.
5. **Exact terrain coordinates.** Layout IDs and component sizes are indexed; exact positions remain in the official diagrams.
6. **Complete base-size table.** The official guide is referenced; the project still does not mirror a complete current base-size table for every faction/model.

## Stop conditions

Return `источников недостаточно` rather than guessing when the answer depends on a missing card, app entry, faction wording, current MFM value, event ruling or exact terrain diagram.


## v0.6 update
- MFM 1.2 user-faction current runtime: implemented.
- July Faction Pack v1.1 semantic delta: implemented for all 8 user factions.
- Remaining gap: full official-app datasheet text is not mirrored locally; exact wording remains live-source-first.

## v0.7 executable-engine status — 2026-08-15

Added executable core roster legality and universal interaction checks. Current certified scope includes battle-size caps, DP, generic unit-copy limits, Battleline/Dedicated Transport multipliers, Epic Hero uniqueness, Warlord/native-faction classification, Leader/Support graph, start-loaded Dedicated Transports, and source-confirmed Upgrade-vs-standard Enhancement semantics.

Still intentionally incomplete: full faction-specific detachment composition clauses, every Enhancement target clause, transport capacity/passenger eligibility, must/cannot-be-Warlord exceptions per datasheet, and unresolved interactions listed in `data/source_conflict_registry_v0_7_20260815.json`. A core PASS must not be presented as full tournament certification when these checks are unresolved.


## v0.8 executable faction-layer status — 2026-08-15

Now executable: 115 exact Enhancement target clauses; 6/6 current Dedicated Transport role profiles; 7 mandatory-Warlord/Supreme rules; 7 normalized faction-composition rules; 11 explicit availability-vs-native-faction overrides. Retained positive keyword/ability evidence covers 93 local datasheets.

Remaining deliberate gates:

1. Only **115 of 267** current MFM Enhancement-cost entries have exact locally retained target wording normalized in this checkpoint. Price existence is not used to invent target legality.
2. `6/6 transport coverage` means the current DEDICATED TRANSPORT role dataset for these eight factions, not every TRANSPORT/Legends datasheet.
3. The 7 composition rules are a high-value executable subset, not all restrictions across 79 current MFM detachments.
4. Datasheet keyword evidence is positive/incomplete unless the roster input explicitly marks `keywords_complete:true`; absence from retained evidence is not treated as proof of absence.
5. Exact current Codex/App-only wording not mirrored locally remains live-source-first and can force `PASS_WITH_UNVERIFIED_DETAILS`.


## v0.9 semantic-layer status — 2026-08-15

Added a provenance-aware current keyword membership layer and generic exact transport profiles. For keyword sets marked `complete_for_local_mfm:true`, absence is now valid negative evidence; incomplete sets remain positive-only and never prove absence. Current coverage is 62 keyword records / 435 positive membership assertions, of which 52 keyword sets are complete for the local MFM corpus. Transport coverage is 14 exact current profiles (6 Dedicated + 8 non-Dedicated).

Remaining deliberate gates: the full Codex/App datasheet and ability corpus is not mirrored, only 115/267 current MFM Enhancement cost entries have exact target predicates, and many detachment-specific composition/ability interactions still require exact current live text.
