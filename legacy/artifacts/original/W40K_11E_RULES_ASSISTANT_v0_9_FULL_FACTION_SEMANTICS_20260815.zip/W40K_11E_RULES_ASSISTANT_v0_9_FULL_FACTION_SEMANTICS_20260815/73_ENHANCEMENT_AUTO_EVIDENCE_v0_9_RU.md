# v0.9 — Enhancement Auto-Evidence and Specific-Rule Precedence

v0.9 не увеличивает искусственно число target predicates: authoritative exact target wording по-прежнему нормализован для 115 Enhancement/Upgrade entries.

Изменение состоит в качестве доказательства target legality:

1. `validate_roster_v0_9.py` автоматически подтягивает текущие keywords unit из live membership layer.
2. Для complete keyword sets движок умеет доказать и отрицание keyword.
3. Exact executable faction target clause является более специфичным правилом, чем generic CHARACTER fallback.
4. Поэтому правило вида `ADEPTUS CUSTODES VEHICLE model only` действительно может разрешить доказанный VEHICLE target без ложной ошибки `not CHARACTER`.
5. Если exact target predicate отсутствует, generic CHARACTER fallback сохраняется.

Regression cases включают TS PSYKER+INFANTRY, WE TERMINATOR SQUAD, AdMech TECH-PRIEST и Custodes WALKER/VEHICLE targets.
