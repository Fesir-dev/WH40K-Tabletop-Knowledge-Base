# Шаблон состояния миссии

```yaml
ruleset:
  edition: 11
  mode: tournament
  companion_version: "1.5"
  event_pack: null
  mfm_version: "1.0"
  mfm_checked: "2026-07-10"
mission:
  code: null
  primary: null
  deployment: null
  layout: null
  round: 1
  turn_player: null
  phase: Command
score:
  me: {primary: 0, secondary: 0, battle_ready: 10}
  opponent: {primary: 0, secondary: 0, battle_ready: 10}
resources:
  me_cp: 0
  opponent_cp: 0
secondaries:
  me:
    mode: tactical
    active: []
    deck_remaining: null
  opponent:
    mode: tactical
    active: []
actions: []
units: []
terrain_notes: null
question: null
```

Для спорной геометрии дополнить фотографией сверху и хотя бы одной известной длиной для масштаба.
