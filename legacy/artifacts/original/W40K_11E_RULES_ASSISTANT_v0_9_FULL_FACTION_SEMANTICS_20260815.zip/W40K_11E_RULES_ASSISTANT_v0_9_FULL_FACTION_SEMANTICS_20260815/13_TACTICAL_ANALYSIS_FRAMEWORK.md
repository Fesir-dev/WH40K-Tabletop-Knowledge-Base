# Tactical Analysis Framework

## 1. Win condition first

Before calculating damage, determine:

- current score;
- remaining scoring opportunities;
- which objectives are controlled at the end of this phase and turn;
- active actions and completion windows;
- whether killing a unit changes scoring more than moving it.

## 2. Board-state valuation

For every unit estimate:

- immediate scoring value;
- future scoring value;
- damage output;
- durability;
- movement and charge threat;
- screening and denial value;
- CP or detachment synergy;
- opponent resources required to remove it.

A cheap unit controlling or securing a terrain objective may be more valuable than a damaged elite unit.

## 3. Threat range

Do not use a single number. Separate:

- guaranteed movement range;
- average Advance or Charge range;
- reliable range after reroll;
- maximum range;
- terrain-constrained path;
- legal final-position requirements.

For charges, account for the need to engage every declared target and avoid undeclared enemies.

## 4. Expected damage

Base expected unsaved attacks:

`attacks x P(hit) x P(wound) x P(failed save)`

Then adjust for:

- Blast/Cleave thresholds;
- Rapid Fire and Melta range at target selection;
- Lethal Hits and Sustained Hits;
- Anti and Devastating Wounds;
- rerolls;
- damage reduction and Feel No Pain;
- finite target models and wounds;
- allocation groups;
- one-model cap per Devastating Wounds critical.

Use distributions rather than only averages when the decision depends on killing a key model or completing an action.

## 5. Activation order

In Fight phase analyse:

- all current and potential Fights First units;
- Counteroffensive availability and CP;
- whether destroying a transport creates an Overrun target;
- whether consolidation exposes a new enemy fight;
- which unit must fight before losing buffs or models.

## 6. CP efficiency

Estimate CP by mission impact:

- points gained or denied;
- probability of critical unit survival;
- probability of completing a charge/action;
- future opportunity cost.

A reroll producing extra damage is weaker than a reroll that flips an objective or prevents a decisive counterattack.

## 7. Opponent response

For every plan, state the opponent's strongest plausible response:

- movement denial;
- reserve arrival;
- Overwatch;
- Smokescreen;
- Heroic Intervention;
- Counteroffensive;
- target selection against an Attached Unit;
- objective flip at end of phase.

## 8. Recommended output

```text
Best line: [plan]
Why: [scoring + probability + board position]
Expected result: [range]
Main failure mode: [risk]
Opponent's best response: [counter]
Fallback: [alternative]
```
