> **v0.8 LIVE / MFM 1.2 / Faction Pack 1.1 (2026-08-15 checkpoint)

# Warhammer 40,000 11th Edition - Rules Assistant Project

Version: 0.1 (Core Rules foundation)
Date: 2026-07-10
Primary rules snapshot: Core Rules PDF, updated 2026-06-01
Primary source SHA-256: `f6a2443a44627ac5f0ef08407d29aa5ec7e97339998f05bc35f3ae37bf276833`

## Purpose

This project is a compact, searchable rules-and-tactics knowledge base for:

- fast rules lookups during games;
- resolving ambiguous interactions;
- checking legal movement, shooting, charges, fights, allocation and scoring;
- estimating expected damage and tactical risk;
- analysing army lists, deployments and turns;
- separating official rules from tactical recommendations;
- updating volatile data without rewriting the stable rules core.

## Current scope

Included in v0.1:

- the complete structure of the 11th-edition Core Rules;
- phase-by-phase checklists;
- attack, allocation and damage workflow;
- movement, charge, pile-in, fight and consolidation logic;
- terrain, objectives, stratagems and actions;
- transports, attached units, strategic reserves, flying and aircraft;
- all 38 Core Abilities in compact form;
- a master prompt for a rules assistant;
- templates for submitting game states and rules questions;
- QA rules and a list of missing sources.

Not yet included:

- the complete expanded digital rules appendix from the Warhammer 40,000 app;
- current mission deck and all mission-specific actions/scoring;
- faction packs, Codexes, detachments, enhancements and faction stratagems;
- current points snapshot for every faction;
- tournament companion, terrain layouts and event rulings;
- later errata, FAQs and balance updates.

## Recommended source hierarchy

1. Latest official errata / FAQ / app clarification.
2. Current mission pack and mission-specific rules.
3. Current faction pack or Codex rules.
4. Current Core Rules.
5. Designer's Notes.
6. Tactical inference and community convention.

A later, more specific rule normally overrides a general rule only where they directly conflict. Never silently treat tactical convention as official rules text.

## File map

- `01_MASTER_PROMPT_W40K11_RULES_ASSISTANT.md` - main project instruction.
- `02_SOURCE_HIERARCHY_AND_UPDATE_POLICY.md` - precedence, freshness and version control.
- `03_CORE_RULES_SECTION_MAP.md` - numbered section map and page guide.
- `04_TURN_AND_PHASE_CHECKLIST.md` - play aid for each turn.
- `05_ATTACK_SEQUENCE_AND_ALLOCATION.md` - attacks, saves, damage and mortal wounds.
- `06_MOVEMENT_CHARGE_AND_FIGHT.md` - positioning and melee movement.
- `07_TERRAIN_OBJECTIVES_AND_ACTIONS.md` - terrain categories, visibility, scoring and actions.
- `08_ADVANCED_UNITS_AND_RESERVES.md` - vehicles, transports, attached units, reserves, fly and aircraft.
- `09_CORE_ABILITIES_GLOSSARY.md` - all Core Abilities.
- `10_CORE_STRATAGEMS_QUICK_REFERENCE.md` - all Core Stratagems.
- `11_GAME_STATE_INPUT_TEMPLATE.md` - structured question template.
- `12_RULES_QUERY_DECISION_TREE.md` - interaction-resolution workflow.
- `13_TACTICAL_ANALYSIS_FRAMEWORK.md` - expected value, tempo, threat and scoring analysis.
- `14_QA_AND_KNOWN_GAPS.md` - anti-hallucination and completeness checks.
- `15_CHANGELOG.md` - package history.
- `rules_index.json` - machine-readable section and ability index.
- `core_abilities.csv` - compact ability table.

## Working convention

Keep official English terms in parentheses after the Russian explanation. Example: «дистанция вовлечения (Engagement Range)». Keywords and weapon abilities remain in their official English form, e.g. `[LETHAL HITS]`, `INFANTRY`, `MONSTER`.


## v0.8 CURRENT RUNTIME

The eight user factions now use `data/mfm_v1_2_user_factions_20260815.json` for current points, duplicate-copy bands, Detachment Points, Force Dispositions and enhancement costs. Historical July-10 data remains preserved for diff/audit.


## v0.8 Faction Legality checkpoint — 2026-08-15

The current validator is `tools/validate_roster_v0_8.py`. It adds exact normalized faction-specific legality where evidence is available: 115 Enhancement target predicates, all 6 current Dedicated Transport role profiles, 7 Supreme Commander rules, 7 faction-composition rules, and 11 army-availability overrides. Unknown current wording remains gated instead of inferred. `CURRENT_CERTIFIED` is emitted only for a concrete roster with zero errors and zero unresolved details.


## v0.9 FULL FACTION SEMANTICS

- `tools/validate_roster_v0_9.py` adds current keyword auto-evidence and generic transport validation.
- `data/keyword_membership_current_v0_9_20260815.json`: 62 keyword records / 435 positive membership assertions; 52 sets are complete for the local current-MFM corpus.
- `data/transport_profiles_v0_9_20260815.json`: 14 exact current transport profiles (6 Dedicated + 8 non-Dedicated).
- Exact executable faction target clauses override the generic CHARACTER fallback when the faction rule explicitly permits another target type.
- v0.9 regressions: 18/18 PASS; cumulative v0.6-v0.9 executable regressions: 80/80 PASS.

See documents `71`–`76` for the v0.9 semantic layer and build verification.
