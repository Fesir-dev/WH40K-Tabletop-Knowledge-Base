# Build Verification — v0.6 CURRENT

Дата: **2026-08-15**.

Все обязательные локальные проверки проходят:

- `validate_project.py`: PASS — PASS: JSON, SQLite and minimum counts validated.
- `validate_factions.py`: PASS — PASS: 8 factions; 41 detachments; 169 stratagems; 93 datasheets; 276 searchable matched-play pages.
- `validate_live_layers.py`: PASS — PASS: 8 factions; 282 point entries; 79 detachments; 267 enhancements; 74 Leader/Support links; 43 dataslate checklist entries.
- `validate_source_freshness.py`: PASS — PASS: source hierarchy checkpoint is internally consistent.
- `validate_current_mfm.py`: PASS — PASS: current MFM 1.2 runtime; 8 factions; 69 unit cost-band changes; 19 detachment/enhancement changes; sentinel costs/dispositions verified.
- `validate_rules_updates_v1_1.py`: PASS — PASS: 8 current Faction Pack v1.1 semantic layers; 34 summarized change groups; official-PDF provenance hashes present.
- `run_current_regressions.py`: PASS — PASS: 18/18 current-runtime regression cases.

Machine report: `data/qa_v0_6_results.json`.
