# Wahapedia 11e — политика интеграции

## Роль

Wahapedia используется как **secondary structured live index**, а не как источник с более высоким приоритетом, чем Games Workshop.

## Разрешённые применения

- искать актуальную страницу фракции/datasheet/rule;
- определять version metadata и структуру книг;
- извлекать кандидатов на изменения для последующей официальной сверки;
- строить coverage matrix;
- заполнять navigation aliases;
- обнаруживать новые FAQ/keywords/units/detachments;
- помогать при невозможности удобно прочитать официальный interactive MFM.

## Запрещённые применения

- автоматически объявлять Wahapedia выше official PDF/app;
- перезаписывать локальную историю без provenance;
- считать отсутствие записи на Wahapedia доказательством отсутствия правила;
- смешивать 10e и 11e URL namespace.

## Namespace lock

Только `https://wahapedia.ru/wh40k11ed/` разрешён для текущих 11e rulings. `wh40k10ed` — архив и может использоваться только для исторического сравнения.

## Conflict object

При расхождении хранить:

- `topic`;
- `official_value`;
- `secondary_value`;
- `official_source_id`;
- `secondary_url`;
- `checked_at`;
- `resolution = official_wins`;
- `notes`.
