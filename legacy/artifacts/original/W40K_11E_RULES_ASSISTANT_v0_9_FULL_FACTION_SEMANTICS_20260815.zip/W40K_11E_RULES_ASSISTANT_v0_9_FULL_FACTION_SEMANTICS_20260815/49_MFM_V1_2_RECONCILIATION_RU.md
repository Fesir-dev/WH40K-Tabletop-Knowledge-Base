# MFM 1.2 — reconciliation checkpoint 2026-08-15

## Статус

Для восьми пользовательских фракций локальный runtime переведён с исторического MFM 1.0 (source update 17.06.2026) на текущий MFM 1.2, официальный update 22.07.2026.

Текущий runtime: `data/mfm_v1_2_user_factions_20260815.json`.

Исторический snapshot: `data/mfm_live_snapshot_20260710.json` — не изменён и не используется для current costing.

## Нормализовано

- points и unit sizes;
- duplicate-copy cost bands / новые unit taxes;
- Detachment Points;
- Force Dispositions;
- enhancement costs;
- current Leader/Support graph metadata;
- faction-pack v1.1 semantic deltas;
- post-July app follow-up для CSM Cypher.

Полный машинный diff: `data/mfm_v1_2_user_faction_diff_20260815.json`.

## Authority

1. Current official Games Workshop documents/app/MFM.
2. Official download/update pages.
3. Wahapedia 11e / 40k.app only as structured secondary cross-check.
4. Historical local snapshots only as evidence.
