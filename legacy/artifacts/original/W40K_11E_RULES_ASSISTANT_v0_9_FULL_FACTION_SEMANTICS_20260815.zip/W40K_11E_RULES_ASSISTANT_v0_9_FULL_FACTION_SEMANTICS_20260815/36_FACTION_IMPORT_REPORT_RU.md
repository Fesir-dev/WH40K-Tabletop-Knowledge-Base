# Отчёт импорта Faction Packs — v0.3

Дата: 2026-07-10

## Результат

- Уникальных фракций: 8
- Faction Packs: 8
- Detachments: 41
- Stratagems indexed: 169
- Matched-play / Imperial Armour datasheets indexed: 93
- Searchable matched-play PDF pages: 276
- Duplicate Custodes PDF: подтверждён и исключён из повторного импорта

## Что создано

Для каждой фракции:
- `source_manifest.json`
- `pack_index.json`
- `detachments.json`
- `datasheets.json`
- `rules_updates_en.md`
- `quick_reference_ru.md`
- `coverage_gaps_ru.md`
- `regression_tests.json`
- `legends_index.json`

Общие файлы:
- `data/user_faction_catalog.json`
- `data/user_faction_catalog.csv`
- `data/faction_page_search.jsonl`
- `data/live_balance_sources_20260710.json`
- `tools/query_factions.py`
- `tools/validate_factions.py`

## Важное ограничение

Большинство загруженных документов — Faction Packs, прямо дополняющие Codex. Они не являются полным набором правил армии. Исключение по объёму покрытия — Chaos Daemons, где в pack присутствует полноценный Index-слой.
