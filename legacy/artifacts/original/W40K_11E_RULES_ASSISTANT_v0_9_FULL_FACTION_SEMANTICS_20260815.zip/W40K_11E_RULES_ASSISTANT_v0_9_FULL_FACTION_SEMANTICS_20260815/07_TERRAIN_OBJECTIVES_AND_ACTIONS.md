# Terrain, Objectives and Actions

## Terrain areas (`13.01`)

A terrain area is defined by a mat/base, a single feature footprint, or an agreed boundary formed by multiple features. Rules often care about the area boundary rather than the physical wall alone.

## Categories

### Exposed

- examples: craters, wire, debris;
- all models can move horizontally and vertically through it.

### Light

- examples: barricades, low walls, statuary;
- all models can move through it;
- contributes to Obscuring terrain areas.

### Dense

- examples: buildings, ruins, containers, woods;
- provides the strongest movement and visibility effects;
- has Solid;
- contributes to Obscuring;
- INFANTRY/BEASTS/SWARM/MOBILE can move horizontally through it;
- INFANTRY/BEASTS/SWARM can move vertically through it;
- other models can move through sections 2" or lower, otherwise must climb and cannot end above ground unless allowed.

## Ending on upper surfaces

A model may end above ground only if:

- it is INFANTRY, BEASTS, SWARM, FLY or MONSTER;
- it is stable;
- no part of its base overhangs the outer edge.

## Benefit of Cover (`13.08`)

The whole target unit gains the benefit only if every model meets at least one qualifying condition:

- INFANTRY/BEASTS/SWARM within a terrain area; or
- not fully visible to the attacker because of intervening terrain/obscuring terrain.

Effect: worsen the attack's BS characteristic by 1. This is not a save bonus in 11th edition.

Because it modifies BS, it interacts differently from hit-roll modifiers and may combine with them subject to the general modifier rules in the app.

## Hidden (`13.09`)

An INFANTRY/BEASTS/SWARM model in a terrain area containing dense terrain is Hidden if its unit did not make ranged attacks during the current or previous turn.

A Hidden model is visible only to enemy models within its detection range, normally 15".

Key asymmetry: a model outside the terrain can still be visible to the Hidden model even when it cannot see the Hidden model.

## Obscuring (`13.10`)

If every line of sight between two models crosses an intervening obscuring terrain area that neither model is within, they are not visible to each other.

Entering the terrain area generally removes that area's obscuring block for that model-to-model line; then use actual line of sight and Solid.

## Solid (`13.11`)

Dense terrain blocks line of sight through enclosed gaps 3" or less above ground, including doors, windows and bullet holes. Gaps above that height can be used normally.

## Plunging Fire (`22.05`)

Improve BS by 1 when attacking a visible unit containing a ground-level model if:

- attacker is on terrain 3" or higher; or
- attacker is TOWERING and target is within 12".

Does not apply to attacks by or against AIRCRAFT.

## Objectives (`14`)

### Terrain objective

Normally the entire terrain area is the objective. A model is in range while within that terrain area.

### Control timing

Control is checked at the end of every phase and turn.

Level of control = sum of OC of all models in range.

- higher total controls;
- tied total means no control unless the objective is secured.

A unit is “controlling” the objective only if it has at least one model with OC 1+ in range and its player controls the objective.

### Secured objective

Remains controlled after leaving until the opponent has a greater control level at the end of a phase.

### Objective marker fallback

If an objective does not coincide with terrain, use a 40 mm marker. Range is 3" horizontally and 5" vertically.

## Actions (`16`)

A unit cannot start an action if it is:

- off battlefield;
- AIRCRAFT or FORTIFICATION;
- battle-shocked;
- OC 0 or `-`;
- engaged, unless TITANIC;
- advanced or fell back this turn;
- already started another action this turn.

After starting:

- normally cannot shoot for the rest of turn, except TITANIC;
- cannot declare a charge.

The action fails to complete if the unit makes a move other than pile-in/consolidation or leaves the battlefield before completion.

## Tactical terrain checklist

- Can the firing unit actually see the target, model by model?
- Is the target Hidden due to the previous turn's shooting history?
- Does every target model qualify for cover?
- Does an intervening area count as Obscuring, or is one unit already inside it?
- Does Solid close a ground-floor gap?
- Is an objective the whole terrain area rather than a 3" circle?
- Will moving onto an objective expose the unit at the end of the phase, when control is checked?
