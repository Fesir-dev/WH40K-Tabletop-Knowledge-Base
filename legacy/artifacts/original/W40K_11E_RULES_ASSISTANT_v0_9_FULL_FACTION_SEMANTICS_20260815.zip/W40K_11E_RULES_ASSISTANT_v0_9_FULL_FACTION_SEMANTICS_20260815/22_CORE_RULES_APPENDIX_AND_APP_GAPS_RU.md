# Rules Appendix: извлечённое и недостающий app-only слой

## Печатная выборка, включённая в Core Rules

### Starting Strength / Half-strength
Starting strength определяется на начало первого раунда; для Attached Unit — общим числом моделей. Для одиночной модели пороги считаются по оставшимся wounds, для многомодельной — по числу моделей. Нечётное значение не может быть ровно half-strength, но может быть below half-strength.

### Adding a New Unit
Для добавленного в ходе битвы нового unit starting strength определяется в момент добавления.

### Destroyed
Сначала разрешаются triggered-on-destroyed rules, затем модель снимается. Если она погибла от attack, такие правила и снятие обычно ждут окончания атак attacking unit. Destroyed models/units обычно не применяют abilities и не выбираются правилами.

### Different Move Characteristics
В unit с разными M каждый model имеет собственный maximum distance; все общие ограничения move всё равно соблюдаются.

### Eligible to Fight, but Unable to Fight
Если все eligible units игрока дальше 5 дюймов от любого врага, он может pass. Два последовательных pass завершают Fight step.

### Mixed Keywords
Unit имеет объединение keywords всех своих models, но сами models не наследуют keywords друг друга.

### Objectives Not Within Terrain Area
Используется плоский 40-мм marker; models могут проходить и останавливаться на нём. Диапазон контроля: 3 дюйма по горизонтали и 5 по вертикали; измерение до ближайшей части маркера.

### Revived
Возвращение не превышает starting strength. Models возвращаются с исходным wargear/enhancements и обычно полными wounds, в coherency с моделями, которые начали фазу на поле; engagement допустим только с врагами, уже engaged с unit. Возвращённый Leader/Support остаётся частью Attached Unit, если возможно.

### Печатные FAQ
1. Unit без ranged weapons всё равно eligible to shoot.
2. Blast нельзя направлять в engaged unit через shooting exceptions для engaged Monster/Vehicle.
3. Overrun fight требует текущей eligibility to fight.
4. После Scout move нельзя embark.

## Что приложение обещает дополнительно

Core Rules указывают на расширенные определения, редкие взаимодействия и обновляемые FAQ. Их полный текст не находится в приложенном PDF. `data/app_reference_inventory.json` разделяет:
- `captured_printed_selection`;
- `missing_app_export`.

Запрещено восполнять missing entries текстом 10-й редакции или памятью. Для полного слоя нужны экспорт/скриншоты/официальный web-view актуального приложения.
