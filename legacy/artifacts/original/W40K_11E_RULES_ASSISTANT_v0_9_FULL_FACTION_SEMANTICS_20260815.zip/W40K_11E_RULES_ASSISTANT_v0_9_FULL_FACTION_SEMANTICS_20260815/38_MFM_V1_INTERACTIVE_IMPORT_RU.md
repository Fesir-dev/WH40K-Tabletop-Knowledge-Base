# MFM interactive — история импорта и current migration

## Historical checkpoint 2026-07-10

Первый интерактивный импорт использовал MFM v1.0 / source update 17.06.2026 и создал `data/mfm_live_snapshot_20260710.json`. Этот слой сохранён только как historical evidence.

## Current checkpoint 2026-08-15

В v0.6 восемь пользовательских фракций reconciled с MFM **v1.2**, официально обновлённым **22.07.2026**.

Текущие данные:
- `data/mfm_v1_2_user_factions_20260815.json`;
- `data/mfm_v1_2_user_faction_diff_20260815.json`;
- `factions/<slug>/mfm_v1_2_points.json`;
- `factions/<slug>/mfm_v1_2_detachments.json`;
- `factions/<slug>/leader_support_graph_v1_2.json`.

Импорт включает points, unit-size bands, duplicate-copy taxes, paid wargear, enhancement costs, Leader/Support links, Detachment Points и Force Dispositions.

Проверки:
```bash
python tools/validate_current_mfm.py
python tools/validate_live_layers.py
python tools/validate_source_freshness.py
python tools/run_current_regressions.py
```
